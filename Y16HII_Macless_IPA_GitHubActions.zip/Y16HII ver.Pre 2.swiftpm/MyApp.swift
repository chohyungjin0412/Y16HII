import SwiftUI
import AVFoundation
import AVKit
import UIKit
import ImageIO
import UserNotifications

// MARK: - 설정 (여기 숫자만 바꾸면 됩니다)
enum Config {
    // 아래 두 값은 [설정 > 영상 인코딩 설정]에서 바꿉니다
    static var fps: Int32 {
        let v = UserDefaults.standard.object(forKey: "videoFPS") as? Int ?? 24
        return Int32(min(60, max(5, v)))
    }
    static var interval: TimeInterval {
        let v = UserDefaults.standard.object(forKey: "shotInterval") as? Int ?? 120
        return TimeInterval(min(600, max(5, v)))
    }
    
    static let maxFrames = 720                // 최대 장수 (12시간 @60초 = 720장)
    static let warmup: TimeInterval = 1.5     // 카메라 켠 뒤 노출 안정화 대기(초)
    static let jpegQuality: CGFloat = 0.85
    static let maxVideoSide: CGFloat = 1920   // 원본 영상 긴 변 최대 픽셀
    static let recordW = 1920                 // 최종(레코드) 영상 크기 16:9
    static let recordH = 1080
    static let warn2Lead: TimeInterval = 10   // 2차 알림: 촬영 10초 전
    static let lateTolerance: TimeInterval = 20 // 이 시간 넘게 늦으면 그 회차는 건너뜀(AwayImage로 대체)
    static let maxPendingShots = 30           // 최소화 중 미리 예약할 회차 수 (알림 2개 x 30 + 안내 1 = 61, iOS 한도 64)
    
    static func tolerance(for interval: TimeInterval) -> TimeInterval { min(lateTolerance, interval / 2) }
}

// MARK: - 색상 테마
enum Theme {
    static let beige = Color(UIColor(hex: "#F3E9D2"))
    static let ink = Color(UIColor(hex: "#4A3B2A"))
}

// MARK: - 저장 위치
enum Store {
    static var docs: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    static var framesDir: URL { docs.appendingPathComponent("Frames", isDirectory: true) }
    static var videoURL: URL { docs.appendingPathComponent("timelapse.mp4") }               // 최종(레코드) 영상
    static var originalURL: URL { docs.appendingPathComponent("timelapse_original.mp4") }   // 원본 영상
    static var zipURL: URL {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy-MM-dd"
        return docs.appendingPathComponent("StudyFrames_\(f.string(from: Date())).zip")
    }
    static func ensure() {
        try? FileManager.default.createDirectory(at: framesDir, withIntermediateDirectories: true)
    }
    static func frameFiles() -> [URL] {
        let files = (try? FileManager.default.contentsOfDirectory(at: framesDir, includingPropertiesForKeys: nil)) ?? []
        return files.filter { $0.pathExtension == "jpg" }.sorted { $0.lastPathComponent < $1.lastPathComponent }
    }
    static func removeLeftovers() {
        try? FileManager.default.removeItem(at: originalURL)
        if let items = try? FileManager.default.contentsOfDirectory(at: docs, includingPropertiesForKeys: nil) {
            for u in items where u.pathExtension == "zip" { try? FileManager.default.removeItem(at: u) }
        }
    }
    /// 이미지 파일의 픽셀 크기 (전체를 디코딩하지 않고 헤더만 읽음)
    static func imageSize(_ url: URL) -> CGSize? {
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
              let p = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
              let w = p[kCGImagePropertyPixelWidth] as? Int,
              let h = p[kCGImagePropertyPixelHeight] as? Int else { return nil }
        return CGSize(width: w, height: h)
    }
}

// MARK: - 통계 로그 (Documents/Stats/capture_log.csv)
// 한 줄 = 한 번의 기록.  timestamp,kind,interval_sec
//  - kind "shot": 실제로 촬영된 사진   - kind "away": 놓쳐서 AwayImage로 대체된 프레임
// 사진을 삭제/압축해도 이 로그는 남기 때문에 누적 통계를 계산할 수 있습니다.
enum StatsLog {
    static var dir: URL { Store.docs.appendingPathComponent("Stats", isDirectory: true) }
    static var file: URL { dir.appendingPathComponent("capture_log.csv") }
    
    static func append(kind: String, date: Date, interval: TimeInterval) {
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let iso = ISO8601DateFormatter()
        iso.timeZone = .current
        iso.formatOptions = [.withInternetDateTime]
        let line = "\(iso.string(from: date)),\(kind),\(Int(interval))\n"
        
        if !FileManager.default.fileExists(atPath: file.path) {
            let header = "timestamp,kind,interval_sec\n"
            try? Data((header + line).utf8).write(to: file)
            return
        }
        if let h = try? FileHandle(forWritingTo: file) {
            defer { try? h.close() }
            _ = try? h.seekToEnd()
            try? h.write(contentsOf: Data(line.utf8))
        }
    }
    
    /// shots: 지금까지 찍힌 사진 수 / seconds: 지금까지 기록된 시간 (사진 수 × 당시 촬영 간격의 합)
    static func summary() -> (shots: Int, seconds: TimeInterval) {
        guard let text = try? String(contentsOf: file, encoding: .utf8) else { return (0, 0) }
        var shots = 0
        var seconds: TimeInterval = 0
        for line in text.split(separator: "\n") {
            let p = line.split(separator: ",")
            guard p.count >= 3, p[1] == "shot", let sec = Double(p[2]) else { continue }
            shots += 1
            seconds += sec
        }
        return (shots, seconds)
    }
    
    /// 2시간 → "2시간", 2.54시간 → "2.5시간"
    static func hoursText(_ seconds: TimeInterval) -> String {
        let h = (seconds / 3600 * 10).rounded() / 10
        if h == h.rounded() { return "\(Int(h))시간" }
        return String(format: "%.1f시간", h)
    }
}

enum AppError: LocalizedError {
    case noCamera, noFrame, encode(String), zip
    var errorDescription: String? {
        switch self {
        case .noCamera: return "전면 카메라를 찾을 수 없습니다"
        case .noFrame: return "프레임을 받지 못했습니다"
        case .encode(let s): return "인코딩 실패: \(s)"
        case .zip: return "압축 실패"
        }
    }
}

// MARK: - 색상 <-> 16진수
extension UIColor {
    convenience init(hex: String) {
        var s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        if s.count != 6 { s = "FFFFFF" }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        self.init(red: CGFloat((v >> 16) & 0xFF) / 255,
                  green: CGFloat((v >> 8) & 0xFF) / 255,
                  blue: CGFloat(v & 0xFF) / 255, alpha: 1)
    }
    var hexString: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        func c(_ x: CGFloat) -> Int { Int(max(0, min(255, (x * 255).rounded()))) }
        return String(format: "#%02X%02X%02X", c(r), c(g), c(b))
    }
}

// MARK: - 타임스탬프 스타일 (설정 메뉴에서 변경)
struct StampStyle: Codable, Equatable {
    var textHex = "#FFFFFF"
    var strokeHex = "#000000"
    var fontName = "System"
    var sizePercent = 2.8      // 사진 가로 길이 대비 %
    var strokeOn = true
    var strokeWidth = 3.0      // 글자 크기 대비 %
    var italic = false
    
    static let key = "stampStyle"
    static func load() -> StampStyle {
        guard let d = UserDefaults.standard.data(forKey: key),
              let s = try? JSONDecoder().decode(StampStyle.self, from: d) else { return StampStyle() }
        return s
    }
    func save() {
        if let d = try? JSONEncoder().encode(self) { UserDefaults.standard.set(d, forKey: StampStyle.key) }
    }
}

enum StampRenderer {
    static func text(for date: Date) -> String {
        let d = DateFormatter(); d.locale = Locale(identifier: "en_US_POSIX"); d.dateFormat = "yyyy.MM.dd."
        let t = DateFormatter(); t.locale = Locale(identifier: "en_US_POSIX"); t.dateFormat = "HH:mm"
        return d.string(from: date) + "\n" + t.string(from: date)
    }
    
    private static func makeFont(_ style: StampStyle, size: CGFloat) -> (UIFont, Bool) {
        let base: UIFont
        if style.fontName == "System" {
            base = UIFont.systemFont(ofSize: size, weight: .semibold)
        } else {
            base = UIFont(name: style.fontName, size: size) ?? UIFont.systemFont(ofSize: size, weight: .semibold)
        }
        guard style.italic else { return (base, false) }
        let traits = base.fontDescriptor.symbolicTraits.union(.traitItalic)
        if let d = base.fontDescriptor.withSymbolicTraits(traits) {
            let f = UIFont(descriptor: d, size: size)
            if f.fontDescriptor.symbolicTraits.contains(.traitItalic) { return (f, false) }
        }
        return (base, true)   // 이탤릭 서체가 없으면 기울임 효과로 대체
    }
    
    /// 현재 그래픽 컨텍스트의 우측 상단에 날짜/시간을 그림
    static func draw(text: String, canvas size: CGSize, style: StampStyle) {
        let fontSize = size.width * CGFloat(style.sizePercent) / 100
        let (font, oblique) = makeFont(style, size: fontSize)
        let para = NSMutableParagraphStyle(); para.alignment = .right
        var attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor(hex: style.textHex),
            .paragraphStyle: para
        ]
        if style.strokeOn {
            attrs[.strokeColor] = UIColor(hex: style.strokeHex)
            attrs[.strokeWidth] = -style.strokeWidth   // 음수 = 채우기 + 테두리
        }
        if oblique { attrs[.obliqueness] = 0.2 }
        let margin = size.width * 0.025
        let rect = CGRect(x: margin, y: margin, width: size.width - margin * 2, height: fontSize * 3)
        (text as NSString).draw(in: rect, withAttributes: attrs)
    }
    
    static func preview(_ style: StampStyle) -> UIImage {
        let size = CGSize(width: 800, height: 600)
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            UIColor(white: 0.5, alpha: 1).setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            draw(text: text(for: Date()), canvas: size, style: style)
        }
    }
}

// MARK: - 기록을 놓친 회차를 대신할 프레임 (AwayImage)
// 프로젝트 Assets에 'AwayImage' 이름의 이미지가 있으면 그 이미지를, 없으면 문구를 사용합니다.
enum AwayFrame {
    nonisolated static func jpeg(size: CGSize, date: Date, style: StampStyle, quality: CGFloat) -> Data? {
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            UIColor.black.setFill()
            UIRectFill(CGRect(origin: .zero, size: size))
            if let ui = UIImage(named: "AwayImage"), ui.size.width > 0, ui.size.height > 0 {
                let s = min(size.width / ui.size.width, size.height / ui.size.height)
                let w = ui.size.width * s, h = ui.size.height * s
                ui.draw(in: CGRect(x: (size.width - w) / 2, y: (size.height - h) / 2, width: w, height: h))
            } else {
                let para = NSMutableParagraphStyle(); para.alignment = .center
                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: size.width * 0.05, weight: .medium),
                    .foregroundColor: UIColor.white,
                    .paragraphStyle: para
                ]
                let text = "다른 앱 사용 중 📚" as NSString
                let box = text.boundingRect(with: CGSize(width: size.width, height: size.height),
                                            options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
                text.draw(in: CGRect(x: 0, y: (size.height - box.height) / 2, width: size.width, height: box.height + 4),
                          withAttributes: attrs)
            }
            StampRenderer.draw(text: StampRenderer.text(for: date), canvas: size, style: style)
        }
        return img.jpegData(compressionQuality: quality)
    }
}

// MARK: - 무음 카메라 (비디오 스트림에서 프레임을 뽑기 때문에 셔터음이 없음)
final class SilentCamera: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate, @unchecked Sendable {
    private let session = AVCaptureSession()
    private let output = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "camera.session")
    private let frameQueue = DispatchQueue(label: "camera.frames")
    private let lock = NSLock()
    private var latest: CVPixelBuffer?
    private var configured = false
    private var rotation: AVCaptureDevice.RotationCoordinator?
    private let ciContext = CIContext()
    
    /// 시작 전 화면의 미리보기가 같은 세션을 사용합니다
    var previewSession: AVCaptureSession { session }
    
    private func configure() throws {
        guard !configured else { return }
        let discovery = AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInUltraWideCamera, .builtInWideAngleCamera],
            mediaType: .video, position: .front)
        guard let dev = discovery.devices.first(where: { $0.deviceType == .builtInUltraWideCamera })
                ?? discovery.devices.first else { throw AppError.noCamera }
        
        session.beginConfiguration()
        if session.canSetSessionPreset(.photo) { session.sessionPreset = .photo }
        let input = try AVCaptureDeviceInput(device: dev)
        guard session.canAddInput(input) else { session.commitConfiguration(); throw AppError.noCamera }
        session.addInput(input)
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: frameQueue)
        guard session.canAddOutput(output) else { session.commitConfiguration(); throw AppError.noCamera }
        session.addOutput(output)
        session.commitConfiguration()
        
        // 가장 넓은 화각
        if (try? dev.lockForConfiguration()) != nil {
            dev.videoZoomFactor = dev.minAvailableVideoZoomFactor
            dev.unlockForConfiguration()
        }
        rotation = AVCaptureDevice.RotationCoordinator(device: dev, previewLayer: nil)
        configured = true
    }
    
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        setLatest(pb)
    }
    
    // 동기 함수 안에서만 lock을 쓰면 async 경고가 나지 않음
    private func setLatest(_ pb: CVPixelBuffer?) {
        lock.lock(); latest = pb; lock.unlock()
    }
    
    private func getLatest() -> CVPixelBuffer? {
        lock.lock(); defer { lock.unlock() }
        return latest
    }
    
    private func run(_ work: @escaping @Sendable () -> Void) async {
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            sessionQueue.async { work(); c.resume() }
        }
    }
    
    // MARK: 미리보기 (촬영 시작 전 앵글/얼굴 확인용)
    func startPreview() async throws {
        try configure()
        await run { if !self.session.isRunning { self.session.startRunning() } }
    }
    
    func stopPreview() async {
        await run { if self.session.isRunning { self.session.stopRunning() } }
    }
    
    /// 한 장 촬영 → 날짜/시간 각인 → JPEG Data와 이미지 크기 반환
    func capture() async throws -> (data: Data, size: CGSize) {
        try configure()
        if let coord = rotation, let conn = output.connection(with: .video) {
            let angle = coord.videoRotationAngleForHorizonLevelCapture
            if conn.isVideoRotationAngleSupported(angle) { conn.videoRotationAngle = angle }
        }
        setLatest(nil)
        
        await run { self.session.startRunning() }
        do {
            try await Task.sleep(nanoseconds: UInt64(Config.warmup * 1_000_000_000))
        } catch {
            await run { self.session.stopRunning() }
            throw error
        }
        let pb = getLatest()
        await run { self.session.stopRunning() }   // 쓰지 않을 때는 카메라를 꺼서 발열/전력 절약
        
        guard let pb else { throw AppError.noFrame }
        let ci = CIImage(cvPixelBuffer: pb)
        guard let cg = ciContext.createCGImage(ci, from: ci.extent) else { throw AppError.noFrame }
        let stamped = stamp(cg, date: Date(), style: StampStyle.load())
        guard let data = stamped.jpegData(compressionQuality: Config.jpegQuality) else { throw AppError.noFrame }
        return (data, stamped.size)
    }
    
    private func stamp(_ cg: CGImage, date: Date, style: StampStyle) -> UIImage {
        let size = CGSize(width: cg.width, height: cg.height)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1; fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            UIImage(cgImage: cg).draw(in: CGRect(origin: .zero, size: size))
            StampRenderer.draw(text: StampRenderer.text(for: date), canvas: size, style: style)
        }
    }
}

// MARK: - 카메라 미리보기 뷰
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    
    func makeUIView(context: Context) -> PreviewUIView {
        let v = PreviewUIView()
        v.previewLayer.session = session
        v.previewLayer.videoGravity = .resizeAspectFill
        return v
    }
    func updateUIView(_ uiView: PreviewUIView, context: Context) { uiView.updateRotation() }
}

final class PreviewUIView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        NotificationCenter.default.addObserver(self, selector: #selector(sessionStarted),
                                               name: AVCaptureSession.didStartRunningNotification, object: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    @objc private func sessionStarted() { DispatchQueue.main.async { self.updateRotation() } }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        updateRotation()
    }
    
    /// 화면이 보이는 방향에 맞춰 미리보기를 똑바로 세움
    func updateRotation() {
        guard let conn = previewLayer.connection else { return }
        let angle: CGFloat
        switch window?.windowScene?.interfaceOrientation ?? .landscapeRight {
        case .portrait: angle = 90
        case .portraitUpsideDown: angle = 270
        case .landscapeLeft: angle = 180
        case .landscapeRight: angle = 0
        default: angle = 90
        }
        if conn.isVideoRotationAngleSupported(angle) { conn.videoRotationAngle = angle }
    }
}

// MARK: - 타임랩스 인코더 (H.264 mp4, fps는 설정값)
enum VideoEncoder {
    enum Layout { case original, record }
    
    static func encode(files: [URL], to out: URL, fps: Int32, layout: Layout) async throws {
        guard let first = files.first,
              let firstCG = UIImage(contentsOfFile: first.path)?.cgImage else { throw AppError.encode("사진 없음") }
        
        let w: Int, h: Int
        switch layout {
        case .record:
            w = Config.recordW; h = Config.recordH
        case .original:
            let scale = min(1, Config.maxVideoSide / CGFloat(max(firstCG.width, firstCG.height)))
            w = Int(CGFloat(firstCG.width) * scale) / 2 * 2
            h = Int(CGFloat(firstCG.height) * scale) / 2 * 2
        }
        let W = CGFloat(w), H = CGFloat(h)
        let background: CGImage? = (layout == .record)
        ? recordBackground(canvas: CGSize(width: W, height: H),
                           photoSize: CGSize(width: firstCG.width, height: firstCG.height))
        : nil
        
        try? FileManager.default.removeItem(at: out)
        let writer = try AVAssetWriter(outputURL: out, fileType: .mp4)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: w,
            AVVideoHeightKey: h
        ])
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: w,
            kCVPixelBufferHeightKey as String: h
        ])
        writer.add(input)
        guard writer.startWriting() else { throw AppError.encode(writer.error?.localizedDescription ?? "시작 실패") }
        writer.startSession(atSourceTime: .zero)
        
        for (i, file) in files.enumerated() {
            while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds: 10_000_000) }
            guard let pool = adaptor.pixelBufferPool else { throw AppError.encode("버퍼 풀 없음") }
            try autoreleasepool {
                guard let cg = UIImage(contentsOfFile: file.path)?.cgImage else { return }
                var pbOut: CVPixelBuffer?
                CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pbOut)
                guard let pb = pbOut else { throw AppError.encode("버퍼 생성 실패") }
                CVPixelBufferLockBaseAddress(pb, [])
                defer { CVPixelBufferUnlockBaseAddress(pb, []) }
                guard let ctx = CGContext(
                    data: CVPixelBufferGetBaseAddress(pb), width: w, height: h, bitsPerComponent: 8,
                    bytesPerRow: CVPixelBufferGetBytesPerRow(pb), space: CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
                ) else { throw AppError.encode("컨텍스트 실패") }
                ctx.interpolationQuality = .high
                
                // 바탕
                ctx.setFillColor(layout == .record ? UIColor.white.cgColor : UIColor.black.cgColor)
                ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))
                if let bg = background { ctx.draw(bg, in: CGRect(x: 0, y: 0, width: W, height: H)) }
                
                // 사진: 잘림 없이 비율 유지. 레코드 영상은 오른쪽 끝 정렬, 원본은 가운데
                let pw = CGFloat(cg.width), ph = CGFloat(cg.height)
                let s = min(W / pw, H / ph)
                let dw = pw * s, dh = ph * s
                let x = (layout == .record) ? (W - dw) : (W - dw) / 2
                ctx.draw(cg, in: CGRect(x: x, y: (H - dh) / 2, width: dw, height: dh))
                
                adaptor.append(pb, withPresentationTime: CMTime(value: Int64(i), timescale: fps))
            }
        }
        input.markAsFinished()
        await writer.finishWriting()
        guard writer.status == .completed else { throw AppError.encode(writer.error?.localizedDescription ?? "알 수 없음") }
    }
    
    /// 흰 바탕 + 왼쪽 빈 공간 가운데에 "Today's your Record"
    private static func recordBackground(canvas: CGSize, photoSize: CGSize) -> CGImage? {
        let s = min(canvas.width / photoSize.width, canvas.height / photoSize.height)
        let leftW = canvas.width - photoSize.width * s
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: canvas, format: fmt).image { ctx in
            UIColor.white.setFill()
            ctx.fill(CGRect(origin: .zero, size: canvas))
            guard leftW > 120 else { return }
            let inset = leftW * 0.08
            let width = leftW - inset * 2
            let fontSize = min(width * 0.2, canvas.height * 0.08)
            let para = NSMutableParagraphStyle(); para.alignment = .center
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: fontSize, weight: .heavy),
                .foregroundColor: UIColor.black,
                .paragraphStyle: para
            ]
            let text = "Today's your Record" as NSString
            let box = text.boundingRect(with: CGSize(width: width, height: canvas.height),
                                        options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
            let y = (canvas.height - box.height) / 2
            text.draw(in: CGRect(x: inset, y: y, width: width, height: box.height + 4), withAttributes: attrs)
        }
        return img.cgImage
    }
}

// MARK: - 상태 관리
@MainActor
final class Recorder: ObservableObject {
    enum Phase { case idle, intro, running, encoding, review, finished }
    enum MoverPurpose { case original, zip }
    
    @Published var phase: Phase = .idle
    @Published var count = 0
    @Published var missed = 0
    @Published var toast: String?
    @Published var message = ""
    @Published var nextShot: Date?
    @Published var encodingText = "인코딩 중…"
    @Published var greetingVisible = false
    @Published var showMover = false
    @Published var moverFile: URL?
    @Published var askOriginal = false
    @Published var askDelete = false
    @Published var askStop = false
    
    private let camera = SilentCamera()
    private var task: Task<Void, Never>?
    private var moverPurpose: MoverPurpose = .zip
    private var isActive = true
    private var isStarting = false
    private var interval: TimeInterval = Config.interval   // 촬영 시작 시점의 값으로 고정
    private var lastFrameSize: CGSize?
    private var savedBrightness: CGFloat?
    
    private var dimEnabled: Bool { UserDefaults.standard.object(forKey: "dimWhileRunning") as? Bool ?? true }
    private var dimLevel: Double { UserDefaults.standard.object(forKey: "dimLevel") as? Double ?? 0.1 }
    private var screen: UIScreen? { (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.screen }
    
    var previewSession: AVCaptureSession { camera.previewSession }
    
    init() {
        Store.ensure()
        count = Store.frameFiles().count
        if count > 0 { message = "이전 촬영본 \(count)장이 남아 있습니다" }
    }
    
    // MARK: 시작 전 미리보기
    func startPreview() {
        Task {
            guard await AVCaptureDevice.requestAccess(for: .video) else {
                message = "설정에서 카메라 권한을 허용해주세요"; return
            }
            do { try await camera.startPreview() } catch { message = error.localizedDescription }
        }
    }
    
    func stopPreview() {
        Task { await camera.stopPreview() }
    }
    
    // MARK: 시작/종료
    func start() {
        guard task == nil, phase == .idle, !isStarting else { return }
        isStarting = true
        Task {
            defer { isStarting = false }
            let ok = await AVCaptureDevice.requestAccess(for: .video)
            guard ok else { message = "설정에서 카메라 권한을 허용해주세요"; return }
            _ = try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert])
            await playIntro()
        }
    }
    
    /// 시작 연출: 화면 요소 페이드 아웃(베이지 배경만 남김) → 인사말 페이드 인(2초) → 인사말+배경 페이드 아웃과 함께 촬영 시작
    private func playIntro() async {
        message = ""
        interval = Config.interval
        lastFrameSize = nil
        
        withAnimation(.easeInOut(duration: 0.6)) { phase = .intro }
        try? await Task.sleep(for: .seconds(0.7))
        await camera.stopPreview()
        
        withAnimation(.easeInOut(duration: 0.6)) { greetingVisible = true }
        try? await Task.sleep(for: .seconds(0.6 + 2.0))   // 완전히 나타난 뒤 2초 유지
        
        UIApplication.shared.isIdleTimerDisabled = true   // 화면 자동 잠금 방지 (촬영 중 필수)
        missed = 0
        withAnimation(.easeInOut(duration: 0.8)) {
            greetingVisible = false
            phase = .running
        }
        task = Task { await loop() }
    }
    
    func stopAndEncode() {
        let t = task
        task = nil
        t?.cancel()
        Task {
            await t?.value   // 진행 중이던 촬영이 정리된 뒤에 인코딩 시작
            await encode()
        }
    }
    
    func abort() {
        askStop = false
        task?.cancel(); task = nil
        clearNotifications()
        applyDim(false)
        UIApplication.shared.isIdleTimerDisabled = false
        greetingVisible = false
        phase = .idle
        nextShot = nil
    }
    
    func encodeExisting() {
        guard count > 0 else { return }
        Task { await encode() }
    }
    
    // MARK: 앱 활성/비활성 (최소화) 처리
    func sceneChanged(active: Bool) {
        isActive = active
        guard phase == .running else { return }
        if active {
            clearNotifications()
            applyDim(true)
        } else {
            applyDim(false)
            scheduleNotifications(from: Date())
        }
    }
    
    // 최소화되면 앱이 멈추므로 알림을 미리 예약해 둔다 (앱이 다시 열리면 전부 취소)
    //  0) 전환 즉시: "전체화면에서만 기록이 가능합니다!"
    //  1차) 전환 즉시(첫 회차) / 직전 회차 시각(이후 회차): 남은 시간(분) 안내
    //       - 첫 회차: 다음 촬영까지 남은 시간, 이후 회차: 촬영 주기
    //  2차) 촬영까지 10초 초과로 남았으면 10초 전, 10초 이내면 1차 직후 → 알림 시점 기준 남은 초(10~0)
    private func scheduleNotifications(from now: Date) {
        guard var t = nextShot else { return }
        while t.timeIntervalSince(now) < 3 { t = t.addingTimeInterval(interval) }   // 이미 진행 중인 회차는 건너뜀
        
        UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        post(id: "full",
             body: "전체화면에서만 기록이 가능합니다!\n(만약 바쁘시다면 잠시 후에 알림이 가요!)",
             at: now.addingTimeInterval(1))
        
        let shots = min(Config.maxPendingShots, max(0, Config.maxFrames - count))
        var prev = now
        for k in 0..<shots {
            let f1 = (k == 0) ? now.addingTimeInterval(2) : prev.addingTimeInterval(1)
            let leftText = Self.minutesText(k == 0 ? t.timeIntervalSince(f1) : interval)
            post(id: "shot\(k)-1", body: "기록까지 \(leftText) 남았어요! 저를 눌러주세요🔥", at: f1)
            
            let f2 = max(f1.addingTimeInterval(1), t.addingTimeInterval(-Config.warn2Lead))
            if f2 < t {
                let n = min(10, max(0, Int(t.timeIntervalSince(f2).rounded())))
                let body = n > 0
                ? "\(n)초 후에 기록이 되요! - “설명할 시간 없어! 빨리 타!!⚠️”"
                : "지금 기록이 되요! - “설명할 시간 없어! 빨리 타!!⚠️”"
                post(id: "shot\(k)-2", body: body, at: f2)
            }
            prev = t
            t = t.addingTimeInterval(interval)
        }
    }
    
    private func post(id: String, body: String, at date: Date) {
        let delay = date.timeIntervalSinceNow
        guard delay > 0.5 else { return }
        let c = UNMutableNotificationContent()
        c.title = "📷 공부 타임랩스"
        c.body = body
        c.sound = nil   // 조용한 자습실: 소리 없음
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: delay, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: id, content: c, trigger: trigger))
    }
    
    /// 300초 → "5분", 100초 → "2분", 60초 미만 → "1분 미만"
    private static func minutesText(_ seconds: TimeInterval) -> String {
        if seconds < 60 { return "1분 미만" }
        return "\(Int((seconds / 60).rounded()))분"
    }
    
    private func clearNotifications() {
        let c = UNUserNotificationCenter.current()
        c.removeAllPendingNotificationRequests()
        c.removeAllDeliveredNotifications()
    }
    
    // 촬영 중 화면 밝기 낮추기
    private func applyDim(_ on: Bool) {
        guard let screen else { return }
        if on {
            guard dimEnabled else { return }
            if savedBrightness == nil { savedBrightness = screen.brightness }
            screen.brightness = CGFloat(dimLevel)
        } else if let b = savedBrightness {
            screen.brightness = b
            savedBrightness = nil
        }
    }
    
    // MARK: 촬영 루프
    private func loop() async {
        applyDim(true)
        var next = Date()
        while !Task.isCancelled && count < Config.maxFrames {
            nextShot = next
            let wait = next.timeIntervalSinceNow
            if wait > 0 { try? await Task.sleep(for: .seconds(wait)) }
            if Task.isCancelled { return }
            
            // 앱이 최소화/비활성이었거나 시간이 많이 지났다면 놓친 회차마다 AwayImage 프레임으로 대체
            let tolerance = Config.tolerance(for: interval)
            if !isActive || -next.timeIntervalSinceNow > tolerance {
                repeat {
                    await fillAway(at: next)
                    next = next.addingTimeInterval(interval)
                } while count < Config.maxFrames && !Task.isCancelled && next.timeIntervalSinceNow < -tolerance
                continue
            }
            await shoot()
            next = next.addingTimeInterval(interval)
        }
        guard !Task.isCancelled else { return }
        task = nil
        await encode()
    }
    
    @discardableResult
    private func saveFrame(_ data: Data) -> Bool {
        let idx = Store.frameFiles().count + 1
        let url = Store.framesDir.appendingPathComponent(String(format: "frame_%04d.jpg", idx))
        do {
            try data.write(to: url)
            count = idx
            return true
        } catch {
            message = error.localizedDescription
            return false
        }
    }
    
    private func shoot() async {
        do {
            let r = try await camera.capture()
            guard saveFrame(r.data) else { return }
            lastFrameSize = r.size
            StatsLog.append(kind: "shot", date: Date(), interval: interval)
            showToast("📷 \(count)")
        } catch {
            if error is CancellationError || Task.isCancelled { return }
            message = error.localizedDescription
            await fillAway(at: Date())   // 촬영 실패도 영상 길이가 어긋나지 않게 대체 프레임으로 채움
        }
    }
    
    /// 기록하지 못한 회차를 AwayImage 프레임으로 대체
    private func fillAway(at date: Date) async {
        guard count < Config.maxFrames else { return }
        missed += 1
        let size = lastFrameSize
        ?? Store.frameFiles().first.flatMap { Store.imageSize($0) }
        ?? CGSize(width: 1920, height: 1440)
        let style = StampStyle.load()
        let quality = Config.jpegQuality
        let data = await Task.detached(priority: .utility) {
            AwayFrame.jpeg(size: size, date: date, style: style, quality: quality)
        }.value
        guard let data, saveFrame(data) else { return }
        StatsLog.append(kind: "away", date: date, interval: interval)
    }
    
    private func encode() async {
        askStop = false
        clearNotifications()
        applyDim(false)
        phase = .encoding
        encodingText = "영상 인코딩 중…"
        nextShot = nil
        do {
            try await VideoEncoder.encode(files: Store.frameFiles(), to: Store.videoURL, fps: Config.fps, layout: .record)
            phase = .review
        } catch {
            message = error.localizedDescription
            phase = .idle
        }
        UIApplication.shared.isIdleTimerDisabled = false
    }
    
    // 작은 팝업 (1.5초 뒤 사라짐)
    private func showToast(_ text: String) {
        toast = text
        Task {
            try? await Task.sleep(for: .seconds(1.5))
            if toast == text { toast = nil }
        }
    }
    
    // MARK: 검토 후 정리 (원본 영상 저장 여부 → 사진 삭제 여부)
    func reviewDone() { askOriginal = true }
    
    func answerOriginal(save: Bool) {
        askOriginal = false
        if save {
            Task { await encodeOriginalAndMove() }
        } else {
            scheduleAskDelete()
        }
    }
    
    private func encodeOriginalAndMove() async {
        phase = .encoding
        encodingText = "원본 영상 인코딩 중…"
        do {
            try await VideoEncoder.encode(files: Store.frameFiles(), to: Store.originalURL, fps: Config.fps, layout: .original)
            phase = .review
            try? await Task.sleep(for: .seconds(0.4))
            moverPurpose = .original
            moverFile = Store.originalURL
            showMover = true
        } catch {
            message = error.localizedDescription
            phase = .review
            scheduleAskDelete()
        }
    }
    
    private func scheduleAskDelete() {
        Task {
            try? await Task.sleep(for: .seconds(0.5))
            askDelete = true
        }
    }
    
    func deleteFrames() {
        for f in Store.frameFiles() { try? FileManager.default.removeItem(at: f) }
        Store.removeLeftovers()
        count = 0
        message = "사진을 모두 삭제했습니다"
        phase = .finished
    }
    
    func prepareZip() {
        var coordError: NSError?
        var result: URL?
        let dest = Store.zipURL
        NSFileCoordinator().coordinate(readingItemAt: Store.framesDir, options: [.forUploading], error: &coordError) { tmp in
            try? FileManager.default.removeItem(at: dest)
            if (try? FileManager.default.copyItem(at: tmp, to: dest)) != nil { result = dest }
        }
        if let r = result, coordError == nil {
            moverPurpose = .zip
            moverFile = r
            showMover = true
        } else {
            message = AppError.zip.localizedDescription
            scheduleAskDelete()
        }
    }
    
    func moverFinished(_ result: Result<URL, Error>) {
        switch moverPurpose {
        case .original:
            if case .failure(let e) = result { message = e.localizedDescription }
            scheduleAskDelete()   // 저장하든 취소하든 다음 질문으로
        case .zip:
            switch result {
            case .success:
                for f in Store.frameFiles() { try? FileManager.default.removeItem(at: f) }  // 낱장 중복 제거 (압축본은 파일 앱에 있음)
                Store.removeLeftovers()
                count = 0
                message = "압축 파일을 저장했습니다"
                phase = .finished
            case .failure:
                message = "압축 저장이 취소되었습니다 (사진은 그대로 남아 있습니다)"
                scheduleAskDelete()
            }
        }
    }
    
    func reset() {
        message = ""
        phase = .idle
    }
}

// MARK: - 화면
@main
struct StudyTimelapseApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct ContentView: View {
    @StateObject private var rec = Recorder()
    @Environment(\.scenePhase) private var scenePhase
    @State private var expanded = false
    @State private var clockMode = 0        // 0 검정, 1 아날로그, 2 디지털
    
    private var isRecording: Bool { rec.phase == .running }
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                    .alert("사용된 \(rec.count)장을 삭제할까요?", isPresented: $rec.askDelete) {
                        Button("예", role: .destructive) { rec.deleteFrames() }
                        Button("아니요") { rec.prepareZip() }
                    } message: {
                        Text("‘아니요’를 누르면 \(rec.count)장을 하나의 압축 파일로 만들어 파일 앱에 저장합니다.")
                    }
                
                // 시작 전/시작 연출 동안의 베이지 바탕 (촬영이 시작되면 페이드 아웃)
                if rec.phase == .idle || rec.phase == .intro {
                    Theme.beige.ignoresSafeArea().transition(.opacity)
                }
                
                switch rec.phase {
                case .idle:
                    IdleView(rec: rec, size: geo.size).transition(.opacity)
                case .intro:
                    IntroView(rec: rec).transition(.opacity)
                case .running:
                    runningView(geo)
                case .encoding:
                    ProgressView(rec.encodingText).tint(.white).foregroundStyle(.white)
                case .review: ReviewView(rec: rec)
                case .finished:
                    VStack(spacing: 16) {
                        Text(rec.message).foregroundStyle(.white)
                        ShareLink(item: Store.videoURL) { Label("영상 저장/공유", systemImage: "square.and.arrow.up") }
                        Button("처음으로") { rec.reset() }
                    }
                }
                
                // 최소화(비활성) 되는 순간 앱 전환 화면에 보일 "다른 앱 사용 중" 표지
                if scenePhase != .active && isRecording { AwayCover() }
            }
            .alert("원본 영상도 저장할까요?", isPresented: $rec.askOriginal) {
                Button("예") { rec.answerOriginal(save: true) }
                Button("아니요") { rec.answerOriginal(save: false) }
            } message: {
                Text("원본은 사진만 이어 붙인 영상입니다 (‘Today’s your Record’ 레이아웃 없음).")
            }
            .fileMover(isPresented: $rec.showMover, file: rec.moverFile) { result in
                rec.moverFinished(result)
            }
        }
        .ignoresSafeArea()
        .alert("⚠️ 기록을 중단하시겠습니까?", isPresented: $rec.askStop) {
            Button("예", role: .destructive) { rec.stopAndEncode() }
            Button("아니요", role: .cancel) {}
        } message: {
            Text("‘예’를 누르면 지금까지 찍은 사진으로 영상을 만듭니다.")
        }
        .onChange(of: scenePhase) { _, new in rec.sceneChanged(active: new == .active) }
        .statusBarHidden(true)
    }
    
    private func isWindowed(_ geo: GeometryProxy) -> Bool {
        let bounds = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.screen.bounds ?? UIScreen.main.bounds
        return geo.size.width < bounds.width - 2 || geo.size.height < bounds.height - 2
    }
    
    // 촬영 중: 거의 검은 화면 + 구석의 작은 표시들
    private func runningView(_ geo: GeometryProxy) -> some View {
        ZStack {
            // 시계 (좌상단 1/9 영역을 탭할 때마다 검정 → 아날로그 → 디지털 → 검정)
            if clockMode == 1 {
                AnalogClock()
                    .frame(width: min(geo.size.width, geo.size.height) * 0.6,
                           height: min(geo.size.width, geo.size.height) * 0.6)
                    .allowsHitTesting(false)
            } else if clockMode == 2 {
                DigitalClock().allowsHitTesting(false)
            }
            
            VStack {
                HStack {
                    Color.clear
                        .frame(width: geo.size.width / 3, height: geo.size.height / 3)
                        .contentShape(Rectangle())
                        .onTapGesture { clockMode = (clockMode + 1) % 3 }
                    Spacer()
                    // 우상단 약 1/8 영역 (화면과 같은 비율, 가로·세로 약 35%)
                    Color.clear
                        .frame(width: geo.size.width * 0.354, height: geo.size.height * 0.354)
                        .contentShape(Rectangle())
                        .onTapGesture { rec.askStop = true }
                }
                Spacer()
            }
            
            VStack {
                HStack {
                    Spacer()
                    if let t = rec.toast {
                        Text(t)
                            .font(.system(size: 10))
                            .foregroundStyle(.white.opacity(0.7))
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(.white.opacity(0.12), in: Capsule())
                    }
                }
                Spacer()
                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: 6) {
                        if expanded {
                            if let n = rec.nextShot {
                                Text("다음 \(n.formatted(date: .omitted, time: .shortened)) · 놓친 \(rec.missed)")
                                    .font(.system(size: 10)).foregroundStyle(.gray)
                            }
                            Button("종료 후 인코딩") { rec.stopAndEncode() }.font(.system(size: 11))
                            Button("중단", role: .destructive) { rec.abort() }.font(.system(size: 11))
                        }
                        Text("● \(rec.count)/\(Config.maxFrames)")
                            .font(.system(size: 10))
                            .foregroundStyle(.white.opacity(0.35))
                            .onTapGesture { expanded.toggle() }
                    }
                    Spacer()
                    if isWindowed(geo) {
                        Text("Can you expand it for our records")
                            .font(.system(size: 10))
                            .foregroundStyle(.red)
                    }
                }
            }
            .padding(10)
        }
    }
}

// MARK: - 시작 화면 (베이지 바탕 + 중앙 카메라 미리보기)
struct IdleView: View {
    @ObservedObject var rec: Recorder
    let size: CGSize
    
    @State private var showSettings = false
    @State private var showStats = false
    @State private var showThanks = false
    
    var body: some View {
        ZStack {
            ZStack {
                // 앱 제목 (중앙 상단)
                VStack {
                    Text("Your 16 Hours Isn't It?")
                        .font(.system(size: 34, weight: .bold, design: .serif))
                        .foregroundStyle(Theme.ink)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                        .padding(.horizontal, 24)
                        .padding(.top, size.height * 0.08)
                    Spacer()
                }
                
                // 카메라 미리보기: 화면의 40%, 정중앙
                CameraPreview(session: rec.previewSession)
                    .frame(width: size.width * 0.4, height: size.height * 0.4)
                    .background(Color.black.opacity(0.1))
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.ink.opacity(0.15), lineWidth: 1))
                
                // 버튼들 (미리보기 바로 아래)
                VStack(spacing: 10) {
                    Spacer().frame(height: size.height * 0.7 + 16)
                    if !rec.message.isEmpty {
                        Text(rec.message).font(.footnote).foregroundStyle(Theme.ink.opacity(0.8))
                    }
                    HStack(spacing: 14) {
                        Button { showStats = true } label: { Label("통계", systemImage: "chart.bar") }
                            .buttonStyle(.bordered)
                        Button("촬영 시작") { rec.start() }
                            .buttonStyle(.borderedProminent)
                        Button { showSettings = true } label: { Label("설정", systemImage: "gearshape") }
                            .buttonStyle(.bordered)
                    }
                    .tint(Theme.ink)
                    if rec.count > 0 {
                        Button("남은 \(rec.count)장으로 바로 인코딩") { rec.encodeExisting() }
                            .font(.footnote)
                            .tint(Theme.ink)
                    }
                    Spacer()
                }
                
                // 하단 문구 (이스터에그: 평범한 글씨처럼 보이지만 누르면 이미지 팝업. 주변 10pt까지 터치 영역)
                VStack {
                    Spacer()
                    VStack(spacing: 2) {
                        Text("우리 어플은 이용자의 촬영된 사진(또는 출력 영상 등 기기 내에서 촬영된 모든 파일)을 수집하지 않아요!")
                        Text("Made by YNDHSIA with Claude")
                    }
                    .font(.system(size: 12))
                    .foregroundStyle(Theme.ink.opacity(0.55))
                    .multilineTextAlignment(.center)
                    // 한글은 이탤릭 서체가 없어서 기울임 변형으로 이탤릭 느낌을 냄
                    .transformEffect(CGAffineTransform(a: 1, b: 0, c: -0.2, d: 1, tx: 0, ty: 0))
                    .padding(10)
                    .contentShape(Rectangle())
                    .onTapGesture {
                        withAnimation(.easeInOut(duration: 0.25)) { showThanks = true }
                    }
                    .padding(.bottom, 14)
                }
            }
            .blur(radius: showThanks ? 5 : 0)
            
            if showThanks {
                ThanksPopup(size: size) {
                    withAnimation(.easeInOut(duration: 0.25)) { showThanks = false }
                }
                .transition(.opacity)
            }
        }
        .frame(width: size.width, height: size.height)
        .onAppear { rec.startPreview() }
        .onDisappear { rec.stopPreview() }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showStats) { StatsView() }
    }
}

// 배경은 어둡게(그림자처럼) 하고 가운데에 이미지 창을 띄움. 아무 곳이나 누르면 닫힘
struct ThanksPopup: View {
    let size: CGSize
    let onClose: () -> Void
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.55)
                .ignoresSafeArea()
                .onTapGesture { onClose() }
            Group {
                // 프로젝트에 'Thank_you_for_use' 이름의 이미지를 넣으면 그 이미지가 표시됩니다
                if let ui = UIImage(named: "Thank_you_for_use") {
                    Image(uiImage: ui).resizable().scaledToFit()
                } else {
                    Text("Thank you for use 💛")
                        .font(.title2.weight(.semibold))
                        .foregroundStyle(Theme.ink)
                        .padding(48)
                }
            }
            .frame(maxWidth: size.width * 0.6, maxHeight: size.height * 0.7)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .shadow(color: .black.opacity(0.35), radius: 24, y: 8)
            .onTapGesture { onClose() }
        }
    }
}

// MARK: - 시작 연출 (베이지 바탕 + 인사말)
struct IntroView: View {
    @ObservedObject var rec: Recorder
    
    var body: some View {
        Text("자, 시작해볼까요? 오늘도 화이팅!")
            .font(.system(size: 34, weight: .bold))
            .foregroundStyle(Theme.ink)
            .multilineTextAlignment(.center)
            .padding(.horizontal, 24)
            .opacity(rec.greetingVisible ? 1 : 0)
    }
}

struct AwayCover: View {
    var body: some View {
        ZStack {
            Color.black
            // 프로젝트에 'AwayImage' 이름의 이미지를 넣으면 그 이미지가 표시됩니다
            if let ui = UIImage(named: "AwayImage") {
                Image(uiImage: ui).resizable().scaledToFit()
            } else {
                Text("다른 앱 사용 중 📚").foregroundStyle(.white)
            }
        }
        .ignoresSafeArea()
    }
}

struct AnalogClock: View {
    var body: some View {
        TimelineView(.everyMinute) { ctx in
            let cal = Calendar.current
            let h = Double(cal.component(.hour, from: ctx.date) % 12)
            let m = Double(cal.component(.minute, from: ctx.date))
            GeometryReader { g in
                let s = min(g.size.width, g.size.height)
                let r = s / 2
                ZStack {
                    Circle().stroke(Color.white.opacity(0.8), lineWidth: s * 0.01)
                    ForEach(1...12, id: \.self) { n in
                        Text("\(n)")
                            .font(.system(size: s * 0.09, weight: .medium, design: .serif))
                            .foregroundStyle(.white.opacity(0.85))
                            .position(x: r + CGFloat(sin(Double(n) * .pi / 6)) * r * 0.82,
                                      y: r - CGFloat(cos(Double(n) * .pi / 6)) * r * 0.82)
                    }
                    hand(length: r * 0.5, width: s * 0.025, angle: (h + m / 60) * 30)   // 시침
                    hand(length: r * 0.75, width: s * 0.015, angle: m * 6)               // 분침 (초침 없음)
                    Circle().fill(Color.white).frame(width: s * 0.04, height: s * 0.04)
                }
                .frame(width: s, height: s)
            }
        }
    }
    
    private func hand(length: CGFloat, width: CGFloat, angle: Double) -> some View {
        Capsule()
            .fill(Color.white.opacity(0.9))
            .frame(width: width, height: length)
            .offset(y: -length / 2)
            .rotationEffect(.degrees(angle))
    }
}

struct DigitalClock: View {
    var body: some View {
        TimelineView(.everyMinute) { ctx in
            VStack(spacing: 12) {
                Text(Self.format(ctx.date, "yy년 MM월 dd일 (E)"))
                    .font(.system(size: 34, weight: .medium))
                Text(Self.format(ctx.date, "HH : mm"))
                    .font(.system(size: 80, weight: .semibold, design: .rounded))
                    .monospacedDigit()
            }
            .foregroundStyle(.white.opacity(0.9))
        }
    }
    
    private static func format(_ date: Date, _ pattern: String) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ko_KR")
        f.dateFormat = pattern
        return f.string(from: date)
    }
}

struct ReviewView: View {
    @ObservedObject var rec: Recorder
    @State private var player = AVPlayer(url: Store.videoURL)
    
    var body: some View {
        VStack(spacing: 14) {
            VideoPlayer(player: player)
                .aspectRatio(16.0 / 9.0, contentMode: .fit)
                .onAppear { player.play() }
            Text("최종 영상을 확인하고, 먼저 저장하세요 (공유 → 파일에 저장)")
                .font(.footnote).foregroundStyle(.gray)
            HStack(spacing: 24) {
                ShareLink(item: Store.videoURL) { Label("영상 저장/공유", systemImage: "square.and.arrow.up") }
                Button("검토 완료") { rec.reviewDone() }.buttonStyle(.borderedProminent)
            }
        }
        .padding()
    }
}

// MARK: - 통계
struct StatsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var summary = StatsLog.summary()
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                card(title: "지금까지 찍힌 나의 순간!", value: "\(summary.shots)장")
                card(title: "지금까지 찍힌 나의 연속성!", value: StatsLog.hoursText(summary.seconds))
                Spacer()
            }
            .padding(24)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Theme.beige.ignoresSafeArea())
            .navigationTitle("통계")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("완료") { dismiss() } }
            }
            .onAppear { summary = StatsLog.summary() }
        }
    }
    
    private func card(title: String, value: String) -> some View {
        VStack(spacing: 10) {
            Text(title).font(.headline).foregroundStyle(Theme.ink.opacity(0.7))
            Text(value).font(.system(size: 44, weight: .bold, design: .rounded)).foregroundStyle(Theme.ink)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 28)
        .background(Color.white, in: RoundedRectangle(cornerRadius: 20))
    }
}

// MARK: - 설정 (타임스탬프 디자인, 영상 인코딩, 밝기)
struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var style = StampStyle.load()
    @AppStorage("dimWhileRunning") private var dim = true
    @AppStorage("dimLevel") private var dimLevel = 0.1
    
    private let fonts = ["System", "Helvetica Neue", "Avenir Next", "Georgia", "Times New Roman",
                         "Courier New", "Menlo", "Futura", "Optima", "Palatino",
                         "Arial Rounded MT Bold", "Marker Felt", "Noteworthy", "Chalkduster"]
    
    var body: some View {
        NavigationStack {
            Form {
                Section("미리보기") {
                    Image(uiImage: StampRenderer.preview(style))
                        .resizable().scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                Section("타임스탬프") {
                    ColorPicker("글자 색", selection: colorBinding(\.textHex), supportsOpacity: false)
                    Picker("글꼴", selection: $style.fontName) {
                        ForEach(fonts, id: \.self) { name in
                            Text(name).font(name == "System" ? .body : .custom(name, size: 17)).tag(name)
                        }
                    }
                    Toggle("이탤릭", isOn: $style.italic)
                    VStack(alignment: .leading) {
                        Text("크기 \(style.sizePercent, specifier: "%.1f")%")
                        Slider(value: $style.sizePercent, in: 1.5...6)
                    }
                    Toggle("글자 테두리", isOn: $style.strokeOn)
                    if style.strokeOn {
                        ColorPicker("테두리 색", selection: colorBinding(\.strokeHex), supportsOpacity: false)
                        VStack(alignment: .leading) {
                            Text("테두리 두께 \(style.strokeWidth, specifier: "%.1f")")
                            Slider(value: $style.strokeWidth, in: 0.5...8)
                        }
                    }
                }
                Section("영상") {
                    NavigationLink {
                        EncodingSettingsView()
                    } label: {
                        Label("영상 인코딩 설정", systemImage: "film")
                    }
                }
                Section("전력") {
                    Toggle("촬영 중 밝기 낮추기", isOn: $dim)
                    if dim {
                        VStack(alignment: .leading) {
                            Text("촬영 중 밝기 \(Int(dimLevel * 100))%")
                            Slider(value: $dimLevel, in: 0.0...0.5)
                        }
                    }
                }
            }
            .navigationTitle("설정")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("완료") { style.save(); dismiss() }
                }
            }
            .onChange(of: style) { _, s in s.save() }
        }
    }
    
    private func colorBinding(_ keyPath: WritableKeyPath<StampStyle, String>) -> Binding<Color> {
        Binding(
            get: { Color(UIColor(hex: style[keyPath: keyPath])) },
            set: { style[keyPath: keyPath] = UIColor($0).hexString }
        )
    }
}

// MARK: - 영상 인코딩 설정 (fps / 촬영 간격)
struct EncodingSettingsView: View {
    @AppStorage("videoFPS") private var fps = 24
    @AppStorage("shotInterval") private var interval = 120
    
    var body: some View {
        VStack(spacing: 0) {
            FPSIndicator(fps: fps)
            Divider()
            Form {
                Section {
                    VStack(alignment: .leading) {
                        Text("프레임 \(fps)fps")
                        Slider(value: doubleBinding($fps), in: 5...60, step: 1)
                    }
                    VStack(alignment: .leading) {
                        Text("촬영 간격 \(interval)초")
                        Slider(value: doubleBinding($interval), in: 5...600, step: 1)
                    }
                } footer: {
                    Text("""
                         개발자 추천
                         장시간 촬영 설정 : 24fps, 120초 (12시간에 10.5초 영상 출력) (디폴트)
                         단시간 촬영 설정 : 36fps, 6초 (1시간에 10초 영상 출력)
                         """)
                    .font(.caption2)
                }
            }
        }
        .navigationTitle("영상 인코딩 설정")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    private func doubleBinding(_ b: Binding<Int>) -> Binding<Double> {
        Binding(get: { Double(b.wrappedValue) }, set: { b.wrappedValue = Int($0.rounded()) })
    }
}

/// 흰 바탕 위를 검정 공이 왼쪽 끝 → 오른쪽 끝으로 움직이고, 끝에 닿으면 다시 왼쪽에서 시작.
/// 공은 "한 프레임에 한 칸"씩 튀며 움직여서 fps가 낮을수록 뚝뚝 끊기고 느리게, 높을수록 부드럽고 빠르게 보임.
struct FPSIndicator: View {
    let fps: Int
    private let steps = 30          // 왼쪽 끝에서 오른쪽 끝까지 가는 프레임 수
    private let ballSize: CGFloat = 26
    
    var body: some View {
        TimelineView(.animation) { ctx in
            let frame = Int((ctx.date.timeIntervalSinceReferenceDate * Double(fps)).rounded(.down))
            let idx = ((frame % steps) + steps) % steps
            GeometryReader { g in
                let travel = max(0, g.size.width - ballSize)
                Circle()
                    .fill(Color.black)
                    .frame(width: ballSize, height: ballSize)
                    .offset(x: travel * CGFloat(idx) / CGFloat(steps - 1),
                            y: (g.size.height - ballSize) / 2)
            }
        }
        .frame(height: 90)
        .frame(maxWidth: .infinity)
        .background(Color.white)
    }
}
