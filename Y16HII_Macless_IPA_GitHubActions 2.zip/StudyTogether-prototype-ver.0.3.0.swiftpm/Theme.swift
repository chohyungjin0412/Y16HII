import SwiftUI

extension Color {
    init(hex: String) {
        var v: UInt64 = 0
        Scanner(string: hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))).scanHexInt64(&v)
        self.init(red: Double((v >> 16) & 0xFF) / 255,
                  green: Double((v >> 8) & 0xFF) / 255,
                  blue: Double(v & 0xFF) / 255)
    }
}

// Figma 변수(Colors)와 같은 이름. 색을 바꿀 때 Figma와 여기를 같이 고치면 됨
enum Theme {
    static let bg            = Color(hex: "#F5F6FA")   // bg
    static let surface       = Color(hex: "#FFFFFF")   // surface
    static let textPrimary   = Color(hex: "#1B1D29")   // text/primary
    static let textSecondary = Color(hex: "#6B7080")   // text/secondary
    static let accent        = Color(hex: "#4D6BFE")   // accent
    static let danger        = Color(hex: "#FF5A5F")   // danger
    static let success       = Color(hex: "#2FBF71")   // success
    static let border        = Color(hex: "#E6E8F0")   // border
    static let subjectHexes  = ["#FF6B6B", "#FFA94D", "#FFD93D", "#6BCB77", "#4D96FF", "#9B72CF"] // subject/1~6
}

// 큰 제목 + 스크롤 영역 (Figma 화면 공통 틀)
struct ScreenScaffold<Content: View>: View {
    let title: String
    let content: Content

    init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(title)
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(Theme.textPrimary)
                content
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 16)
            .padding(.top, 12)
            .padding(.bottom, 24)
        }
        .background(Theme.bg.ignoresSafeArea())
    }
}

// 흰 카드 (Figma 'Card')
struct CardStyle: ViewModifier {
    var vertical: CGFloat = 8
    func body(content: Content) -> some View {
        content
            .padding(.horizontal, 16)
            .padding(.vertical, vertical)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Theme.surface, in: RoundedRectangle(cornerRadius: 16))
    }
}
extension View {
    func card(vertical: CGFloat = 8) -> some View { modifier(CardStyle(vertical: vertical)) }
}

struct Divider1: View {
    var body: some View { Rectangle().fill(Theme.border).frame(height: 1) }
}
