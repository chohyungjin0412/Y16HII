import SwiftUI

// ───────── 프로필 탭 ─────────
struct ProfileView: View {
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var profile: ProfileStore
    @EnvironmentObject var store: TimerStore
    @State private var showAuth = false
    @State private var showEditor = false
    @State private var showBlocked = false

    private var nickname: String { profile.me?.nickname ?? "" }

    var body: some View {
        ScreenScaffold("프로필") {
            VStack(spacing: 8) {
                Text(String((nickname.isEmpty ? "스" : nickname).prefix(1)))
                    .font(.system(size: 32, weight: .bold)).foregroundColor(.white)
                    .frame(width: 80, height: 80).background(Theme.accent, in: Circle())
                Text(nickname.isEmpty ? "닉네임을 정해 주세요" : nickname)
                    .font(.system(size: 20, weight: .bold)).foregroundColor(Theme.textPrimary)
            }
            .frame(maxWidth: .infinity).padding(.vertical, 8)

            VStack(alignment: .leading, spacing: 12) {
                if session.isSignedIn {
                    Text(session.email).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
                    if let err = profile.loadError {
                        Text(err).font(.system(size: 13)).foregroundColor(Theme.danger)
                        Button("다시 불러오기") { Task { await profile.load() } }.font(.system(size: 14, weight: .medium))
                    }
                    Button(profile.isComplete ? "프로필 편집" : "프로필 만들기") { showEditor = true }
                        .font(.system(size: 15, weight: .medium))
                    Button("차단 목록") { showBlocked = true }.font(.system(size: 15, weight: .medium))
                    Button("로그아웃", role: .destructive) { session.signOut() }.font(.system(size: 15, weight: .medium))
                        .disabled(store.runningSubjectId != nil || !store.pendingStops.isEmpty)
                    if store.runningSubjectId != nil || !store.pendingStops.isEmpty {
                        Text("측정 중이거나 종료 신호를 보내는 중에는 로그아웃할 수 없어요.")
                            .font(.system(size: 12)).foregroundColor(Theme.textSecondary)
                    }
                } else {
                    Text("로그인하면 친구와 랭크를 이용할 수 있어요")
                        .font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                    PrimaryButton(title: "로그인 / 회원가입") { showAuth = true }
                }
            }
            .card(vertical: 16)

            if session.isSignedIn, let p = profile.me {
                Text("공개 설정").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
                VStack(spacing: 0) {
                    ToggleRowView(label: "실명 공개", isOn: binding(p.privacy.showRealName) { $0.showRealName = $1 }); Divider1()
                    ToggleRowView(label: "나이 공개 (성인만)", isOn: binding(p.privacy.showAge) { $0.showAge = $1 }); Divider1()
                    ToggleRowView(label: "성별 공개", isOn: binding(p.privacy.showGender) { $0.showGender = $1 }); Divider1()
                    ToggleRowView(label: "타임랩스 영상 공개", isOn: binding(p.privacy.showTimelapse) { $0.showTimelapse = $1 })
                }
                .card()
                Text("10대는 실제 나이 대신 문구만 보여요. 공개 설정은 바로 서버에 저장돼요.")
                    .font(.system(size: 12)).foregroundColor(Theme.textSecondary)
            }
        }
        .sheet(isPresented: $showAuth) { AuthView() }
        .sheet(isPresented: $showEditor) { ProfileEditor() }
        .sheet(isPresented: $showBlocked) { BlockedListView() }
    }

    private func binding(_ value: Bool, _ apply: @escaping (inout Privacy, Bool) -> Void) -> Binding<Bool> {
        Binding(get: { value },
                set: { v in Task { await profile.setPrivacy { apply(&$0, v) } } })
    }
}

// ───────── 프로필 만들기 / 편집 ─────────
struct ProfileEditor: View {
    @EnvironmentObject var profile: ProfileStore
    @Environment(\.dismiss) private var dismiss
    @State private var nickname = ""
    @State private var birthYear: Int?
    @State private var gender: String?
    @State private var realName = ""
    @State private var busy = false
    @State private var message: String?
    @State private var showConfirm = false
    @State private var loaded = false

    private var locked: Bool { profile.me?.birthYear != nil }
    private let thisYear = Calendar.current.component(.year, from: Date())
    private var canSave: Bool {
        nickname.trimmingCharacters(in: .whitespaces).count >= 2 && birthYear != nil && gender != nil && !busy
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("닉네임 (2~12자)") { TextField("닉네임", text: $nickname) }

                Section {
                    Picker("출생연도", selection: $birthYear) {
                        Text("선택").tag(Int?.none)
                        ForEach(Array((thisYear - 100)...(thisYear - 8)).reversed(), id: \.self) { Text(String($0) + "년").tag(Int?.some($0)) }
                    }
                    .disabled(locked)
                    Picker("성별", selection: $gender) {
                        Text("선택").tag(String?.none)
                        Text("남자").tag(String?.some("male"))
                        Text("여자").tag(String?.some("female"))
                    }
                    .pickerStyle(.segmented)
                    .disabled(locked)
                } header: { Text("출생연도 · 성별") }
                footer: { Text(locked ? "출생연도와 성별은 바꿀 수 없어요." : "저장하면 바꿀 수 없어요. 신중하게 골라 주세요.") }

                Section("실명 (선택, 공개 설정에서 따로 켜야 보여요)") { TextField("실명", text: $realName) }

                if let message { Section { Text(message).foregroundColor(.red) } }
            }
            .navigationTitle("프로필")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("취소") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("저장") { locked ? save() : (showConfirm = true) }.disabled(!canSave)
                }
            }
            .alert("출생연도와 성별을 저장할까요?", isPresented: $showConfirm) {
                Button("저장") { save() }
                Button("취소", role: .cancel) {}
            } message: { Text("저장하면 나중에 바꿀 수 없어요.") }
            .onAppear {
                guard !loaded, let me = profile.me else { return }
                loaded = true
                nickname = me.nickname ?? ""; birthYear = me.birthYear; gender = me.gender; realName = me.realName ?? ""
            }
        }
    }

    private func save() {
        busy = true; message = nil
        let update = ProfileUpdate(nickname: nickname.trimmingCharacters(in: .whitespaces),
                                   birthYear: locked ? nil : birthYear, gender: locked ? nil : gender,
                                   realName: realName.trimmingCharacters(in: .whitespaces), privacy: nil)
        Task {
            do {
                try await profile.save(update)
                await MainActor.run { dismiss() }
            } catch { await MainActor.run { message = errorText(error) } }
            await MainActor.run { busy = false }
        }
    }
}

// ───────── 차단 목록 ─────────
struct BlockedListView: View {
    @EnvironmentObject var store: TimerStore
    @Environment(\.dismiss) private var dismiss
    @State private var blocked: [BlockedUser] = []
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ScreenScaffold("차단 목록") {
                if let message { Text(message).font(.system(size: 14)).foregroundColor(Theme.danger) }
                if blocked.isEmpty {
                    Text("차단한 사용자가 없어요").font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                        .frame(maxWidth: .infinity).padding(.top, 40)
                } else {
                    VStack(spacing: 0) {
                        ForEach(Array(blocked.enumerated()), id: \.element.id) { i, u in
                            HStack {
                                Text(u.nickname).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.darkRed)
                                Spacer()
                                Button("해제") { unblock(u) }.font(.system(size: 14, weight: .bold)).foregroundColor(Theme.accent)
                            }
                            .frame(height: 52)
                            if i < blocked.count - 1 { Divider1() }
                        }
                    }
                    .card()
                }
            }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("닫기") { dismiss() } } }
            .navigationBarTitleDisplayMode(.inline)
            .task { await load() }
        }
    }

    private func unblock(_ u: BlockedUser) {
        Task {
            do { try await store.api.unblock(userId: u.id); await load() }
            catch { await MainActor.run { message = errorText(error) } }
        }
    }

    private func load() async {
        do { let b = try await store.api.fetchBlocks(); await MainActor.run { blocked = b } }
        catch { await MainActor.run { message = errorText(error) } }
    }
}
