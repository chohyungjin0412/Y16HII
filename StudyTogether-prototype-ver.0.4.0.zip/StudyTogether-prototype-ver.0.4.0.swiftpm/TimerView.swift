import SwiftUI

// 과목 선택 화면 (탭 바 있음). 과목을 누르면 측정 화면(MeasureView)이 전체 화면으로 뜸
struct TimerView: View {
    @EnvironmentObject var store: TimerStore
    @State private var now = Date()
    @State private var showAdd = false
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    private var today: String { DayBoundary.studyDay(of: now) }

    var body: some View {
        ScreenScaffold("스터디투게더") {
            if let err = store.syncError {
                VStack(alignment: .leading, spacing: 8) {
                    Text("종료 신호를 서버에 보내지 못했어요").font(.system(size: 14, weight: .bold)).foregroundColor(Theme.danger)
                    Text(err).font(.system(size: 12)).foregroundColor(Theme.textSecondary)
                    if !store.pendingStops.isEmpty {
                        Text("종료 시각은 기기에 저장돼 있고, 연결되면 자동으로 다시 보내요.")
                            .font(.system(size: 12)).foregroundColor(Theme.textSecondary)
                        Button("지금 다시 보내기") { store.flushPendingStops() }.font(.system(size: 14, weight: .bold))
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .card(vertical: 12)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("오늘 공부시간").font(.system(size: 13)).foregroundColor(Theme.textSecondary)
                Text(hms(store.seconds(on: today, now: now)))
                    .font(.system(size: 44, weight: .bold)).monospacedDigit()
                    .foregroundColor(Theme.textPrimary)
            }
            .card(vertical: 20)

            Text("과목").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)

            VStack(spacing: 0) {
                ForEach(store.subjects) { s in
                    Button { store.start(s.id) } label: {
                        SubjectRowView(name: s.name, colorHex: s.colorHex,
                                       seconds: store.seconds(subject: s.id, on: today, now: now))
                    }
                    .buttonStyle(.plain)
                    .disabled(store.isStarting)
                    .contextMenu {
                        Button("보관", role: .destructive) { store.archiveSubject(id: s.id) }
                    }
                    Divider1()
                }
                Button { showAdd = true } label: {
                    Text("+ 과목 추가").font(.system(size: 15, weight: .medium)).foregroundColor(Theme.accent)
                        .frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 14)
                }
            }
            .card()

            ToggleRowView(label: "뽀모도로 (25분 집중 / 5분 휴식)", isOn: $store.pomodoroOn).card()

            VStack(alignment: .leading, spacing: 4) {
                ToggleRowView(label: "오프라인 측정 모드", isOn: $store.offlineMode)
                Text("켜면 측정 중에 서버와 연결하지 않아요. 친구에게는 공부 중으로 보이지 않고, 끝내면 기록이 한 번에 올라가요.")
                    .font(.system(size: 12)).foregroundColor(Theme.textSecondary)
            }
            .card()
        }
        .alert("알림", isPresented: Binding(get: { store.alertMessage != nil },
                                           set: { if !$0 { store.alertMessage = nil } })) {
            Button("확인") { store.alertMessage = nil }
        } message: { Text(store.alertMessage ?? "") }
        .sheet(isPresented: $showAdd) { AddSubjectView() }
        .fullScreenCover(isPresented: Binding(get: { store.runningSubjectId != nil }, set: { _ in })) {
            MeasureView().environmentObject(store)
        }
        .onReceive(ticker) { t in now = t; store.tick(t) }
        .onAppear { Notifier.requestAuth() }
    }
}

struct AddSubjectView: View {
    @EnvironmentObject var store: TimerStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var color = Theme.subjectHexes[0]

    var body: some View {
        NavigationStack {
            Form {
                TextField("과목 이름", text: $name)
                HStack {
                    ForEach(Theme.subjectHexes, id: \.self) { hex in
                        Circle().fill(Color(hex: hex)).frame(width: 32, height: 32)
                            .overlay(Circle().stroke(Color.primary, lineWidth: color == hex ? 3 : 0))
                            .onTapGesture { color = hex }
                    }
                }
            }
            .navigationTitle("과목 추가")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("취소") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("저장") {
                        store.addSubject(name: name.trimmingCharacters(in: .whitespaces), colorHex: color)
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                }
            }
        }
    }
}
