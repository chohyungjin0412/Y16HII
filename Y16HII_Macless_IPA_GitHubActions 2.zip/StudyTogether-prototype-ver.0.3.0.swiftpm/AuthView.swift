import SwiftUI

struct PrimaryButton: View {
    let title: String
    var busy = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Group {
                if busy { ProgressView().tint(.white) }
                else { Text(title).font(.system(size: 16, weight: .bold)) }
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).padding(.vertical, 14)
            .background(Theme.accent, in: RoundedRectangle(cornerRadius: 12))
        }
        .disabled(busy)
    }
}

// 로그인 / 회원가입 / 이메일 인증을 한 시트에서 처리
struct AuthView: View {
    enum Mode { case signIn, signUp, confirm }

    @EnvironmentObject var session: SessionStore
    @Environment(\.dismiss) private var dismiss
    @State private var mode: Mode = .signIn
    @State private var email = ""
    @State private var password = ""
    @State private var password2 = ""
    @State private var code = ""
    @State private var message: String?
    @State private var busy = false

    private var title: String {
        switch mode { case .signIn: return "로그인"; case .signUp: return "회원가입"; case .confirm: return "이메일 인증" }
    }
    private var buttonTitle: String {
        switch mode { case .signIn: return "로그인"; case .signUp: return "가입하기"; case .confirm: return "인증하고 시작" }
    }

    var body: some View {
        NavigationStack {
            ScreenScaffold(title) {
                if session.isMock {
                    Text("테스트 모드: 서버 없이 동작해요. 인증 코드는 123456, 비밀번호는 8자 이상이면 돼요.")
                        .font(.system(size: 13)).foregroundColor(Theme.textSecondary)
                }
                if mode == .confirm {
                    Text("\(email)로 보낸 인증 코드를 입력해 주세요.")
                        .font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                }

                VStack(spacing: 0) {
                    TextField("이메일", text: $email)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .keyboardType(.emailAddress).disabled(mode == .confirm)
                        .frame(height: 52)
                    Divider1()
                    if mode == .confirm {
                        TextField("인증 코드 6자리", text: $code)
                            .keyboardType(.numberPad).frame(height: 52)
                    } else {
                        SecureField("비밀번호", text: $password).frame(height: 52)
                        if mode == .signUp {
                            Divider1()
                            SecureField("비밀번호 확인", text: $password2).frame(height: 52)
                        }
                    }
                }
                .foregroundColor(Theme.textPrimary)
                .card()

                if let message {
                    Text(message).font(.system(size: 14)).foregroundColor(Theme.danger)
                }

                PrimaryButton(title: buttonTitle, busy: busy, action: submit)

                VStack(spacing: 12) {
                    switch mode {
                    case .signIn:
                        link("계정이 없어요 · 회원가입") { mode = .signUp; message = nil }
                    case .signUp:
                        link("이미 계정이 있어요 · 로그인") { mode = .signIn; message = nil }
                    case .confirm:
                        link("코드 다시 받기") { resend() }
                        link("처음으로") { mode = .signIn; message = nil }
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("닫기") { dismiss() } } }
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func link(_ text: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(text).font(.system(size: 14, weight: .medium)).foregroundColor(Theme.accent)
        }
    }

    private func show(_ error: Error) {
        message = (error as? LocalizedError)?.errorDescription ?? "알 수 없는 오류가 발생했어요."
    }

    private func submit() {
        message = nil; busy = true
        Task {
            do {
                switch mode {
                case .signIn:
                    try await session.signIn(email: email, password: password)
                    await MainActor.run { dismiss() }
                case .signUp:
                    guard password == password2 else { throw AuthError.message("비밀번호가 서로 달라요.") }
                    try await session.signUp(email: email, password: password)
                    await MainActor.run { mode = .confirm }
                case .confirm:
                    try await session.confirm(email: email, code: code)
                    if password.isEmpty {   // 인증만 끝나고 비밀번호가 없는 경우 로그인 화면으로
                        await MainActor.run { mode = .signIn; message = "인증 완료! 로그인해 주세요." }
                    } else {
                        try await session.signIn(email: email, password: password)
                        await MainActor.run { dismiss() }
                    }
                }
            } catch AuthError.needsConfirmation {
                try? await session.resend(email: email)
                await MainActor.run { mode = .confirm; message = "이메일 인증이 필요해요. 새 코드를 보냈어요." }
            } catch {
                await MainActor.run { show(error) }
            }
            await MainActor.run { busy = false }
        }
    }

    private func resend() {
        Task {
            do { try await session.resend(email: email); await MainActor.run { message = "코드를 다시 보냈어요." } }
            catch { await MainActor.run { show(error) } }
        }
    }
}

// 로그인 없이는 못 쓰는 탭(커뮤니티, 친구)에 보여줄 화면
struct LoginRequiredView: View {
    let title: String
    @State private var showAuth = false

    var body: some View {
        ScreenScaffold(title) {
            VStack(spacing: 12) {
                Text("로그인이 필요해요").font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
                Text("친구와 랭크는 계정이 있어야 이용할 수 있어요.\n타이머는 로그인 없이 쓸 수 있어요.")
                    .font(.system(size: 14)).foregroundColor(Theme.textSecondary).multilineTextAlignment(.center)
                PrimaryButton(title: "로그인 / 회원가입") { showAuth = true }.padding(.top, 8)
            }
            .frame(maxWidth: .infinity).padding(.top, 60)
        }
        .sheet(isPresented: $showAuth) { AuthView() }
    }
}
