import SwiftUI
import UIKit
import CoreText

// MARK: - 앱 전역 설정
// 문구·폰트·색·크기·이미지 같은 "자주 바꾸는 값"은 코드 본문 말고 여기서만 수정하세요.
// (이미 AppConfig 파일이 있다면 아래 `enum Splash` 블록만 기존 AppConfig 안으로 옮기면 됩니다.)

enum AppConfig {
    
    static let appVersion = "prototype-0.4.0"                            // 앱 버전. 여기만 고치면 설정 탭 맨 아래 'Ver. 0.1.0'이 바뀜
    static let region = "ap-southeast-2"                       // 시드니 (개발용). 서울로 옮기면 ap-northeast-2
    static let cognitoClientId = "6o4lfburddnn6731gavgt8i736"         // Cognito 앱 클라이언트 ID (비밀 키 없는 것)
    static let apiBaseURL = "https://xoptufo6mi.execute-api.ap-southeast-2.amazonaws.com" // API Gateway 주소
    
    static var useMockAuth: Bool { cognitoClientId.hasPrefix("YOUR_") }
    static var useMockAPI: Bool { apiBaseURL.contains("YOUR_") }
    
    // MARK: 스플래시 화면
    enum Splash {
        
        // 중앙 문구 (한 줄이 한 요소입니다. 줄바꿈 = 배열 항목 추가)
        static let titleLines: [String] = ["Study", "Together"]
        
        // 폰트 ─ 프로젝트에 폰트 파일(.ttf / .otf)을 넣고 "파일명.확장자"만 적으면 됩니다.
        // nil 이면 시스템 폰트를 씁니다. 파일을 못 찾아도 시스템 폰트로 자동 대체됩니다.
        static let fontFileName: String? = "YeongdoOTF-Regular.otf"          // 예: "MyFont.ttf"
        static let fontSize: CGFloat = 56
        static let fallbackFontWeight: Font.Weight = .bold   // 시스템 폰트일 때만 적용
        static let lineSpacing: CGFloat = 4
        static let titleColor: Color = Color(red: 0.106, green: 0.114, blue: 0.161)   // Figma 기본 텍스트색
        
        // 배경
        static let backgroundColor: Color = Color(red: 0.961, green: 0.965, blue: 0.980)   // Figma 배경색
        
        // 하단 중앙 로고 (회사 로고)
        // 프로젝트에 이미지를 넣고 "파일명.확장자" 또는 에셋 이름을 적으세요. nil 이면 표시 안 함.
        static let logoImageFile: String? = "MODORI_Logo.png"         // 예: "CompanyLogo.png"
        static let logoHeight: CGFloat = 32
        static let logoBottomPadding: CGFloat = 28
        
        // 좌하단 버전 표기
        static let showVersion: Bool = true
        static let versionPrefix: String = "v"
        static let showBuildNumber: Bool = false        // true 면 v1.0 (3) 형태
        static let versionFontSize: CGFloat = 13
        static let versionColor: Color = Color(red: 0.42, green: 0.44, blue: 0.50)   // Figma 보조 텍스트색
        static let versionLeadingPadding: CGFloat = 24
        static let versionBottomPadding: CGFloat = 28
        
        // 노출 시간(초)과 사라지는 페이드 시간(초)
        static let displayDuration: TimeInterval = 2.0
        static let fadeDuration: TimeInterval = 0.4
    }
}

// MARK: - 폰트 / 이미지 / 버전 도우미

enum ConfigResources {
    
    private static var fontCache: [String: String] = [:]
    
    /// 번들의 폰트 파일을 등록하고 PostScript 이름을 돌려줍니다. 실패하면 nil.
    static func registeredFontName(file: String) -> String? {
        if let cached = fontCache[file] { return cached }
        
        let ns = file as NSString
        let name = ns.deletingPathExtension
        let ext = ns.pathExtension
        guard let url = Bundle.main.url(forResource: name, withExtension: ext.isEmpty ? nil : ext),
              let provider = CGDataProvider(url: url as CFURL),
              let cgFont = CGFont(provider),
              let postScript = cgFont.postScriptName as String? else {
            return nil
        }
        // 이미 등록된 경우 false 가 돌아오지만 문제 없습니다.
        CTFontManagerRegisterGraphicsFont(cgFont, nil)
        fontCache[file] = postScript
        return postScript
    }
    
    /// 설정값을 바탕으로 SwiftUI Font 를 만듭니다.
    static func splashFont() -> Font {
        let size = AppConfig.Splash.fontSize
        if let file = AppConfig.Splash.fontFileName,
           let ps = registeredFontName(file: file) {
            return .custom(ps, size: size)
        }
        return .system(size: size, weight: AppConfig.Splash.fallbackFontWeight)
    }
    
    /// 에셋 이름 → 번들 파일 순서로 이미지를 찾습니다.
    static func image(file: String) -> UIImage? {
        let ns = file as NSString
        let name = ns.deletingPathExtension
        let ext = ns.pathExtension
        
        if let img = UIImage(named: file) ?? UIImage(named: name) { return img }
        if let url = Bundle.main.url(forResource: name, withExtension: ext.isEmpty ? nil : ext),
           let data = try? Data(contentsOf: url),
           let img = UIImage(data: data) {
            return img
        }
        return nil
    }
    
    /// 앱 설정(Info)에 저장된 버전을 읽어옵니다.
    static func versionText() -> String {
        let info = Bundle.main.infoDictionary
        let version = info?["CFBundleShortVersionString"] as? String ?? "?"
        var text = AppConfig.Splash.versionPrefix + version
        if AppConfig.Splash.showBuildNumber, let build = info?["CFBundleVersion"] as? String {
            text += " (\(build))"
        }
        return text
    }
}

