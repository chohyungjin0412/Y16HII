import Foundation
import Security

// ── 토큰 / 오류 ──
struct AuthTokens: Codable {
    var idToken: String
    var accessToken: String
    var refreshToken: String
    var expiresAt: Date
}

enum AuthError: LocalizedError {
    case message(String)
    case needsConfirmation      // 가입은 했지만 이메일 인증 전
    case wrongCredentials       // 이메일/비밀번호 불일치
    case sessionExpired         // 자동 로그인 갱신 실패
    case network

    var errorDescription: String? {
        switch self {
        case .message(let m): return m
        case .needsConfirmation: return "이메일 인증이 필요해요."
        case .wrongCredentials: return "이메일 또는 비밀번호가 맞지 않아요."
        case .sessionExpired: return "로그인이 만료됐어요. 다시 로그인해 주세요."
        case .network: return "네트워크 연결을 확인해 주세요."
        }
    }

    static func from(type rawType: String, message: String?) -> AuthError {
        let type = rawType.split(separator: "#").last.map(String.init) ?? rawType
        switch type {
        case "NotAuthorizedException", "UserNotFoundException": return .wrongCredentials
        case "UserNotConfirmedException": return .needsConfirmation
        case "UsernameExistsException": return .message("이미 가입된 이메일이에요.")
        case "InvalidPasswordException": return .message("비밀번호 규칙에 맞지 않아요. (사용자 풀에 정한 규칙 확인)")
        case "CodeMismatchException": return .message("인증 코드가 맞지 않아요.")
        case "ExpiredCodeException": return .message("인증 코드가 만료됐어요. 코드를 다시 받아 주세요.")
        case "LimitExceededException", "TooManyRequestsException", "TooManyFailedAttemptsException":
            return .message("시도가 너무 많아요. 잠시 후 다시 해 주세요.")
        case "InvalidParameterException": return .message("입력한 내용을 확인해 주세요.")
        default: return .message(message ?? "오류가 발생했어요. (\(type))")
        }
    }
}

// ── 인증 서버 인터페이스 (Mock ↔ Cognito 교체 가능) ──
protocol AuthAPI {
    func signUp(email: String, password: String) async throws
    func confirm(email: String, code: String) async throws
    func resendCode(email: String) async throws
    func signIn(email: String, password: String) async throws -> AuthTokens
    func refresh(refreshToken: String) async throws -> AuthTokens
}

// ── 서버 없이 화면 확인용: 인증 코드는 123456, 비밀번호는 8자 이상이면 로그인됨 ──
struct MockAuth: AuthAPI {
    private func fake() -> AuthTokens {
        AuthTokens(idToken: "mock-id", accessToken: "mock-access", refreshToken: "mock-refresh",
                   expiresAt: Date().addingTimeInterval(3600))
    }
    func signUp(email: String, password: String) async throws {
        if password.count < 8 { throw AuthError.message("비밀번호는 8자 이상이어야 해요.") }
    }
    func confirm(email: String, code: String) async throws {
        if code != "123456" { throw AuthError.message("인증 코드가 맞지 않아요.") }
    }
    func resendCode(email: String) async throws {}
    func signIn(email: String, password: String) async throws -> AuthTokens {
        if password.count < 8 { throw AuthError.wrongCredentials }
        return fake()
    }
    func refresh(refreshToken: String) async throws -> AuthTokens { fake() }
}

// ── Cognito 직접 호출 (SDK 없이 HTTPS만 사용) ──
// 필요한 설정: 앱 클라이언트에 비밀 키 없음 + ALLOW_USER_PASSWORD_AUTH, ALLOW_REFRESH_TOKEN_AUTH 켬
struct CognitoAuth: AuthAPI {
    let region: String
    let clientId: String

    private var url: URL { URL(string: "https://cognito-idp.\(region).amazonaws.com/")! }

    private func call(_ target: String, _ body: [String: Any]) async throws -> [String: Any] {
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/x-amz-json-1.1", forHTTPHeaderField: "Content-Type")
        req.setValue("AWSCognitoIdentityProviderService.\(target)", forHTTPHeaderField: "X-Amz-Target")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let data: Data, resp: URLResponse
        do { (data, resp) = try await URLSession.shared.data(for: req) }
        catch { throw AuthError.network }
        let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        if let http = resp as? HTTPURLResponse, http.statusCode >= 400 {
            throw AuthError.from(type: json["__type"] as? String ?? "", message: json["message"] as? String)
        }
        return json
    }

    func signUp(email: String, password: String) async throws {
        _ = try await call("SignUp", [
            "ClientId": clientId, "Username": email, "Password": password,
            "UserAttributes": [["Name": "email", "Value": email]]
        ])
    }

    func confirm(email: String, code: String) async throws {
        _ = try await call("ConfirmSignUp", ["ClientId": clientId, "Username": email, "ConfirmationCode": code])
    }

    func resendCode(email: String) async throws {
        _ = try await call("ResendConfirmationCode", ["ClientId": clientId, "Username": email])
    }

    func signIn(email: String, password: String) async throws -> AuthTokens {
        let json = try await call("InitiateAuth", [
            "AuthFlow": "USER_PASSWORD_AUTH", "ClientId": clientId,
            "AuthParameters": ["USERNAME": email, "PASSWORD": password]
        ])
        guard let r = json["AuthenticationResult"] as? [String: Any],
              let id = r["IdToken"] as? String,
              let access = r["AccessToken"] as? String,
              let refresh = r["RefreshToken"] as? String
        else { throw AuthError.message("로그인 응답을 확인할 수 없어요.") }
        let expires = (r["ExpiresIn"] as? Double) ?? 3600
        return AuthTokens(idToken: id, accessToken: access, refreshToken: refresh,
                          expiresAt: Date().addingTimeInterval(expires))
    }

    func refresh(refreshToken: String) async throws -> AuthTokens {
        let json: [String: Any]
        do {
            json = try await call("InitiateAuth", [
                "AuthFlow": "REFRESH_TOKEN_AUTH", "ClientId": clientId,
                "AuthParameters": ["REFRESH_TOKEN": refreshToken]
            ])
        } catch AuthError.wrongCredentials { throw AuthError.sessionExpired }
        guard let r = json["AuthenticationResult"] as? [String: Any],
              let id = r["IdToken"] as? String,
              let access = r["AccessToken"] as? String
        else { throw AuthError.sessionExpired }
        let expires = (r["ExpiresIn"] as? Double) ?? 3600
        // 갱신 응답에는 refresh 토큰이 없으므로 기존 것을 유지
        return AuthTokens(idToken: id, accessToken: access, refreshToken: refreshToken,
                          expiresAt: Date().addingTimeInterval(expires))
    }
}

// ── 토큰 보관: 키체인 우선, 안 되면 UserDefaults로 대체 (Playgrounds 대비) ──
enum SecureStore {
    private static let service = "StudyTogether"
    private static func base(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: key]
    }
    static func save(_ data: Data, key: String) {
        SecItemDelete(base(key) as CFDictionary)
        var add = base(key); add[kSecValueData as String] = data
        if SecItemAdd(add as CFDictionary, nil) == errSecSuccess {
            UserDefaults.standard.removeObject(forKey: "fallback.\(key)")
        } else {
            UserDefaults.standard.set(data, forKey: "fallback.\(key)")
        }
    }
    static func load(key: String) -> Data? {
        var q = base(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        if SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data { return d }
        return UserDefaults.standard.data(forKey: "fallback.\(key)")
    }
    static func delete(key: String) {
        SecItemDelete(base(key) as CFDictionary)
        UserDefaults.standard.removeObject(forKey: "fallback.\(key)")
    }
}

// ── 로그인 상태 ──
final class SessionStore: ObservableObject {
    @Published private(set) var isSignedIn = false
    @Published private(set) var email = ""
    let isMock: Bool
    var onSignedIn: (() -> Void)?
    var onSignedOut: (() -> Void)?

    private let auth: AuthAPI
    private var tokens: AuthTokens?
    private let key = "session"

    private struct Saved: Codable { var email: String; var tokens: AuthTokens }

    init(auth: AuthAPI, isMock: Bool) {
        self.auth = auth
        self.isMock = isMock
        if let data = SecureStore.load(key: key),
           let s = try? JSONDecoder().decode(Saved.self, from: data) {
            tokens = s.tokens; email = s.email; isSignedIn = true
        }
    }

    func signUp(email: String, password: String) async throws {
        try await auth.signUp(email: clean(email), password: password)
    }
    func confirm(email: String, code: String) async throws {
        try await auth.confirm(email: clean(email), code: code.trimmingCharacters(in: .whitespaces))
    }
    func resend(email: String) async throws { try await auth.resendCode(email: clean(email)) }

    func signIn(email: String, password: String) async throws {
        let e = clean(email)
        let t = try await auth.signIn(email: e, password: password)
        await MainActor.run {
            self.tokens = t; self.email = e; self.isSignedIn = true
            self.persist()
            self.onSignedIn?()
        }
    }

    func signOut() {
        tokens = nil; email = ""; isSignedIn = false
        SecureStore.delete(key: key)
        onSignedOut?()
    }

    /// 서버 요청에 쓸 ID 토큰. 만료 직전이면 자동으로 갱신
    func idToken() async -> String? {
        guard var t = await MainActor.run(body: { self.tokens }) else { return nil }
        if t.expiresAt.timeIntervalSinceNow < 60 {
            do {
                t = try await auth.refresh(refreshToken: t.refreshToken)
                await MainActor.run { self.tokens = t; self.persist() }
            } catch AuthError.sessionExpired {
                await MainActor.run { self.signOut() }
                return nil
            } catch { return nil }
        }
        return t.idToken
    }

    private func clean(_ s: String) -> String { s.trimmingCharacters(in: .whitespaces).lowercased() }

    private func persist() {
        guard let t = tokens, let data = try? JSONEncoder().encode(Saved(email: email, tokens: t)) else { return }
        SecureStore.save(data, key: key)
    }
}

// ── 앱 전체에서 쓰는 객체를 한곳에서 조립 ──
final class AppContainer: ObservableObject {
    let session: SessionStore
    let store: TimerStore
    let profile: ProfileStore

    init() {
        let auth: AuthAPI = AppConfig.useMockAuth
            ? MockAuth()
            : CognitoAuth(region: AppConfig.region, clientId: AppConfig.cognitoClientId)
        let s = SessionStore(auth: auth, isMock: AppConfig.useMockAuth)

        let api: StudyAPI = AppConfig.useMockAPI
            ? MockAPI()
            : RemoteAPI(baseURL: URL(string: AppConfig.apiBaseURL)!, tokenProvider: { await s.idToken() })
        let st = TimerStore(api: api)
        let pf = ProfileStore(api: api)

        st.canSendPresence = { s.isSignedIn }
        s.onSignedIn = { st.syncPending(); st.pushSubjects(); Task { await pf.load() } }   // 로그인하면 밀린 기록 업로드 + 프로필 불러오기
        s.onSignedOut = { Task { await pf.clear() } }
        if s.isSignedIn { Task { await pf.load() } }

        session = s
        store = st
        profile = pf
    }
}
