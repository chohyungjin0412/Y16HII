import SwiftUI

// 내 프로필(서버 저장). 로그인하면 불러오고, 로그아웃하면 비움
final class ProfileStore: ObservableObject {
    @Published var me: MyProfile?
    @Published var loading = false
    @Published var loadError: String?
    let api: StudyAPI

    init(api: StudyAPI) { self.api = api }

    var isComplete: Bool { me?.profileComplete == true }

    @MainActor func load() async {
        loading = true
        do { me = try await api.fetchMe(); loadError = nil }
        catch { loadError = errorText(error) }
        loading = false
    }

    @MainActor func save(_ update: ProfileUpdate) async throws {
        me = try await api.saveMe(update)
    }

    @MainActor func setPrivacy(_ change: (inout Privacy) -> Void) async {
        guard var p = me?.privacy else { return }
        change(&p)
        do { me = try await api.saveMe(ProfileUpdate(privacy: p)) } catch { loadError = errorText(error) }
    }

    @MainActor func clear() { me = nil; loadError = nil }
}
