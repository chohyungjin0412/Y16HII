import SwiftUI
import UserNotifications

/// 서버에 아직 전달하지 못한 '측정 종료' 신호. 인터넷이 돌아오면 순서대로 다시 보냄
struct PendingStop: Codable, Hashable {
    var sessionId: String
    var endMs: Double          // 서버 시계 기준 종료 시각(epoch 밀리초)
}

final class TimerStore: ObservableObject {
    @Published var subjects: [Subject] = []
    @Published var records: [StudyRecord] = []
    @Published var runningSubjectId: Int?
    @Published var runningStart: Date?
    /// 서버 측정 세션 번호. nil이면 이 기기에서만 재는 중 (오프라인 모드 또는 로그인 안 함)
    @Published var runningSessionId: String?

    /// 켜면 측정 중에 서버와 연결하지 않고, 끝낼 때 기록만 한 번에 보냄
    @Published var offlineMode = false { didSet { if loaded && offlineMode != oldValue { save() } } }

    // 새벽 4시 확인 팝업 / 알림
    @Published var needsConfirm = false
    @Published var confirmBy: Date?
    @Published var alertMessage: String?
    @Published var isStarting = false
    @Published var pendingStops: [PendingStop] = []
    @Published var syncError: String?              // 종료 신호 전송이 실패한 이유 (화면 맨 위에 표시)

    // 뽀모도로 (과목 타이머의 부가 기능)
    @Published var pomodoroOn = false
    @Published var phase: PomodoroPhase = .focus
    @Published var phaseEnd: Date?
    let focusMinutes = 25
    let restMinutes = 5

    let api: StudyAPI
    var canSendPresence: () -> Bool = { false }   // 로그인했을 때만 서버 측정을 씀 (이름은 예전 그대로)
    private var loaded = false
    private var lastPoll = Date.distantPast
    private var flushing = false
    private var opGen = 0                          // 시작/종료를 누를 때마다 올림: 늦게 도착한 옛 응답을 무시하기 위함
    private var clockOffset: TimeInterval = 0      // (서버 시계 - 기기 시계)
    private var confirmedAt: Date?
    private var nextSubjectId = 1
    private let fileURL: URL

    private struct Running: Codable {
        var subjectId: Int
        var start: Date
        var sessionId: String?
    }
    private struct Saved: Codable {
        var subjects: [Subject]
        var records: [StudyRecord]
        var nextSubjectId: Int
        var offlineMode: Bool?
        var pendingStops: [PendingStop]?
        var running: Running?
    }

    init(api: StudyAPI) {
        self.api = api
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = dir.appendingPathComponent("study_state.json")
        load()
        loaded = true
        syncPending()
    }

    // MARK: 타이머
    /// 서버 측정이면 서버가 '시작 신호'를 받아 상태를 바꾼 뒤에야 측정 화면이 뜸 (인터넷이 없으면 안내 팝업)
    func start(_ subjectId: Int) {
        guard !isStarting else { return }
        if runningSubjectId != nil { stop() }
        opGen += 1
        if offlineMode || !canSendPresence() {
            beginRunning(subjectId: subjectId, start: Date(), sessionId: nil)
            return
        }
        isStarting = true
        Task {
            // 앞선 종료 신호가 남아 있으면 먼저 보냄 (순서가 뒤바뀌지 않게)
            await self.flushPendingStopsAsync()
            let blocked = await MainActor.run { !self.pendingStops.isEmpty }
            if blocked {
                await MainActor.run {
                    self.isStarting = false
                    self.alertMessage = "이전 측정의 종료 신호를 아직 서버에 보내지 못했어요. 인터넷 연결을 확인한 뒤 다시 시작해 주세요."
                }
                return
            }
            do {
                let st = try await self.api.startSession(subjectId: subjectId)
                await MainActor.run { self.isStarting = false; self.apply(st) }
            } catch {
                await MainActor.run { self.isStarting = false; self.alertMessage = self.startFailText(error) }
            }
        }
    }

    func stop() {
        guard let id = runningSubjectId, let s = runningStart else { return }
        opGen += 1
        let end = Date()
        let sid = runningSessionId
        appendRecord(subjectId: id, start: s, end: end, synced: sid != nil)   // 서버 측정은 서버가 따로 기록하므로 다시 올리지 않음
        clearRunning()
        if let sid = sid {
            pendingStops.append(PendingStop(sessionId: sid, endMs: (end.timeIntervalSince1970 + clockOffset) * 1000))
            save()
            flushPendingStops()
        } else {
            save()
            syncPending()
        }
    }

    /// 매초 호출 (화면의 1초 타이머에서)
    func tick(_ now: Date) {
        guard runningSubjectId != nil else { return }
        // 서버 상태 확인: 30초마다, 그리고 새벽 4시를 넘긴 직후
        if runningSessionId != nil, let start = runningStart {
            let since = now.timeIntervalSince(lastPoll)
            let boundary = DayBoundary.nextBoundary(after: confirmedAt ?? start)
            if since >= 30 || (!needsConfirm && now >= boundary && since >= 5) { refreshSession() }
        }
        if !pomodoroOn {
            if phaseEnd != nil { phaseEnd = nil; Notifier.cancel() }
            return
        }
        if phaseEnd == nil { beginPhase(.focus, now) }
        else if let end = phaseEnd, now >= end { beginPhase(phase == .focus ? .rest : .focus, now) }
    }

    private func beginPhase(_ p: PomodoroPhase, _ now: Date) {
        phase = p
        let minutes = (p == .focus) ? focusMinutes : restMinutes
        let end = now.addingTimeInterval(Double(minutes) * 60)
        phaseEnd = end
        Notifier.schedule(at: end,
                          title: p == .focus ? "휴식 끝! 다시 집중" : "집중 끝! 잠깐 쉬어요",
                          body: "스터디투게더")
    }

    private func beginRunning(subjectId: Int, start: Date, sessionId: String?) {
        runningSubjectId = subjectId
        runningStart = start
        runningSessionId = sessionId
        phaseEnd = nil          // tick에서 뽀모도로 시작
        needsConfirm = false
        confirmBy = nil
        confirmedAt = nil
        save()
    }

    private func clearRunning() {
        runningSubjectId = nil
        runningStart = nil
        runningSessionId = nil
        phaseEnd = nil
        needsConfirm = false
        confirmBy = nil
        confirmedAt = nil
        Notifier.cancel()
    }

    private func appendRecord(subjectId: Int, start: Date, end: Date, synced: Bool) {
        var raw = StudyRecord(subjectId: subjectId, start: start, end: max(start, end))
        raw.synced = synced
        records.append(contentsOf: DayBoundary.split(raw).filter { $0.seconds > 0 })
    }

    // MARK: 서버 측정 상태 (서버가 진실, 기기는 신호만 보냄)
    /// 앱을 켤 때 / 로그인할 때 / 앞으로 돌아올 때 / 측정 중 30초마다 서버의 현재 상태를 받아 맞춤.
    /// 마지막 상태가 '공부 중'이었다면 앱을 껐다 켜도 계속 공부 중으로 보임
    func refreshSession() {
        guard canSendPresence(), !isStarting else { return }
        if runningSubjectId != nil && runningSessionId == nil { return }   // 이 기기에서만 재는 중이면 서버와 무관
        lastPoll = Date()
        let gen = opGen
        Task {
            await self.flushPendingStopsAsync()
            let busy = await MainActor.run { !self.pendingStops.isEmpty || self.isStarting }
            if busy { return }
            do {
                let st = try await self.api.fetchSession()
                await MainActor.run { if gen == self.opGen { self.apply(st) } }   // 그 사이 시작/종료를 눌렀다면 옛 응답은 버림
            } catch { /* 다음 확인 때 다시 */ }
        }
    }

    /// 새벽 4시 팝업에 대한 답: keep=true면 계속 공부 중(오늘 첫 기록은 4시부터), false면 4시에 끝냄
    func answerConfirm(keep: Bool) {
        needsConfirm = false
        opGen += 1
        Task {
            do {
                let st = try await self.api.confirmSession(keep: keep)
                await MainActor.run {
                    if keep { self.confirmedAt = Date() }
                    self.apply(st)
                }
            } catch {
                await MainActor.run { self.needsConfirm = true }   // 전달 실패: 팝업을 다시 보여줌
            }
        }
    }

    /// 서버가 알려준 상태를 이 기기에 반영 (항상 메인 스레드에서 호출)
    private func apply(_ st: SessionState) {
        clockOffset = st.serverNowMs / 1000 - Date().timeIntervalSince1970
        if st.active, let s = st.session {
            let canAdopt = runningSubjectId == nil || runningSessionId != nil
            if runningSessionId != s.id && canAdopt {
                if runningSessionId != nil { clearRunning() }   // 다른 세션으로 바뀜: 옛 것은 버림
                runningSubjectId = s.subjectId
                runningSessionId = s.id
                runningStart = Date(timeIntervalSince1970: s.startedAtMs / 1000 - clockOffset)
                phaseEnd = nil
            }
            if runningSessionId == s.id {
                needsConfirm = s.needsConfirm
                confirmBy = s.confirmByMs.map { Date(timeIntervalSince1970: $0 / 1000 - clockOffset) }
            }
        } else if let sid = runningSessionId, let id = runningSubjectId, let start = runningStart {
            // 서버에는 진행 중인 세션이 없음: 서버가 끝낸 것
            if let e = st.ended, e.id == sid {
                let serverEnd = Date(timeIntervalSince1970: e.endAt / 1000 - clockOffset)
                appendRecord(subjectId: id, start: start, end: min(Date(), serverEnd), synced: true)
                if e.reason == "timeout" {
                    alertMessage = "새벽 4시 이후 확인이 없어서 4시에 측정이 끝났어요. 4시부터의 시간은 기록되지 않았어요."
                }
            }
            clearRunning()
        }
        save()
    }

    private func startFailText(_ e: Error) -> String {
        if e is URLError {
            return "인터넷에 연결되어 있지 않아서 측정을 시작할 수 없어요. 연결을 확인하거나, 오프라인 측정 모드를 켜고 시작해 주세요."
        }
        return errorText(e)
    }

    // MARK: 종료 신호 재전송
    func flushPendingStops() { Task { await flushPendingStopsAsync() } }

    /// 보내지 못한 종료 신호를 순서대로 보냄. 이미 다른 곳에서 보내는 중이면 끝날 때까지 기다림
    private func flushPendingStopsAsync() async {
        while true {
            let action = await MainActor.run { () -> Int in
                if self.pendingStops.isEmpty { return 0 }       // 보낼 것 없음
                if self.flushing { return 1 }                   // 다른 곳에서 전송 중
                self.flushing = true
                return 2                                        // 내가 보냄
            }
            if action == 0 { return }
            if action == 1 { try? await Task.sleep(nanoseconds: 200_000_000); continue }
            await sendPendingStops()
            await MainActor.run { self.flushing = false }
            return
        }
    }

    private func sendPendingStops() async {
        while true {
            guard let op = await MainActor.run(body: { self.pendingStops.first }) else { return }
            do {
                _ = try await api.stopSession(sessionId: op.sessionId, endMs: op.endMs)
                await MainActor.run { self.syncError = nil }
            } catch APIError.decoding {
                // 서버는 종료를 처리했고 응답 모양만 읽지 못한 것: 전달된 것으로 봄
            } catch {
                let text = describe(error)
                await MainActor.run { self.syncError = text }
                if shouldRetry(error) { return }               // 인터넷/로그인/서버 문제: 나중에 다시
            }
            await MainActor.run {
                if !self.pendingStops.isEmpty { self.pendingStops.removeFirst() }
                self.save()
            }
        }
    }

    private func describe(_ e: Error) -> String {
        if let u = e as? URLError { return "인터넷 연결 문제 (\(u.code.rawValue))" }
        if let a = e as? APIError {
            switch a {
            case .badStatus(let c): return "서버 응답 오류 (\(c))"
            case .server(let m): return "서버가 거절함: \(m)"
            case .decoding: return "서버 응답을 읽을 수 없음"
            }
        }
        return errorText(e)
    }

    private func shouldRetry(_ e: Error) -> Bool {
        if e is URLError { return true }
        if let a = e as? APIError, case .badStatus = a { return true }
        return false
    }

    // MARK: 집계 (진행 중인 기록도 포함, 새벽 4시 기준 날짜)
    func allRecords(now: Date) -> [StudyRecord] {
        var all = records
        if let id = runningSubjectId, let s = runningStart {
            all += DayBoundary.split(StudyRecord(subjectId: id, start: s, end: now))
        }
        return all
    }

    func seconds(on day: String, now: Date) -> Int {
        allRecords(now: now)
            .filter { DayBoundary.studyDay(of: $0.start) == day }
            .reduce(0) { $0 + $1.seconds }
    }

    func seconds(subject: Int, on day: String, now: Date) -> Int {
        allRecords(now: now)
            .filter { $0.subjectId == subject && DayBoundary.studyDay(of: $0.start) == day }
            .reduce(0) { $0 + $1.seconds }
    }

    // MARK: 과목
    func addSubject(name: String, colorHex: String) {
        subjects.append(Subject(id: nextSubjectId, name: name, colorHex: colorHex, order: subjects.count))
        nextSubjectId += 1
        save()
        pushSubjects()
    }

    /// 보관: 이름·색·순서는 지우고, 기록에는 과목 번호만 남음
    func archiveSubject(id: Int) {
        if runningSubjectId == id { stop() }
        subjects.removeAll { $0.id == id }
        save()
        pushSubjects()
    }

    // MARK: 서버 동기화 (오프라인이면 다음 기회에 재시도)
    /// 오프라인 모드로 잰 기록처럼 아직 서버에 없는 기록을 한 번에 보냄
    func syncPending() {
        let pending = records.filter { !$0.synced }
        guard !pending.isEmpty, canSendPresence() else { return }
        let ids = Set(pending.map(\.id))
        Task {
            do {
                try await self.api.upload(records: pending)
                await MainActor.run {
                    for i in self.records.indices where ids.contains(self.records[i].id) {
                        self.records[i].synced = true
                    }
                    self.save()
                }
            } catch { /* 다음 실행/종료/앞으로 돌아올 때 재시도 */ }
        }
    }

    func pushSubjects() {
        let list = subjects
        Task { try? await self.api.syncSubjects(list) }
    }

    // MARK: 로컬 저장
    private func save() {
        var running: Running? = nil
        if let id = runningSubjectId, let st = runningStart {
            running = Running(subjectId: id, start: st, sessionId: runningSessionId)
        }
        let s = Saved(subjects: subjects, records: records, nextSubjectId: nextSubjectId,
                      offlineMode: offlineMode, pendingStops: pendingStops, running: running)
        try? JSONEncoder().encode(s).write(to: fileURL, options: .atomic)
    }

    private func load() {
        if let data = try? Data(contentsOf: fileURL),
           let s = try? JSONDecoder().decode(Saved.self, from: data) {
            subjects = s.subjects; records = s.records; nextSubjectId = s.nextSubjectId
            offlineMode = s.offlineMode ?? false
            pendingStops = s.pendingStops ?? []
            if let r = s.running {                     // 앱을 껐다 켜도 재던 중이던 측정을 이어감
                runningSubjectId = r.subjectId; runningStart = r.start; runningSessionId = r.sessionId
            }
        } else {
            subjects = [Subject(id: 1, name: "국어", colorHex: "#FF6B6B", order: 0),
                        Subject(id: 2, name: "수학", colorHex: "#4D96FF", order: 1),
                        Subject(id: 3, name: "영어", colorHex: "#6BCB77", order: 2)]
            nextSubjectId = 4
        }
    }
}

// 뽀모도로 알림 (Swift Playgrounds에서 안 오면 앱 내 표시만으로 대체)
enum Notifier {
    static func requestAuth() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }
    static func schedule(at date: Date, title: String, body: String) {
        let c = UNMutableNotificationContent()
        c.title = title; c.body = body; c.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, date.timeIntervalSinceNow), repeats: false)
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["pomodoro"])
        center.add(UNNotificationRequest(identifier: "pomodoro", content: c, trigger: trigger))
    }
    static func cancel() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["pomodoro"])
    }
}
