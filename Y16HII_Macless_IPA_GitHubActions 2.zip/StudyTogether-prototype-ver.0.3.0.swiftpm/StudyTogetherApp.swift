import SwiftUI

@main
struct StudyTogetherApp: App {
    @StateObject private var app = AppContainer()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(app.store)
                .environmentObject(app.session)
                .environmentObject(app.profile)
                .preferredColorScheme(.light)   // Figma 시안은 라이트 모드만 있음
        }
    }
}

struct RootView: View {
    var body: some View {
        TabView {
            TimerView().tabItem { Label("타이머", systemImage: "timer") }
            AuthGate("커뮤니티") { CommunityView() }.tabItem { Label("커뮤니티", systemImage: "person.3") }
            AuthGate("친구") { FriendsView() }.tabItem { Label("친구", systemImage: "person.2") }
            ProfileView().tabItem { Label("프로필", systemImage: "person.crop.circle") }
        }
        .tint(Theme.accent)
        .toolbarBackground(Theme.surface, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
    }
}
