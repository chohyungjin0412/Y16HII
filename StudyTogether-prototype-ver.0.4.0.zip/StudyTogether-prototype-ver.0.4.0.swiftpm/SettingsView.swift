import SwiftUI

// ───────── 설정 탭 ─────────
// 지금은 연결 상태만 있고 나머지는 비어 있음. 항목이 생기면 아래 VStack에 카드를 추가하면 됨.
struct SettingsView: View {
    private var serverText: String {
        AppConfig.useMockAPI ? "테스트 모드 (가짜 데이터)" : "실서버 (\(AppConfig.region))"
    }
    private var loginText: String {
        AppConfig.useMockAuth ? "테스트 모드 (인증 코드 123456)" : "실서버 (Cognito)"
    }

    var body: some View {
        ScreenScaffold("설정") {
            VStack(spacing: 0) {
                infoRow("서버", serverText)
                Divider1()
                infoRow("로그인", loginText)
            }
            .card()

            // 앱 버전: AppConfig.swift 의 appVersion 값이 그대로 표시됨
            Text("Ver. \(AppConfig.appVersion)")
                .font(.system(size: 12))
                .foregroundColor(Theme.faint)
                .frame(maxWidth: .infinity)
                .padding(.top, 24)
        }
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).font(.system(size: 16)).foregroundColor(Theme.textPrimary)
            Spacer()
            Text(value).font(.system(size: 14)).foregroundColor(Theme.textSecondary)
        }
        .frame(height: 48)
    }
}
