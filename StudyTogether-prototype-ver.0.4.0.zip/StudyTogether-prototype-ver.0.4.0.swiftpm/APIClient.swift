import Foundation

// 서버 오류를 사용자에게 보여줄 문장으로
func errorText(_ error: Error) -> String {
    if let e = error as? LocalizedError, let d = e.errorDescription { return d }
    if error is URLError { return "네트워크 연결을 확인해 주세요." }
    return "오류가 발생했어요. 잠시 후 다시 해 주세요."
}

enum APIError: LocalizedError {
    case server(String)
    case badStatus(Int)
    case decoding

    var errorDescription: String? {
        switch self {
        case .server(let m): return m
        case .badStatus(let c): return c == 401 ? "로그인이 만료됐어요. 다시 로그인해 주세요." : "서버 오류가 발생했어요. (\(c))"
        case .decoding: return "서버 응답을 읽을 수 없어요."
        }
    }
}

// 앱 ↔ 서버 경계. UI/Store는 이 프로토콜만 알면 됨 (Mock ↔ 실서버 교체 쉬움)
protocol StudyAPI {
    // 기록
    func upload(records: [StudyRecord]) async throws
    func syncSubjects(_ subjects: [Subject]) async throws
    // 측정 세션: 상태는 서버가 가지고, 기기는 신호만 보냄
    func fetchSession() async throws -> SessionState
    func startSession(subjectId: Int) async throws -> SessionState
    func stopSession(sessionId: String?, endMs: Double?) async throws -> SessionState
    func confirmSession(keep: Bool) async throws -> SessionState
    // 통계: 날짜 범위의 하루 합계 (서버에 올라간 기록)
    func fetchDaily(from: String, to: String) async throws -> [DailyStat]
    // 프로필
    func fetchMe() async throws -> MyProfile
    func saveMe(_ update: ProfileUpdate) async throws -> MyProfile
    // 친구
    func fetchFriends() async throws -> [FriendInfo]
    func requestFriend(code: String) async throws
    func acceptFriend(id: String) async throws
    func removeFriend(id: String) async throws
    // 방
    func fetchRooms() async throws -> [Room]
    func fetchRoom(id: String) async throws -> RoomDetail
    func createRoom(name: String, official: Bool, gender: String?) async throws -> Room
    func joinRoom(roomId: String?, inviteCode: String?) async throws -> Room
    func leaveRoom(id: String) async throws
    // 차단 / 신고
    func block(userId: String) async throws
    func unblock(userId: String) async throws
    func fetchBlocks() async throws -> [BlockedUser]
    func report(userId: String, reason: String, detail: String, roomId: String?) async throws
}

// ── 서버 없이 화면 확인용 (앱을 끄면 초기화됨) ──
// 시험용 값: 친구 코드 TESTCODE → 친구 요청 보내짐, 초대 코드 ABC123 → 방 입장
actor MockAPI: StudyAPI {
    private var mockSession: (id: String, subjectId: Int, startMs: Double)?
    private var me = MyProfile(userId: "me", email: "mock@test.com", friendCode: "MOCK1234", nickname: nil,
                               birthYear: nil, gender: nil, realName: nil, privacy: Privacy(),
                               ageGroup: "unknown", isAdmin: false, profileComplete: false)
    private var friends: [FriendInfo] = [
        FriendInfo(id: "f1", nickname: "새벽반", ageLabel: "나이: 무럭무럭 자라는중", status: "friends", todaySeconds: 7200, studying: true),
        FriendInfo(id: "f2", nickname: "뽀모러", ageLabel: nil, status: "pending_in", todaySeconds: 0, studying: false),
    ]
    private var rooms: [Room] = [
        Room(id: "r1", name: "남자 전체", type: "official", memberCount: 128, maxMembers: 100, joined: false, gender: nil, inviteCode: nil),
        Room(id: "r2", name: "예시 방", type: "private", memberCount: 3, maxMembers: 30, joined: true, gender: nil, inviteCode: "ABC123"),
    ]
    private var blocked: [BlockedUser] = []
    private let names = ["f1": "새벽반", "f2": "뽀모러", "f3": "테스트친구", "x1": "올빼미"]   // 테스트 모드 사용자 이름

    func upload(records: [StudyRecord]) async throws {}
    func syncSubjects(_ subjects: [Subject]) async throws {}

    // 테스트 모드의 측정 세션 (앱을 끄면 초기화됨)
    private func nowMs() -> Double { Date().timeIntervalSince1970 * 1000 }
    private func state(ended: EndedInfo? = nil, recorded: Int? = nil) -> SessionState {
        let info = mockSession.map { SessionInfo(id: $0.id, subjectId: $0.subjectId, startedAtMs: $0.startMs,
                                                 needsConfirm: false, confirmByMs: nil) }
        return SessionState(serverNowMs: nowMs(), active: info != nil, session: info,
                            ended: info == nil ? ended : nil, recordedSeconds: recorded)
    }
    func fetchSession() async throws -> SessionState { state() }
    func startSession(subjectId: Int) async throws -> SessionState {
        if mockSession?.subjectId != subjectId { mockSession = (UUID().uuidString, subjectId, nowMs()) }
        return state()
    }
    func stopSession(sessionId: String?, endMs: Double?) async throws -> SessionState {
        guard let cur = mockSession, sessionId == nil || sessionId == cur.id else { return state() }
        let end = min(endMs ?? nowMs(), nowMs())
        mockSession = nil
        return state(ended: EndedInfo(id: cur.id, endAt: end, reason: "stopped"),
                     recorded: max(0, Int((end - cur.startMs) / 1000)))
    }
    func confirmSession(keep: Bool) async throws -> SessionState { state() }
    func fetchDaily(from: String, to: String) async throws -> [DailyStat] { [] }

    func fetchMe() async throws -> MyProfile { me }
    func saveMe(_ u: ProfileUpdate) async throws -> MyProfile {
        if let n = u.nickname { me.nickname = n }
        if let y = u.birthYear { me.birthYear = y }
        if let g = u.gender { me.gender = g }
        if let r = u.realName { me.realName = r }
        if let p = u.privacy { me.privacy = p }
        me.profileComplete = me.nickname != nil && me.birthYear != nil && me.gender != nil
        if let y = me.birthYear {
            let age = Calendar.current.component(.year, from: Date()) - y
            me.ageGroup = age <= 15 ? "under16" : (age <= 18 ? "high" : "adult")
        }
        return me
    }

    func fetchFriends() async throws -> [FriendInfo] { friends }
    func requestFriend(code: String) async throws {
        guard code.uppercased() == "TESTCODE" else { throw APIError.server("친구 코드를 찾을 수 없어요.") }
        guard !friends.contains(where: { $0.id == "f3" }) else { throw APIError.server("이미 요청을 보냈어요.") }
        friends.append(FriendInfo(id: "f3", nickname: "테스트친구", ageLabel: nil, status: "pending_out", todaySeconds: 0, studying: false))
    }
    func acceptFriend(id: String) async throws {
        if let i = friends.firstIndex(where: { $0.id == id }) { friends[i].status = "friends" }
    }
    func removeFriend(id: String) async throws { friends.removeAll { $0.id == id } }

    func fetchRooms() async throws -> [Room] { rooms }
    func fetchRoom(id: String) async throws -> RoomDetail {
        guard let r = rooms.first(where: { $0.id == id && $0.joined }) else { throw APIError.server("방을 찾을 수 없어요.") }
        let members = [
            RoomMember(id: "f1", nickname: "새벽반", ageLabel: "나이: 무럭무럭 자라는중", gender: nil, todaySeconds: 21600, studying: true, isFriend: true, isMe: false),
            RoomMember(id: "me", nickname: me.nickname ?? "나", ageLabel: nil, gender: nil, todaySeconds: 14400, studying: false, isFriend: false, isMe: true),
            RoomMember(id: "x1", nickname: "올빼미", ageLabel: nil, gender: nil, todaySeconds: 9000, studying: false, isFriend: false, isMe: false),
        ]
        return RoomDetail(room: r, members: members.filter { m in !blocked.contains(where: { $0.id == m.id }) })
    }
    func createRoom(name: String, official: Bool, gender: String?) async throws -> Room {
        let r = Room(id: UUID().uuidString, name: name, type: official ? "official" : "private", memberCount: 1,
                     maxMembers: official ? 100 : 30, joined: true, gender: gender, inviteCode: official ? nil : "NEW123")
        rooms.append(r); return r
    }
    func joinRoom(roomId: String?, inviteCode: String?) async throws -> Room {
        if let code = inviteCode, code.uppercased() != "ABC123" { throw APIError.server("방을 찾을 수 없어요.") }
        let id = roomId ?? "r2"
        guard let i = rooms.firstIndex(where: { $0.id == id }) else { throw APIError.server("방을 찾을 수 없어요.") }
        rooms[i].joined = true
        return rooms[i]
    }
    func leaveRoom(id: String) async throws {
        if let i = rooms.firstIndex(where: { $0.id == id }) { rooms[i].joined = false }
    }

    func block(userId: String) async throws {
        if !blocked.contains(where: { $0.id == userId }) {
            blocked.append(BlockedUser(id: userId, nickname: names[userId] ?? "알 수 없음"))
        }
        friends.removeAll { $0.id == userId }
    }
    func unblock(userId: String) async throws { blocked.removeAll { $0.id == userId } }
    func fetchBlocks() async throws -> [BlockedUser] { blocked }
    func report(userId: String, reason: String, detail: String, roomId: String?) async throws {}
}

// ── 실서버(API Gateway + Lambda) 연결. Cognito 토큰은 tokenProvider로 주입 ──
struct RemoteAPI: StudyAPI {
    var baseURL: URL
    var tokenProvider: () async -> String?

    private var encoder: JSONEncoder { let e = JSONEncoder(); e.dateEncodingStrategy = .iso8601; return e }
    private var decoder: JSONDecoder { JSONDecoder() }

    private func send(_ method: String, _ path: String, body: Data? = nil, query: [URLQueryItem] = []) async throws -> Data {
        var comps = URLComponents(url: baseURL.appendingPathComponent(path), resolvingAgainstBaseURL: false)
        if !query.isEmpty { comps?.queryItems = query }
        var req = URLRequest(url: comps?.url ?? baseURL.appendingPathComponent(path))
        req.httpMethod = method
        req.httpBody = body
        req.timeoutInterval = 20
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let t = await tokenProvider() { req.setValue("Bearer \(t)", forHTTPHeaderField: "Authorization") }
        let (data, resp) = try await URLSession.shared.data(for: req)
        if let code = (resp as? HTTPURLResponse)?.statusCode, !(200..<300).contains(code) {
            // 5xx는 나중에 다시 시도할 수 있는 오류로 구분 (종료 신호 재전송 판단에 씀)
            if code < 500, let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let m = obj["error"] as? String {
                throw APIError.server(m)
            }
            throw APIError.badStatus(code)
        }
        return data
    }

    private func json(_ dict: [String: Any]) throws -> Data { try JSONSerialization.data(withJSONObject: dict) }

    private func decode<T: Decodable>(_ type: T.Type, _ data: Data) throws -> T {
        do { return try decoder.decode(type, from: data) } catch { throw APIError.decoding }
    }

    // 기록
    func upload(records: [StudyRecord]) async throws {
        _ = try await send("POST", "records", body: try encoder.encode(records))
    }
    func syncSubjects(_ subjects: [Subject]) async throws {
        _ = try await send("PUT", "subjects", body: try encoder.encode(subjects))
    }
    func fetchSession() async throws -> SessionState {
        try decode(SessionState.self, try await send("GET", "session"))
    }
    func startSession(subjectId: Int) async throws -> SessionState {
        try decode(SessionState.self, try await send("POST", "session/start", body: try json(["subjectId": subjectId])))
    }
    func stopSession(sessionId: String?, endMs: Double?) async throws -> SessionState {
        var d: [String: Any] = [:]
        if let s = sessionId { d["sessionId"] = s }
        if let e = endMs { d["endMs"] = e }
        return try decode(SessionState.self, try await send("POST", "session/stop", body: try json(d)))
    }
    func confirmSession(keep: Bool) async throws -> SessionState {
        try decode(SessionState.self, try await send("POST", "session/confirm", body: try json(["keep": keep])))
    }

    private struct DailyBody: Decodable { var days: [DailyStat] }
    func fetchDaily(from: String, to: String) async throws -> [DailyStat] {
        let q = [URLQueryItem(name: "from", value: from), URLQueryItem(name: "to", value: to)]
        return try decode(DailyBody.self, try await send("GET", "daily", query: q)).days
    }

    // 프로필
    func fetchMe() async throws -> MyProfile { try decode(MyProfile.self, try await send("GET", "me")) }
    func saveMe(_ update: ProfileUpdate) async throws -> MyProfile {
        try decode(MyProfile.self, try await send("PUT", "me", body: try encoder.encode(update)))
    }

    // 친구
    private struct FriendsBody: Decodable { var friends: [FriendInfo] }
    func fetchFriends() async throws -> [FriendInfo] { try decode(FriendsBody.self, try await send("GET", "friends")).friends }
    func requestFriend(code: String) async throws { _ = try await send("POST", "friends", body: try json(["friendCode": code])) }
    func acceptFriend(id: String) async throws { _ = try await send("POST", "friends/\(id)/accept") }
    func removeFriend(id: String) async throws { _ = try await send("DELETE", "friends/\(id)") }

    // 방
    private struct RoomsBody: Decodable { var rooms: [Room] }
    private struct RoomBody: Decodable { var room: Room }
    func fetchRooms() async throws -> [Room] { try decode(RoomsBody.self, try await send("GET", "rooms")).rooms }
    func fetchRoom(id: String) async throws -> RoomDetail { try decode(RoomDetail.self, try await send("GET", "rooms/\(id)/members")) }
    func createRoom(name: String, official: Bool, gender: String?) async throws -> Room {
        var d: [String: Any] = ["name": name, "type": official ? "official" : "private"]
        if let g = gender { d["gender"] = g }
        return try decode(RoomBody.self, try await send("POST", "rooms", body: try json(d))).room
    }
    func joinRoom(roomId: String?, inviteCode: String?) async throws -> Room {
        var d: [String: Any] = [:]
        if let r = roomId { d["roomId"] = r }
        if let c = inviteCode { d["inviteCode"] = c }
        return try decode(RoomBody.self, try await send("POST", "rooms/join", body: try json(d))).room
    }
    func leaveRoom(id: String) async throws { _ = try await send("DELETE", "rooms/\(id)/members/me") }

    // 차단 / 신고
    private struct BlocksBody: Decodable { var blocked: [BlockedUser] }
    func block(userId: String) async throws { _ = try await send("POST", "blocks", body: try json(["userId": userId])) }
    func unblock(userId: String) async throws { _ = try await send("DELETE", "blocks/\(userId)") }
    func fetchBlocks() async throws -> [BlockedUser] { try decode(BlocksBody.self, try await send("GET", "blocks")).blocked }
    func report(userId: String, reason: String, detail: String, roomId: String?) async throws {
        var d: [String: Any] = ["userId": userId, "reason": reason, "detail": detail]
        if let r = roomId { d["roomId"] = r }
        _ = try await send("POST", "reports", body: try json(d))
    }
}
