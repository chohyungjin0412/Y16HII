import SwiftUI

// 측정 화면: 전체 화면으로 덮어서 하단 탭 바가 보이지 않음.
// TimerView에서 runningSubjectId가 생기면 자동으로 뜨고, 정지하면 사라짐.
struct MeasureView: View {
    @EnvironmentObject var store: TimerStore

    private var subject: Subject? { store.subjects.first { $0.id == store.runningSubjectId } }

    var body: some View {
        // TimelineView: 1초마다 화면을 다시 그림. 부모 화면이 다시 그려져도 멈추지 않음
        TimelineView(.periodic(from: Date(), by: 1)) { context in
            content(now: context.date)
        }
        .background(Theme.bg.ignoresSafeArea())
        .alert("새벽 4시가 지났어요", isPresented: Binding(get: { store.needsConfirm }, set: { _ in })) {
            Button("계속 공부 중") { store.answerConfirm(keep: true) }
            Button("4시에 끝내기", role: .destructive) { store.answerConfirm(keep: false) }
        } message: {
            Text("계속 공부하고 있었나요? \(confirmByText)까지 답하지 않으면 4시에 끝난 것으로 처리되고, 4시 이후 시간은 기록되지 않아요.")
        }
    }

    private var confirmByText: String {
        guard let d = store.confirmBy else { return "새벽 6시" }
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.string(from: d)
    }

    private func content(now: Date) -> some View {
        let elapsed = store.runningStart.map { max(0, Int(now.timeIntervalSince($0))) } ?? 0
        let todayTotal = store.seconds(on: DayBoundary.studyDay(of: now), now: now)

        return VStack(spacing: 20) {
            // 과목 칩
            HStack(spacing: 8) {
                Circle().fill(Color(hex: subject?.colorHex ?? "#4D6BFE")).frame(width: 12, height: 12)
                Text(subject?.name ?? "").font(.system(size: 18, weight: .medium)).foregroundColor(Theme.textPrimary)
            }
            .padding(.horizontal, 16).padding(.vertical, 10)
            .background(Theme.surface, in: Capsule())

            Spacer()

            VStack(spacing: 8) {
                Text("이번 공부").font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                Text(hms(elapsed)).font(.system(size: 64, weight: .bold)).monospacedDigit()
                    .foregroundColor(Theme.textPrimary).minimumScaleFactor(0.6).lineLimit(1)
                Text("오늘 총 \(hms(todayTotal))").font(.system(size: 16)).monospacedDigit()
                    .foregroundColor(Theme.textSecondary)
            }

            Spacer()

            if store.pomodoroOn { pomodoroCard(now: now) }

            Button { store.stop() } label: {
                Text("정지").font(.system(size: 18, weight: .bold)).foregroundColor(.white)
                    .frame(maxWidth: .infinity).padding(.vertical, 18)
                    .background(Theme.danger, in: RoundedRectangle(cornerRadius: 16))
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 12)
        .padding(.bottom, 24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func pomodoroCard(now: Date) -> some View {
        let total = Double((store.phase == .focus ? store.focusMinutes : store.restMinutes) * 60)
        let remaining = max(0, store.phaseEnd?.timeIntervalSince(now) ?? total)
        return VStack(spacing: 12) {
            HStack {
                Text(store.phase.rawValue).font(.system(size: 16, weight: .bold))
                    .foregroundColor(store.phase == .focus ? Theme.accent : Theme.success)
                Spacer()
                Text("남은 \(mmss(Int(remaining)))").font(.system(size: 16)).monospacedDigit()
                    .foregroundColor(Theme.textSecondary)
            }
            ProgressView(value: min(1, max(0, 1 - remaining / total))).tint(Theme.accent)
        }
        .card(vertical: 16)
    }
}
