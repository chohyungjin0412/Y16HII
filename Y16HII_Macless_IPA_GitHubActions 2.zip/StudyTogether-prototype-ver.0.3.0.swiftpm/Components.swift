import SwiftUI

// Figma 부품과 이름을 맞춤: SubjectRow / RankRow / RoomRow / ToggleRow

struct SubjectRowView: View {
    let name: String
    let colorHex: String
    let seconds: Int

    var body: some View {
        HStack(spacing: 12) {
            Circle().fill(Color(hex: colorHex)).frame(width: 12, height: 12)
            Text(name).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
            Spacer()
            Text(hms(seconds)).font(.system(size: 16)).monospacedDigit().foregroundColor(Theme.textSecondary)
            Image(systemName: "play.circle").font(.system(size: 26)).foregroundColor(Theme.accent)
        }
        .frame(height: 52)
        .contentShape(Rectangle())
    }
}

struct RankRowView: View {
    let rank: Int
    let nickname: String
    let seconds: Int
    let studying: Bool
    var subtitle: String? = nil

    var body: some View {
        HStack(spacing: 12) {
            Text("\(rank)").font(.system(size: 16, weight: .bold)).foregroundColor(Theme.accent)
                .frame(width: 24, alignment: .leading)
            VStack(alignment: .leading, spacing: 2) {
                Text(nickname).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
                if let subtitle { Text(subtitle).font(.system(size: 11)).foregroundColor(Theme.textSecondary) }
            }
            Spacer()
            if studying { Circle().fill(Theme.success).frame(width: 8, height: 8) }
            Text(hms(seconds)).font(.system(size: 16)).monospacedDigit().foregroundColor(Theme.textSecondary)
        }
        .frame(height: 52)
    }
}

struct RoomRowView: View {
    let name: String
    let count: String

    var body: some View {
        HStack(spacing: 8) {
            Text(name).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
            Spacer()
            Text(count).font(.system(size: 14)).foregroundColor(Theme.textSecondary)
            Image(systemName: "chevron.right").font(.system(size: 13, weight: .semibold)).foregroundColor(Theme.textSecondary)
        }
        .frame(height: 52)
        .contentShape(Rectangle())
    }
}

struct ToggleRowView: View {
    let label: String
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 12) {
            Text(label).font(.system(size: 16)).foregroundColor(Theme.textPrimary)
            Spacer()
            Toggle("", isOn: $isOn).labelsHidden().tint(Theme.accent)
        }
        .padding(.vertical, 6)
    }
}
