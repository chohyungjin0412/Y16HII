import Foundation

// ── 도메인 모델 (UI와 무관한 순수 Swift: 안드로이드 이식 시 그대로 설계 참고) ──

struct Subject: Identifiable, Codable, Hashable {
    var id: Int            // 과목 번호. 보관(삭제)해도 기록에는 이 번호만 남음
    var name: String
    var colorHex: String
    var order: Int
}

struct StudyRecord: Identifiable, Codable, Hashable {
    var id = UUID()
    var subjectId: Int
    var start: Date
    var end: Date
    var synced = false     // 서버 업로드 완료 여부
    var seconds: Int { max(0, Int(end.timeIntervalSince(start))) }
}

enum PomodoroPhase: String, Codable {
    case focus = "집중"
    case rest = "휴식"
}

// ── 하루 기준: 새벽 4시. 4시를 넘기는 기록은 둘로 쪼개 각 날짜에 반영 ──
enum DayBoundary {
    static let startHour = 4
    static var calendar = Calendar(identifier: .gregorian)

    /// 해당 시각이 속한 '공부 날짜' (yyyy-MM-dd)
    static func studyDay(of date: Date) -> String {
        let shifted = date.addingTimeInterval(-Double(startHour) * 3600)
        let c = calendar.dateComponents([.year, .month, .day], from: shifted)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    static func nextBoundary(after date: Date) -> Date {
        calendar.nextDate(after: date,
                          matching: DateComponents(hour: startHour, minute: 0, second: 0),
                          matchingPolicy: .nextTime) ?? date.addingTimeInterval(86400)
    }

    /// 기준 시각을 넘기면 여러 조각으로 분할
    static func split(_ r: StudyRecord) -> [StudyRecord] {
        var out: [StudyRecord] = []
        var cur = r.start
        while cur < r.end {
            let e = min(nextBoundary(after: cur), r.end)
            var part = r
            part.id = UUID()
            part.start = cur
            part.end = e
            out.append(part)
            cur = e
        }
        return out
    }
}

// ── 서버 통신용 모델 (서버가 보내는 JSON 키와 이름이 같아야 함) ──
struct Room: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var type: String              // "official" | "private"
    var memberCount: Int
    var maxMembers: Int
    var joined: Bool
    var gender: String?
    var inviteCode: String?       // 방장에게만 내려옴
}

struct RoomMember: Identifiable, Codable, Hashable {
    var id: String
    var nickname: String
    var ageLabel: String?
    var gender: String?
    var todaySeconds: Int
    var studying: Bool
    var isFriend: Bool
    var isMe: Bool
}

struct RoomDetail: Codable {
    var room: Room
    var members: [RoomMember]
}

// ── 측정 세션 (서버가 상태를 가짐. 시각은 모두 epoch 밀리초) ──
struct SessionInfo: Codable, Hashable {
    var id: String
    var subjectId: Int
    var startedAtMs: Double
    var needsConfirm: Bool        // 새벽 4시를 넘겨서 '계속 공부 중인지' 물어봐야 함
    var confirmByMs: Double?      // 이 시각(새벽 6시)까지 답이 없으면 4시에 끝난 것으로 처리
}

struct EndedInfo: Codable, Hashable {
    var id: String
    var endAt: Double
    var reason: String            // stopped | timeout | declined
}

struct SessionState: Codable {
    var serverNowMs: Double
    var active: Bool
    var session: SessionInfo?
    var ended: EndedInfo?
    var recordedSeconds: Int?
}

/// 서버의 하루 합계. bySubject의 키는 과목 번호(문자열)
struct DailyStat: Codable, Hashable {
    var day: String               // yyyy-MM-dd (새벽 4시 기준 공부 날짜)
    var total: Int
    var bySubject: [String: Int]
}

struct Privacy: Codable, Hashable {
    var showRealName = false
    var showAge = false
    var showGender = false
    var showTimelapse = false
}

struct MyProfile: Codable, Hashable {
    var userId: String
    var email: String?
    var friendCode: String
    var nickname: String?
    var birthYear: Int?
    var gender: String?           // "male" | "female"
    var realName: String?
    var privacy: Privacy
    var ageGroup: String          // under16 | high | adult | unknown
    var isAdmin: Bool
    var profileComplete: Bool
}

/// 보낼 값만 채우면 됨 (nil은 전송되지 않음)
struct ProfileUpdate: Codable {
    var nickname: String?
    var birthYear: Int?
    var gender: String?
    var realName: String?
    var privacy: Privacy?
}

struct FriendInfo: Identifiable, Codable, Hashable {
    var id: String
    var nickname: String
    var ageLabel: String?
    var status: String            // friends | pending_in | pending_out
    var todaySeconds: Int
    var studying: Bool
}

struct BlockedUser: Identifiable, Codable, Hashable {
    var id: String
    var nickname: String
}

func hms(_ s: Int) -> String {
    String(format: "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}

func mmss(_ s: Int) -> String {
    let t = max(0, s)
    return String(format: "%02d:%02d", t / 60, t % 60)
}
