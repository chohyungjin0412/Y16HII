import SwiftUI
import UserNotifications

final class TimerStore: ObservableObject {
    @Published var subjects: [Subject] = []
    @Published var records: [StudyRecord] = []
    @Published var runningSubjectId: Int?
    @Published var runningStart: Date?

    // 뽀모도로 (과목 타이머의 부가 기능)
    @Published var pomodoroOn = false
    @Published var phase: PomodoroPhase = .focus
    @Published var phaseEnd: Date?
    let focusMinutes = 25
    let restMinutes = 5

    let api: StudyAPI
    var canSendPresence: () -> Bool = { false }   // 로그인했을 때만 '공부 중' 신호를 보냄
    private var lastBeat = Date.distantPast
    private var nextSubjectId = 1
    private let fileURL: URL

    private struct Saved: Codable {
        var subjects: [Subject]
        var records: [StudyRecord]
        var nextSubjectId: Int
    }

    init(api: StudyAPI) {
        self.api = api
        let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        fileURL = dir.appendingPathComponent("study_state.json")
        load()
        syncPending()
    }

    // MARK: 타이머
    func start(_ subjectId: Int) {
        if runningSubjectId != nil { stop() }
        runningSubjectId = subjectId
        runningStart = Date()
        phaseEnd = nil          // tick에서 뽀모도로 시작
        sendPresence(true, subjectId)
    }

    func stop() {
        guard let id = runningSubjectId, let s = runningStart else { return }
        let raw = StudyRecord(subjectId: id, start: s, end: Date())
        records.append(contentsOf: DayBoundary.split(raw).filter { $0.seconds > 0 })
        runningSubjectId = nil
        runningStart = nil
        phaseEnd = nil
        Notifier.cancel()
        save()
        // 공부 중 표시를 먼저 끄고 기록을 올림 (순서가 바뀌면 순위에서 시간이 잠깐 두 번 잡힘)
        let api = self.api
        let signedIn = canSendPresence()
        Task {
            if signedIn { try? await api.sendPresence(studying: false, subjectId: nil) }
            self.syncPending()
        }
    }

    /// 매초 호출 (화면의 1초 타이머에서)
    func tick(_ now: Date) {
        guard runningSubjectId != nil else { return }
        if now.timeIntervalSince(lastBeat) >= 60 { sendPresence(true, runningSubjectId) }   // 1분마다 신호
        if !pomodoroOn {
            if phaseEnd != nil { phaseEnd = nil; Notifier.cancel() }
            return
        }
        if phaseEnd == nil { beginPhase(.focus, now) }
        else if let end = phaseEnd, now >= end { beginPhase(phase == .focus ? .rest : .focus, now) }
    }

    private func beginPhase(_ p: PomodoroPhase, _ now: Date) {
        phase = p
        let minutes = (p == .focus) ? focusMinutes : restMinutes
        let end = now.addingTimeInterval(Double(minutes) * 60)
        phaseEnd = end
        Notifier.schedule(at: end,
                          title: p == .focus ? "휴식 끝! 다시 집중" : "집중 끝! 잠깐 쉬어요",
                          body: "스터디투게더")
    }

    private func sendPresence(_ studying: Bool, _ subjectId: Int?) {
        lastBeat = Date()
        guard canSendPresence() else { return }
        let api = self.api
        Task { try? await api.sendPresence(studying: studying, subjectId: subjectId) }
    }

    // MARK: 집계 (진행 중인 기록도 포함, 새벽 4시 기준 날짜)
    func allRecords(now: Date) -> [StudyRecord] {
        var all = records
        if let id = runningSubjectId, let s = runningStart {
            all += DayBoundary.split(StudyRecord(subjectId: id, start: s, end: now))
        }
        return all
    }

    func seconds(on day: String, now: Date) -> Int {
        allRecords(now: now)
            .filter { DayBoundary.studyDay(of: $0.start) == day }
            .reduce(0) { $0 + $1.seconds }
    }

    func seconds(subject: Int, on day: String, now: Date) -> Int {
        allRecords(now: now)
            .filter { $0.subjectId == subject && DayBoundary.studyDay(of: $0.start) == day }
            .reduce(0) { $0 + $1.seconds }
    }

    // MARK: 과목
    func addSubject(name: String, colorHex: String) {
        subjects.append(Subject(id: nextSubjectId, name: name, colorHex: colorHex, order: subjects.count))
        nextSubjectId += 1
        save()
        pushSubjects()
    }

    /// 보관: 이름·색·순서는 지우고, 기록에는 과목 번호만 남음
    func archiveSubject(id: Int) {
        if runningSubjectId == id { stop() }
        subjects.removeAll { $0.id == id }
        save()
        pushSubjects()
    }

    // MARK: 서버 동기화 (오프라인이면 다음 기회에 재시도)
    func syncPending() {
        let pending = records.filter { !$0.synced }
        guard !pending.isEmpty else { return }
        let ids = Set(pending.map(\.id))
        Task {
            do {
                try await self.api.upload(records: pending)
                await MainActor.run {
                    for i in self.records.indices where ids.contains(self.records[i].id) {
                        self.records[i].synced = true
                    }
                    self.save()
                }
            } catch { /* 다음 실행/종료 때 재시도 */ }
        }
    }

    func pushSubjects() {
        let list = subjects
        Task { try? await self.api.syncSubjects(list) }
    }

    // MARK: 로컬 저장
    private func save() {
        let s = Saved(subjects: subjects, records: records, nextSubjectId: nextSubjectId)
        try? JSONEncoder().encode(s).write(to: fileURL, options: .atomic)
    }

    private func load() {
        if let data = try? Data(contentsOf: fileURL),
           let s = try? JSONDecoder().decode(Saved.self, from: data) {
            subjects = s.subjects; records = s.records; nextSubjectId = s.nextSubjectId
        } else {
            subjects = [Subject(id: 1, name: "국어", colorHex: "#FF6B6B", order: 0),
                        Subject(id: 2, name: "수학", colorHex: "#4D96FF", order: 1),
                        Subject(id: 3, name: "영어", colorHex: "#6BCB77", order: 2)]
            nextSubjectId = 4
        }
    }
}

// 뽀모도로 알림 (Swift Playgrounds에서 안 오면 앱 내 표시만으로 대체)
enum Notifier {
    static func requestAuth() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { _, _ in }
    }
    static func schedule(at date: Date, title: String, body: String) {
        let c = UNMutableNotificationContent()
        c.title = title; c.body = body; c.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: max(1, date.timeIntervalSinceNow), repeats: false)
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: ["pomodoro"])
        center.add(UNNotificationRequest(identifier: "pomodoro", content: c, trigger: trigger))
    }
    static func cancel() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["pomodoro"])
    }
}
