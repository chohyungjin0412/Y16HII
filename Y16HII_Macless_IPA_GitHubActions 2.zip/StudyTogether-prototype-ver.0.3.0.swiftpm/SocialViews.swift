import SwiftUI
import UIKit

// ───────── 공통: 로그인/프로필 확인 후에만 보여주는 틀 ─────────
struct AuthGate<Content: View>: View {
    let title: String
    let content: Content
    @EnvironmentObject var session: SessionStore
    @EnvironmentObject var profile: ProfileStore

    init(_ title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }

    var body: some View {
        if !session.isSignedIn {
            LoginRequiredView(title: title)
        } else if profile.me == nil && profile.loadError == nil {
            ScreenScaffold(title) { ProgressView().frame(maxWidth: .infinity).padding(.top, 60) }
        } else if profile.me == nil {
            ScreenScaffold(title) {
                VStack(spacing: 12) {
                    Text(profile.loadError ?? "").font(.system(size: 14)).foregroundColor(Theme.danger)
                    PrimaryButton(title: "다시 시도") { Task { await profile.load() } }
                }
                .frame(maxWidth: .infinity).padding(.top, 60)
            }
        } else if !profile.isComplete {
            ProfileRequiredView(title: title)
        } else {
            content
        }
    }
}

struct ProfileRequiredView: View {
    let title: String
    @State private var showEditor = false

    var body: some View {
        ScreenScaffold(title) {
            VStack(spacing: 12) {
                Text("프로필을 먼저 만들어 주세요").font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
                Text("닉네임, 출생연도, 성별이 필요해요.\n출생연도와 성별은 한 번 정하면 바꿀 수 없어요.")
                    .font(.system(size: 14)).foregroundColor(Theme.textSecondary).multilineTextAlignment(.center)
                PrimaryButton(title: "프로필 만들기") { showEditor = true }.padding(.top, 8)
            }
            .frame(maxWidth: .infinity).padding(.top, 60)
        }
        .sheet(isPresented: $showEditor) { ProfileEditor() }
    }
}

// ───────── 공통: 한 줄 입력 시트 ─────────
struct InputSheet: View {
    let title: String
    let placeholder: String
    let button: String
    var uppercase = false
    let action: (String) async throws -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            ScreenScaffold(title) {
                TextField(placeholder, text: $text)
                    .textInputAutocapitalization(uppercase ? .characters : .sentences)
                    .autocorrectionDisabled()
                    .frame(height: 52)
                    .card()
                if let message { Text(message).font(.system(size: 14)).foregroundColor(Theme.danger) }
                PrimaryButton(title: button, busy: busy) { submit() }
            }
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("닫기") { dismiss() } } }
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func submit() {
        busy = true; message = nil
        Task {
            do {
                try await action(text.trimmingCharacters(in: .whitespaces))
                await MainActor.run { dismiss() }
            } catch {
                await MainActor.run { message = errorText(error) }
            }
            await MainActor.run { busy = false }
        }
    }
}

// ───────── 신고 시트 ─────────
struct ReportSheet: View {
    let userId: String
    let nickname: String
    var roomId: String? = nil
    var onDone: () -> Void = {}

    @EnvironmentObject var store: TimerStore
    @Environment(\.dismiss) private var dismiss
    @State private var reason = "abuse"
    @State private var detail = ""
    @State private var alsoBlock = true
    @State private var busy = false
    @State private var message: String?

    private let reasons = [("abuse", "욕설·비하"), ("sexual", "음란·선정적 내용"), ("harassment", "괴롭힘·스토킹"),
                           ("profile", "부적절한 프로필"), ("other", "기타")]

    var body: some View {
        NavigationStack {
            Form {
                Section("\(nickname) 님을 신고해요") {
                    Picker("사유", selection: $reason) {
                        ForEach(reasons, id: \.0) { Text($0.1).tag($0.0) }
                    }
                    TextField("자세한 내용 (선택)", text: $detail, axis: .vertical).lineLimit(3...5)
                    Toggle("신고하고 차단하기", isOn: $alsoBlock)
                }
                if let message { Text(message).foregroundColor(.red) }
            }
            .navigationTitle("신고")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("취소") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("신고") { submit() }.disabled(busy) }
            }
        }
    }

    private func submit() {
        busy = true; message = nil
        Task {
            do {
                try await store.api.report(userId: userId, reason: reason, detail: detail, roomId: roomId)
                if alsoBlock { try await store.api.block(userId: userId) }
                await MainActor.run { onDone(); dismiss() }
            } catch {
                await MainActor.run { message = errorText(error) }
            }
            await MainActor.run { busy = false }
        }
    }
}

private func smallButton(_ title: String, _ action: @escaping () -> Void) -> some View {
    Button(action: action) {
        Text(title).font(.system(size: 14, weight: .bold)).foregroundColor(Theme.accent)
            .frame(maxWidth: .infinity).padding(.vertical, 12)
            .background(Theme.surface, in: RoundedRectangle(cornerRadius: 12))
    }
}

// ───────── 커뮤니티: 방 목록 ─────────
struct CommunityView: View {
    @EnvironmentObject var store: TimerStore
    @EnvironmentObject var profile: ProfileStore
    @State private var rooms: [Room] = []
    @State private var message: String?
    @State private var showCreate = false
    @State private var showJoin = false
    @State private var showOfficial = false

    var body: some View {
        NavigationStack {
            ScreenScaffold("커뮤니티") {
                HStack(spacing: 12) {
                    smallButton("방 만들기") { showCreate = true }
                    smallButton("초대 코드 입장") { showJoin = true }
                }
                if profile.me?.isAdmin == true {
                    smallButton("공식 방 만들기 (운영자)") { showOfficial = true }
                }
                if let message { Text(message).font(.system(size: 14)).foregroundColor(Theme.danger) }
                VStack(spacing: 0) {
                    ForEach(Array(rooms.enumerated()), id: \.element.id) { i, room in
                        roomRow(room)
                        if i < rooms.count - 1 { Divider1() }
                    }
                    if rooms.isEmpty {
                        Text("참여할 수 있는 방이 없어요").font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                            .frame(maxWidth: .infinity).padding(.vertical, 24)
                    }
                }
                .card()
            }
            .refreshable { await load() }
            .navigationDestination(for: Room.self) { room in
                RoomView(room: room, onChange: { Task { await load() } })
            }
            .toolbar(.hidden, for: .navigationBar)
            .task { await load() }
            .sheet(isPresented: $showCreate) {
                InputSheet(title: "방 만들기", placeholder: "방 이름 (2~20자)", button: "만들기") { name in
                    _ = try await store.api.createRoom(name: name, official: false, gender: nil)
                    await load()
                }
            }
            .sheet(isPresented: $showOfficial) { OfficialRoomSheet { Task { await load() } } }
            .sheet(isPresented: $showJoin) {
                InputSheet(title: "초대 코드 입장", placeholder: "초대 코드 6자리", button: "입장", uppercase: true) { code in
                    _ = try await store.api.joinRoom(roomId: nil, inviteCode: code)
                    await load()
                }
            }
        }
    }

    @ViewBuilder private func roomRow(_ room: Room) -> some View {
        if room.joined {
            NavigationLink(value: room) {
                RoomRowView(name: room.name, count: "\(room.memberCount)명")
            }
            .buttonStyle(.plain)
        } else {
            HStack(spacing: 8) {
                Text(room.name).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
                Spacer()
                Text("\(room.memberCount)명").font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                Button("참여") { join(room) }
                    .font(.system(size: 14, weight: .bold)).foregroundColor(.white)
                    .padding(.horizontal, 14).padding(.vertical, 6)
                    .background(Theme.accent, in: Capsule())
            }
            .frame(height: 52)
        }
    }

    private func join(_ room: Room) {
        Task {
            do {
                _ = try await store.api.joinRoom(roomId: room.id, inviteCode: nil)
                await load()
            } catch {
                await MainActor.run { message = errorText(error) }
            }
        }
    }

    private func load() async {
        do {
            let r = try await store.api.fetchRooms()
            await MainActor.run { rooms = r; message = nil }
        } catch {
            await MainActor.run { message = errorText(error) }
        }
    }
}

// ───────── 방 안: 참여자 순위 ─────────
struct RoomView: View {
    @EnvironmentObject var store: TimerStore
    @Environment(\.dismiss) private var dismiss
    let room: Room
    var onChange: () -> Void = {}

    @State private var detail: RoomDetail?
    @State private var friendsOnly = false
    @State private var message: String?
    @State private var reportTarget: RoomMember?
    @State private var confirmLeave = false

    private var members: [RoomMember] {
        let all = detail?.members ?? []
        return friendsOnly ? all.filter { $0.isFriend || $0.isMe } : all
    }

    var body: some View {
        ScreenScaffold(room.name) {
            Text("참여 \(detail?.room.memberCount ?? room.memberCount)명")
                .font(.system(size: 14)).foregroundColor(Theme.textSecondary)

            if let code = detail?.room.inviteCode ?? room.inviteCode {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("초대 코드").font(.system(size: 12)).foregroundColor(Theme.textSecondary)
                        Text(code).font(.system(size: 22, weight: .bold, design: .monospaced)).foregroundColor(Theme.textPrimary)
                    }
                    Spacer()
                    Button("복사") { UIPasteboard.general.string = code }
                        .font(.system(size: 14, weight: .bold)).foregroundColor(Theme.accent)
                }
                .card(vertical: 12)
            }

            ToggleRowView(label: "친구들만 보기", isOn: $friendsOnly).card()

            if let message { Text(message).font(.system(size: 14)).foregroundColor(Theme.danger) }

            VStack(spacing: 0) {
                ForEach(Array(members.enumerated()), id: \.element.id) { i, m in
                    RankRowView(rank: i + 1, nickname: m.isMe ? "\(m.nickname) (나)" : m.nickname,
                                seconds: m.todaySeconds, studying: m.studying, subtitle: m.ageLabel)
                        .contextMenu {
                            if !m.isMe {
                                Button("신고") { reportTarget = m }
                                Button("차단", role: .destructive) { block(m) }
                            }
                        }
                    if i < members.count - 1 { Divider1() }
                }
            }
            .card()

            Button("방 나가기", role: .destructive) { confirmLeave = true }
                .font(.system(size: 15, weight: .medium)).frame(maxWidth: .infinity).padding(.top, 8)
        }
        .refreshable { await load() }
        .navigationBarTitleDisplayMode(.inline)
        .task { await load() }
        .sheet(item: $reportTarget) { m in
            ReportSheet(userId: m.id, nickname: m.nickname, roomId: room.id) { Task { await load() } }
        }
        .confirmationDialog("이 방에서 나갈까요?", isPresented: $confirmLeave, titleVisibility: .visible) {
            Button("나가기", role: .destructive) { leave() }
        }
    }

    private func block(_ m: RoomMember) {
        Task {
            do { try await store.api.block(userId: m.id); await load() }
            catch { await MainActor.run { message = errorText(error) } }
        }
    }

    private func leave() {
        Task {
            do {
                try await store.api.leaveRoom(id: room.id)
                await MainActor.run { onChange(); dismiss() }
            } catch { await MainActor.run { message = errorText(error) } }
        }
    }

    private func load() async {
        do {
            let d = try await store.api.fetchRoom(id: room.id)
            await MainActor.run { detail = d; message = nil }
        } catch {
            await MainActor.run { message = errorText(error) }
        }
    }
}

// ───────── 친구 ─────────
struct FriendsView: View {
    @EnvironmentObject var store: TimerStore
    @EnvironmentObject var profile: ProfileStore
    @State private var friends: [FriendInfo] = []
    @State private var code = ""
    @State private var message: String?
    @State private var info: String?
    @State private var busy = false
    @State private var reportTarget: FriendInfo?

    private var incoming: [FriendInfo] { friends.filter { $0.status == "pending_in" } }
    private var confirmed: [FriendInfo] { friends.filter { $0.status == "friends" } }
    private var outgoing: [FriendInfo] { friends.filter { $0.status == "pending_out" } }

    var body: some View {
        ScreenScaffold("친구") {
            if let myCode = profile.me?.friendCode {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("내 친구 코드").font(.system(size: 12)).foregroundColor(Theme.textSecondary)
                        Text(myCode).font(.system(size: 22, weight: .bold, design: .monospaced)).foregroundColor(Theme.textPrimary)
                    }
                    Spacer()
                    Button("복사") { UIPasteboard.general.string = myCode }
                        .font(.system(size: 14, weight: .bold)).foregroundColor(Theme.accent)
                }
                .card(vertical: 12)
            }

            HStack(spacing: 8) {
                TextField("친구 코드 입력", text: $code)
                    .textInputAutocapitalization(.characters).autocorrectionDisabled()
                    .padding(.horizontal, 12).frame(height: 48)
                    .background(Theme.surface, in: RoundedRectangle(cornerRadius: 12))
                Button { request() } label: {
                    Text("요청").font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                        .padding(.horizontal, 20).frame(height: 48)
                        .background(Theme.accent, in: RoundedRectangle(cornerRadius: 12))
                }
                .disabled(busy || code.trimmingCharacters(in: .whitespaces).isEmpty)
            }
            if let message { Text(message).font(.system(size: 14)).foregroundColor(Theme.danger) }
            if let info { Text(info).font(.system(size: 14)).foregroundColor(Theme.success) }

            if !incoming.isEmpty {
                Text("받은 요청").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
                VStack(spacing: 0) {
                    ForEach(Array(incoming.enumerated()), id: \.element.id) { i, f in
                        HStack(spacing: 8) {
                            nameBlock(f)
                            Spacer()
                            pill("수락", filled: true) { run { try await store.api.acceptFriend(id: f.id) } }
                            pill("거절", filled: false) { run { try await store.api.removeFriend(id: f.id) } }
                        }
                        .frame(height: 56)
                        if i < incoming.count - 1 { Divider1() }
                    }
                }
                .card()
            }

            Text("친구 \(confirmed.count)명").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
            if confirmed.isEmpty {
                VStack(spacing: 6) {
                    Text("아직 친구가 없어요").font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
                    Text("친구 코드를 주고받아 같이 공부해 보세요").font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                }
                .frame(maxWidth: .infinity).padding(.vertical, 32)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(confirmed.enumerated()), id: \.element.id) { i, f in
                        HStack(spacing: 8) {
                            nameBlock(f)
                            Spacer()
                            if f.studying { Circle().fill(Theme.success).frame(width: 8, height: 8) }
                            Text(hms(f.todaySeconds)).font(.system(size: 16)).monospacedDigit().foregroundColor(Theme.textSecondary)
                        }
                        .frame(height: 56)
                        .contextMenu {
                            Button("친구 삭제") { run { try await store.api.removeFriend(id: f.id) } }
                            Button("신고") { reportTarget = f }
                            Button("차단", role: .destructive) { run { try await store.api.block(userId: f.id) } }
                        }
                        if i < confirmed.count - 1 { Divider1() }
                    }
                }
                .card()
            }

            if !outgoing.isEmpty {
                Text("보낸 요청").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
                VStack(spacing: 0) {
                    ForEach(Array(outgoing.enumerated()), id: \.element.id) { i, f in
                        HStack {
                            nameBlock(f)
                            Spacer()
                            pill("취소", filled: false) { run { try await store.api.removeFriend(id: f.id) } }
                        }
                        .frame(height: 56)
                        if i < outgoing.count - 1 { Divider1() }
                    }
                }
                .card()
            }
        }
        .refreshable { await load() }
        .task { await load() }
        .sheet(item: $reportTarget) { f in
            ReportSheet(userId: f.id, nickname: f.nickname) { Task { await load() } }
        }
    }

    private func nameBlock(_ f: FriendInfo) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(f.nickname).font(.system(size: 16, weight: .medium)).foregroundColor(Theme.textPrimary)
            if let a = f.ageLabel { Text(a).font(.system(size: 11)).foregroundColor(Theme.textSecondary) }
        }
    }

    private func pill(_ title: String, filled: Bool, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title).font(.system(size: 13, weight: .bold))
                .foregroundColor(filled ? .white : Theme.textSecondary)
                .padding(.horizontal, 12).padding(.vertical, 6)
                .background(filled ? Theme.accent : Theme.border, in: Capsule())
        }
    }

    private func request() {
        let c = code.trimmingCharacters(in: .whitespaces)
        busy = true; message = nil; info = nil
        Task {
            do {
                try await store.api.requestFriend(code: c)
                await MainActor.run { code = ""; info = "요청을 보냈어요." }
                await load()
            } catch { await MainActor.run { message = errorText(error) } }
            await MainActor.run { busy = false }
        }
    }

    private func run(_ work: @escaping () async throws -> Void) {
        Task {
            do { try await work(); await load() }
            catch { await MainActor.run { message = errorText(error) } }
        }
    }

    private func load() async {
        do {
            let f = try await store.api.fetchFriends()
            await MainActor.run { friends = f }
        } catch { await MainActor.run { message = errorText(error) } }
    }
}

// ───────── 운영자 전용: 공식 방 만들기 ─────────
struct OfficialRoomSheet: View {
    @EnvironmentObject var store: TimerStore
    @Environment(\.dismiss) private var dismiss
    var onDone: () -> Void

    @State private var name = ""
    @State private var gender = "all"
    @State private var busy = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("공식 방 (모든 사용자에게 보여요)") {
                    TextField("방 이름 (예: 남자 전체, ○○고등학교)", text: $name)
                    Picker("입장 가능", selection: $gender) {
                        Text("모두").tag("all")
                        Text("남자만").tag("male")
                        Text("여자만").tag("female")
                    }
                    .pickerStyle(.segmented)
                }
                if let message { Text(message).foregroundColor(.red) }
            }
            .navigationTitle("공식 방 만들기")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("취소") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("만들기") { submit() }.disabled(busy || name.trimmingCharacters(in: .whitespaces).count < 2)
                }
            }
        }
    }

    private func submit() {
        busy = true; message = nil
        Task {
            do {
                _ = try await store.api.createRoom(name: name.trimmingCharacters(in: .whitespaces),
                                                   official: true, gender: gender == "all" ? nil : gender)
                await MainActor.run { onDone(); dismiss() }
            } catch { await MainActor.run { message = errorText(error) } }
            await MainActor.run { busy = false }
        }
    }
}
