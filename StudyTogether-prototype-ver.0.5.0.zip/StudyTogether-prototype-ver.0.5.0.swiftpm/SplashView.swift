import SwiftUI

// MARK: - 스플래시 화면
// 모양과 값은 전부 AppConfig.Splash 에서 바꿉니다.

struct SplashView: View {
    private let cfg = AppConfig.Splash.self

    var body: some View {
        ZStack {
            cfg.backgroundColor.ignoresSafeArea()

            // 중앙 문구
            VStack(spacing: cfg.lineSpacing) {
                ForEach(Array(cfg.titleLines.enumerated()), id: \.offset) { _, line in
                    Text(line)
                        .font(ConfigResources.splashFont())
                        .foregroundColor(cfg.titleColor)
                }
            }
            .multilineTextAlignment(.center)
        }
        // 하단 중앙: 회사 로고
        .overlay(alignment: .bottom) {
            if let file = cfg.logoImageFile, let image = ConfigResources.image(file: file) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: cfg.logoHeight)
                    .padding(.bottom, cfg.logoBottomPadding)
            }
        }
        // 좌하단: 버전
        .overlay(alignment: .bottomLeading) {
            if cfg.showVersion {
                Text(ConfigResources.versionText())
                    .font(.system(size: cfg.versionFontSize, weight: .regular))
                    .foregroundColor(cfg.versionColor)
                    .padding(.leading, cfg.versionLeadingPadding)
                    .padding(.bottom, cfg.versionBottomPadding)
            }
        }
    }
}

// MARK: - 스플래시 → 메인 화면 전환
// 사용법 (앱 진입점):
//
//   WindowGroup {
//       SplashGate { ContentView() }   // ContentView 자리에 기존 첫 화면 이름
//   }
//
// 스플래시가 끝난 뒤에 메인 화면이 만들어지므로, 카메라 등 메인 화면의 초기화는 그 뒤에 실행됩니다.

struct SplashGate<Content: View>: View {
    @State private var showingSplash = true
    private let content: () -> Content

    init(@ViewBuilder content: @escaping () -> Content) {
        self.content = content
    }

    var body: some View {
        ZStack {
            if showingSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            } else {
                content()
                    .transition(.opacity)
            }
        }
        .task {
            let nanos = UInt64(AppConfig.Splash.displayDuration * 1_000_000_000)
            try? await Task.sleep(nanoseconds: nanos)
            withAnimation(.easeInOut(duration: AppConfig.Splash.fadeDuration)) {
                showingSplash = false
            }
        }
    }
}
