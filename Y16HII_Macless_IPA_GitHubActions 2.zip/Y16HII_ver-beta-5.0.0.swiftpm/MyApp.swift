import SwiftUI
import AVFoundation
import AVKit
import ImageIO
import Photos
import PhotosUI
import Security
import UIKit
import UniformTypeIdentifiers

// MARK: - 상수 (여기 숫자만 바꾸면 됩니다)
enum Config {
    static let maxFrames = 1000               // 안전 상한 (수동으로 멈추지 않을 때)
    static let warmup: TimeInterval = 1.5     // 카메라 켠 뒤 노출 안정화 대기(초)
    static let jpegQuality: CGFloat = 0.85
    static let maxVideoSide: CGFloat = 1920   // 원본 영상 긴 변 최대 픽셀
    static let recordW = 1920                 // 최종(레코드) 영상 크기 16:9
    static let recordH = 1080
    static let quoteSeconds: ClosedRange<Double> = 540...660   // 동기부여 문구 교체 주기 (9~11분 사이 랜덤)
    static let storageUseRatio = 0.7          // 남은 용량 중 앱이 쓸 수 있는 비율
    static let storageWarnRatio = 0.8         // 허용 용량의 80%에 도달하면 경고
    static let lateTolerance: TimeInterval = 20 // 이 시간 넘게 늦으면 그 회차는 AwayImage 프레임으로 대체
    static let previewScale: CGFloat = 0.4    // 시작 화면 카메라 미리보기 크기 (화면 가로·세로의 40%)
    // 인코딩 시 밝기 평탄화 (프레임 사이에서 튀는 밝기만 줄이고, 서서히 변하는 빛은 살림)
    static let smoothBrightness = true
    static let smoothRadius = 6               // 앞뒤 몇 프레임의 평균 흐름에 맞출지
    static let minGain: Double = 0.6          // 보정 한도 (너무 크게 바꾸지 않도록)
    static let maxGain: Double = 1.6
}

// MARK: - 동기부여 문구 (프로젝트에 넣은 motiv_text.txt: 한 줄에 문구 하나, '#'로 시작하면 주석)
enum MotivQuotes {
    static func load() -> [String] {
        let b = Bundle.main
        guard let url = b.url(forResource: "motiv_text", withExtension: "txt")
                ?? b.url(forResource: "motiv_text", withExtension: nil)
                ?? BundleFiles.find("motiv_text", exts: ["txt", "csv"]),
              let text = try? String(contentsOf: url, encoding: .utf8) else { return [] }
        let trim = CharacterSet.whitespacesAndNewlines.union(CharacterSet(charactersIn: "\u{FEFF}"))
        return text.split(whereSeparator: \.isNewline)
            .map { $0.trimmingCharacters(in: trim) }
            .filter { !$0.isEmpty && !$0.hasPrefix("#") }
    }
}

// MARK: - 사용자 설정값 (설정 > 영상 인코딩 설정)
enum Prefs {
    static var fps: Int32 {
        Int32((UserDefaults.standard.object(forKey: "videoFps") as? Double) ?? 24)
    }
    static var interval: TimeInterval {
        (UserDefaults.standard.object(forKey: "captureInterval") as? Double) ?? 120
    }
}

// MARK: - 저장 위치
enum Store {
    static var docs: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0] }
    static var framesDir: URL { docs.appendingPathComponent("Frames", isDirectory: true) }
    static var videoURL: URL { docs.appendingPathComponent("timelapse.mp4") }               // 최종(레코드) 영상
    static var originalURL: URL { docs.appendingPathComponent("timelapse_original.mp4") }   // 원본 영상
    static var zipURL: URL {
        let f = DateFormatter(); f.locale = Locale(identifier: "en_US_POSIX"); f.dateFormat = "yyyy-MM-dd"
        return docs.appendingPathComponent("StudyFrames_\(f.string(from: Date())).zip")
    }
    static func ensure() {
        try? FileManager.default.createDirectory(at: framesDir, withIntermediateDirectories: true)
    }
    static func frameFiles() -> [URL] {
        let files = (try? FileManager.default.contentsOfDirectory(at: framesDir, includingPropertiesForKeys: nil)) ?? []
        return files.filter { $0.pathExtension == "jpg" }.sorted { $0.lastPathComponent < $1.lastPathComponent }
    }
    static func removeLeftovers() {
        try? FileManager.default.removeItem(at: originalURL)
        if let items = try? FileManager.default.contentsOfDirectory(at: docs, includingPropertiesForKeys: nil) {
            for u in items where u.pathExtension == "zip" || (u.pathExtension == "mp4" && u.lastPathComponent.hasPrefix("Y16HII_")) {
                try? FileManager.default.removeItem(at: u)
            }
        }
    }
    // MARK: 용량 / 촬영 시각
    static func frameBytes() -> Int64 {
        frameFiles().reduce(0) { acc, u in
            acc + Int64((try? u.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0)
        }
    }
    static func availableBytes() -> Int64 {
        let url = URL(fileURLWithPath: NSHomeDirectory())
        if let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let c = v.volumeAvailableCapacityForImportantUsage { return c }
        return 0
    }
    static func frameDate(_ url: URL) -> Date? {
        (try? FileManager.default.attributesOfItem(atPath: url.path))?[.creationDate] as? Date
    }
    static func sessionRange(files: [URL]? = nil) -> (start: Date, end: Date)? {
        let dates = (files ?? frameFiles()).compactMap { frameDate($0) }
        guard let s = dates.min(), let e = dates.max() else { return nil }
        return (s, e)
    }
    /// Y16HII_yymmdd_시작시-종료시.mp4
    static func namedVideoName() -> String {
        let r = sessionRange() ?? (start: Date(), end: Date())
        let d = DateFormatter(); d.locale = Locale(identifier: "en_US_POSIX"); d.dateFormat = "yyMMdd"
        let h = DateFormatter(); h.locale = Locale(identifier: "en_US_POSIX"); h.dateFormat = "HH"
        return "Y16HII_\(d.string(from: r.start))_\(h.string(from: r.start))-\(h.string(from: r.end)).mp4"
    }

    /// 마지막 프레임의 픽셀 크기 (이미지를 전부 읽지 않고 메타데이터만 확인)
    static func lastFrameSize() -> CGSize? {
        guard let url = frameFiles().last,
              let src = CGImageSourceCreateWithURL(url as CFURL, nil),
              let p = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [CFString: Any],
              let w = p[kCGImagePropertyPixelWidth] as? Int,
              let h = p[kCGImagePropertyPixelHeight] as? Int else { return nil }
        return CGSize(width: w, height: h)
    }
}

// MARK: - 통계 로그 (Documents/Stats/capture_log.jsonl)
enum StatsLog {
    struct Entry: Codable {
        let time: Date
        let type: String      // "photo"(실제 촬영) / "away"(AwayImage로 대체된 프레임)
        let interval: Double  // 그 당시 촬영 간격(초)
    }
    static var dir: URL { Store.docs.appendingPathComponent("Stats", isDirectory: true) }
    static var file: URL { dir.appendingPathComponent("capture_log.jsonl") }

    static func append(type: String, interval: Double) {
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let enc = JSONEncoder(); enc.dateEncodingStrategy = .iso8601
        guard var data = try? enc.encode(Entry(time: Date(), type: type, interval: interval)) else { return }
        data.append(0x0A)
        if let h = try? FileHandle(forWritingTo: file) {
            defer { try? h.close() }
            _ = try? h.seekToEnd()
            try? h.write(contentsOf: data)
        } else {
            try? data.write(to: file)
        }
    }

    /// photos: 지금까지 실제로 찍힌 사진 수, hours: 사진 수 x 촬영 간격으로 계산한 기록 시간
    static func summary() -> (photos: Int, hours: Double) {
        guard let text = try? String(contentsOf: file, encoding: .utf8) else { return (0, 0) }
        let dec = JSONDecoder(); dec.dateDecodingStrategy = .iso8601
        var photos = 0
        var secs = 0.0
        for line in text.split(separator: "\n") {
            guard let d = line.data(using: .utf8),
                  let e = try? dec.decode(Entry.self, from: d), e.type == "photo" else { continue }
            photos += 1
            secs += e.interval
        }
        return (photos, secs / 3600)
    }
}

// MARK: - 번들 파일 검색: 이름의 공백/밑줄/기호/대소문자가 달라도 찾음 (예: "ui config.txt", "Video watermark (1).png")
enum BundleFiles {
    static let all: [URL] = {
        var out: [URL] = []
        if let en = FileManager.default.enumerator(at: Bundle.main.bundleURL, includingPropertiesForKeys: nil) {
            for case let u as URL in en { out.append(u) }
        }
        return out
    }()

    static func norm(_ s: String) -> String {
        s.lowercased().unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }.map(String.init).joined()
    }

    static func find(_ name: String, exts: [String]) -> URL? {
        let target = norm(name)
        let candidates = all.filter { exts.contains($0.pathExtension.lowercased()) }
        if let exact = candidates.first(where: { norm($0.deletingPathExtension().lastPathComponent) == target }) { return exact }
        return candidates.first { norm($0.deletingPathExtension().lastPathComponent).hasPrefix(target) }
    }
}

// MARK: - 외부 설정 파일 (ui_config.txt): 문구·색·크기·좌표·이탤릭·이미지 경로를 코드 밖에서 바꿈
// 형식:  [섹션이름] 아래에  키 = 값  (키와 값 사이는 ':' 또는 '=')   '#'로 시작하는 줄은 주석
// 좌표(coordinate)는 화면 대비 비율 (0.5, 0.1) = 가로 50%, 세로 10% 지점이 글자의 가운데
struct Elem {
    var text: String?
    var color: Color?
    var size: CGFloat?
    var coord: CGPoint?
    var italic: Bool?
}

final class UIConfig: @unchecked Sendable {
    static let shared = UIConfig()
    private var sections: [String: [String: String]] = [:]
    private(set) var isLoaded = false
    var sectionCount: Int { sections.count }

    init() {
        let docsFile = Store.docs.appendingPathComponent("ui_config.txt")
        var text: String?
        if let t = try? String(contentsOf: docsFile, encoding: .utf8) {
            text = t
        } else if let u = Bundle.main.url(forResource: "ui_config", withExtension: "txt")
                    ?? BundleFiles.find("ui_config", exts: ["txt"]),
                  let t = try? String(contentsOf: u, encoding: .utf8) {
            text = t
        }
        if let text {
            parse(text)
            isLoaded = true
        }
    }

    private func parse(_ text: String) {
        var current = ""
        for raw in text.split(whereSeparator: \.isNewline) {
            let line = raw.trimmingCharacters(in: CharacterSet.whitespaces.union(CharacterSet(charactersIn: "\u{FEFF}")))
            if line.isEmpty || line.hasPrefix("#") || line.hasPrefix("//") { continue }
            if let idx = line.firstIndex(where: { $0 == ":" || $0 == "=" }) {
                let key = line[..<idx].trimmingCharacters(in: .whitespaces).lowercased()
                var value = line[line.index(after: idx)...].trimmingCharacters(in: .whitespaces)
                // "Title_set:" 처럼 값 없이 끝나는 이름 줄은 섹션으로 취급
                if value.isEmpty && (key.hasSuffix("_set") || key == "images" || key == "colors") {
                    current = key
                    continue
                }
                if value.count >= 2, let f = value.first, let l = value.last,
                   (f == "\"" && l == "\"") || (f == "“" && l == "”") {
                    value = String(value.dropFirst().dropLast())
                }
                sections[current, default: [:]][key] = value
            } else {
                current = line.trimmingCharacters(in: CharacterSet(charactersIn: "[]: ")).lowercased()
            }
        }
    }

    func value(_ section: String, _ key: String) -> String? {
        let k = key.lowercased()
        return sections[section.lowercased()]?[k] ?? sections[""]?[k]
    }

    func number(_ section: String, _ key: String) -> Double? {
        value(section, key).flatMap { Self.parseNumber($0) }
    }

    func color(_ section: String, _ key: String) -> Color? {
        value(section, key).flatMap { Self.parseColor($0) }
    }

    func elem(_ name: String) -> Elem {
        var e = Elem()
        guard let d = sections[name.lowercased()] else { return e }
        if let t = d["text"] { e.text = t.replacingOccurrences(of: "\\n", with: "\n") }
        if let c = d["color"] { e.color = Self.parseColor(c) }
        if let s = d["size"], let n = Self.parseNumber(s) { e.size = CGFloat(n) }
        if let p = d["coordinate"] { e.coord = Self.parsePoint(p) }
        if let i = d["italic"] { e.italic = Self.parseBool(i) }
        return e
    }

    // MARK: 값 해석 ('???' 같은 자리표시는 무시되어 기본값이 쓰임)
    static func parseNumber(_ s: String) -> Double? {
        let allowed = CharacterSet(charactersIn: "0123456789.-")
        var out = ""
        for ch in s.unicodeScalars {
            if allowed.contains(ch) { out.unicodeScalars.append(ch) } else if !out.isEmpty { break }
        }
        return Double(out)
    }

    static func parsePoint(_ s: String) -> CGPoint? {
        let cleaned = s.replacingOccurrences(of: "(", with: "").replacingOccurrences(of: ")", with: "")
        let parts = cleaned.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespaces) }
        guard parts.count == 2, let x = Double(parts[0]), let y = Double(parts[1]) else { return nil }
        return CGPoint(x: x, y: y)
    }

    static func parseBool(_ s: String) -> Bool? {
        switch s.trimmingCharacters(in: .whitespaces).lowercased() {
        case "yes", "y", "true", "1", "on", "예": return true
        case "no", "n", "false", "0", "off", "아니오": return false
        default: return nil
        }
    }

    static func parseColor(_ s: String) -> Color? {
        var t = s.trimmingCharacters(in: .whitespaces).lowercased()
        let names: [String: String] = [
            "white": "ffffff", "black": "000000", "red": "ff3b30", "green": "34c759", "blue": "0a84ff",
            "orange": "ff9500", "yellow": "ffcc00", "gray": "888888", "grey": "888888",
            "beige": "f5ebd6", "brown": "5a3d29"
        ]
        if let n = names[t] { t = n }
        t = t.replacingOccurrences(of: "#", with: "")
        guard t.count == 6 || t.count == 8, let v = UInt64(t, radix: 16) else { return nil }
        if t.count == 6 {
            return Color(.sRGB, red: Double((v >> 16) & 0xFF) / 255, green: Double((v >> 8) & 0xFF) / 255,
                         blue: Double(v & 0xFF) / 255, opacity: 1)
        }
        return Color(.sRGB, red: Double((v >> 24) & 0xFF) / 255, green: Double((v >> 16) & 0xFF) / 255,
                     blue: Double((v >> 8) & 0xFF) / 255, opacity: Double(v & 0xFF) / 255)
    }
}

// MARK: - 이미지 위치 (설정 파일의 경로 → 프로젝트 안 파일 이름 → 에셋 순서로 찾음)
enum ImageLocator {
    static func load(key: String, fallbackName: String) -> UIImage? {
        if let loc = UIConfig.shared.value("Images", key), !loc.isEmpty, let img = load(location: loc) { return img }
        if let img = UIImage(named: fallbackName) { return img }
        for ext in ["png", "jpg", "jpeg"] {
            if let url = Bundle.main.url(forResource: fallbackName, withExtension: ext),
               let img = UIImage(contentsOfFile: url.path) { return img }
        }
        if let url = BundleFiles.find(fallbackName, exts: ["png", "jpg", "jpeg"]),
           let img = UIImage(contentsOfFile: url.path) { return img }
        return nil
    }

    private static func load(location: String) -> UIImage? {
        let fm = FileManager.default
        if location.hasPrefix("/"), fm.fileExists(atPath: location) { return UIImage(contentsOfFile: location) }
        let name = (location as NSString).lastPathComponent
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        if let url = Bundle.main.url(forResource: base, withExtension: ext.isEmpty ? nil : ext)
                ?? BundleFiles.find(base, exts: ext.isEmpty ? ["png", "jpg", "jpeg"] : [ext.lowercased()]),
           let img = UIImage(contentsOfFile: url.path) { return img }
        let docs = Store.docs.appendingPathComponent(name)
        if fm.fileExists(atPath: docs.path), let img = UIImage(contentsOfFile: docs.path) { return img }
        return UIImage(named: base)
    }
}

enum AppError: LocalizedError {
    case noCamera, noFrame, encode(String), zip
    var errorDescription: String? {
        switch self {
        case .noCamera: return "전면 카메라를 찾을 수 없습니다"
        case .noFrame: return "프레임을 받지 못했습니다"
        case .encode(let s): return "인코딩 실패: \(s)"
        case .zip: return "압축 실패"
        }
    }
}

// MARK: - 색상 <-> 16진수
extension UIColor {
    convenience init(hex: String) {
        var s = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#"))
        if s.count != 6 { s = "FFFFFF" }
        var v: UInt64 = 0
        Scanner(string: s).scanHexInt64(&v)
        self.init(red: CGFloat((v >> 16) & 0xFF) / 255,
                  green: CGFloat((v >> 8) & 0xFF) / 255,
                  blue: CGFloat(v & 0xFF) / 255, alpha: 1)
    }
    var hexString: String {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        getRed(&r, green: &g, blue: &b, alpha: &a)
        func c(_ x: CGFloat) -> Int { Int(max(0, min(255, (x * 255).rounded()))) }
        return String(format: "#%02X%02X%02X", c(r), c(g), c(b))
    }
}

// MARK: - 타임스탬프 스타일 (설정 메뉴에서 변경)
struct StampStyle: Codable, Equatable {
    var textHex = "#FFFFFF"
    var strokeHex = "#000000"
    var fontName = "System"
    var sizePercent = 2.8      // 사진 가로 길이 대비 %
    var strokeOn = true
    var strokeWidth = 3.0      // 글자 크기 대비 %
    var italic = false

    static let key = "stampStyle"
    static func load() -> StampStyle {
        guard let d = UserDefaults.standard.data(forKey: key),
              let s = try? JSONDecoder().decode(StampStyle.self, from: d) else { return StampStyle() }
        return s
    }
    func save() {
        if let d = try? JSONEncoder().encode(self) { UserDefaults.standard.set(d, forKey: StampStyle.key) }
    }
}

enum StampRenderer {
    static func text(for date: Date) -> String {
        let d = DateFormatter(); d.locale = Locale(identifier: "en_US_POSIX"); d.dateFormat = "yyyy.MM.dd."
        let t = DateFormatter(); t.locale = Locale(identifier: "en_US_POSIX"); t.dateFormat = "HH:mm"
        return d.string(from: date) + "\n" + t.string(from: date)
    }

    private static func makeFont(_ style: StampStyle, size: CGFloat) -> (UIFont, Bool) {
        let base: UIFont
        if style.fontName == "System" {
            base = UIFont.systemFont(ofSize: size, weight: .semibold)
        } else {
            base = UIFont(name: style.fontName, size: size) ?? UIFont.systemFont(ofSize: size, weight: .semibold)
        }
        guard style.italic else { return (base, false) }
        let traits = base.fontDescriptor.symbolicTraits.union(.traitItalic)
        if let d = base.fontDescriptor.withSymbolicTraits(traits) {
            let f = UIFont(descriptor: d, size: size)
            if f.fontDescriptor.symbolicTraits.contains(.traitItalic) { return (f, false) }
        }
        return (base, true)   // 이탤릭 서체가 없으면 기울임 효과로 대체
    }

    /// 현재 그래픽 컨텍스트의 우측 상단에 날짜/시간을 그림
    static func draw(text: String, canvas size: CGSize, style: StampStyle) {
        let fontSize = size.width * CGFloat(style.sizePercent) / 100
        let (font, oblique) = makeFont(style, size: fontSize)
        let para = NSMutableParagraphStyle(); para.alignment = .right
        var attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor(hex: style.textHex),
            .paragraphStyle: para
        ]
        if style.strokeOn {
            attrs[.strokeColor] = UIColor(hex: style.strokeHex)
            attrs[.strokeWidth] = -style.strokeWidth   // 음수 = 채우기 + 테두리
        }
        if oblique { attrs[.obliqueness] = 0.2 }
        let margin = size.width * 0.025
        let rect = CGRect(x: margin, y: margin, width: size.width - margin * 2, height: fontSize * 3)
        (text as NSString).draw(in: rect, withAttributes: attrs)
    }

    static func preview(_ style: StampStyle) -> UIImage {
        let size = CGSize(width: 800, height: 600)
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            UIColor(white: 0.5, alpha: 1).setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            draw(text: text(for: Date()), canvas: size, style: style)
        }
    }
}

// MARK: - 최종 영상 왼쪽 패널 스타일 (영상 꾸미기 화면에서 변경). panelMode 'grid' = 이용자 명칭 '타임테이블'(내부 이름 System_record_style)
struct RecordStyle: Codable, Equatable {
    var panelMode = "text"            // "text": 문구 / "grid": System_record_style
    var text = "Today's your Record"
    var textHex = "#000000"
    var fontName = "System"
    var italic = false
    var align = "center"              // left / center / right
    var textScale: Double? = nil      // 글씨 크기 배율 (기본 1.0)
    var bgHex = "#FFFFFF"
    var gridFillHex = "#4CAF50"
    var gridSmooth = false            // false: 10분 칸을 하나씩 / true: 칸 안에서 왼쪽→오른쪽으로 서서히

    static let key = "recordStyle"
    static let defaultText = "Today's your Record"

    static func load() -> RecordStyle {
        guard let d = UserDefaults.standard.data(forKey: key),
              let s = try? JSONDecoder().decode(RecordStyle.self, from: d) else { return RecordStyle() }
        return s
    }
    func save() {
        if let d = try? JSONEncoder().encode(self) { UserDefaults.standard.set(d, forKey: RecordStyle.key) }
    }
}

enum FontKit {
    /// 반환: (글꼴, 이탤릭 서체가 없어서 기울임 효과가 필요한지)
    static func make(name: String, size: CGFloat, italic: Bool, weight: UIFont.Weight = .semibold) -> (UIFont, Bool) {
        let base: UIFont
        if name == "System" {
            base = UIFont.systemFont(ofSize: size, weight: weight)
        } else {
            base = UIFont(name: name, size: size) ?? UIFont.systemFont(ofSize: size, weight: weight)
        }
        guard italic else { return (base, false) }
        let traits = base.fontDescriptor.symbolicTraits.union(.traitItalic)
        if let d = base.fontDescriptor.withSymbolicTraits(traits) {
            let f = UIFont(descriptor: d, size: size)
            if f.fontDescriptor.symbolicTraits.contains(.traitItalic) { return (f, false) }
        }
        return (base, true)
    }
}

// MARK: - 왼쪽 패널 그리기
enum PanelRenderer {
    /// 캔버스 전체(배경색 + 왼쪽 패널 내용)를 그린 이미지. 사진은 따로 오른쪽 끝에 얹는다.
    static func render(canvas: CGSize, photoSize: CGSize, style: RecordStyle,
                       range: (start: Date, end: Date)?, time: Date?) -> CGImage? {
        let s = min(canvas.width / photoSize.width, canvas.height / photoSize.height)
        let leftW = canvas.width - photoSize.width * s
        let bg = UIColor(hex: style.bgHex)
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: canvas, format: fmt).image { ctx in
            bg.setFill()
            ctx.fill(CGRect(origin: .zero, size: canvas))
            guard leftW > 120 else { return }
            let area = CGRect(x: 0, y: 0, width: leftW, height: canvas.height)
            if style.panelMode == "grid", let range {
                drawGrid(in: area, style: style, range: range, time: time ?? range.end, bg: bg)
            } else {
                drawText(in: area, style: style)
            }
        }
        return img.cgImage
    }

    private static func drawText(in area: CGRect, style: RecordStyle) {
        guard !style.text.isEmpty else { return }
        let inset = area.width * 0.08
        let width = area.width - inset * 2
        let fontSize = min(width * 0.2, area.height * 0.08) * CGFloat(style.textScale ?? 1)
        let (font, oblique) = FontKit.make(name: style.fontName, size: fontSize, italic: style.italic, weight: .heavy)
        let para = NSMutableParagraphStyle()
        switch style.align {
        case "left": para.alignment = .left
        case "right": para.alignment = .right
        default: para.alignment = .center
        }
        var attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor(hex: style.textHex),
            .paragraphStyle: para
        ]
        if oblique { attrs[.obliqueness] = 0.2 }
        let text = style.text as NSString
        let box = text.boundingRect(with: CGSize(width: width, height: area.height),
                                    options: .usesLineFragmentOrigin, attributes: attrs, context: nil)
        let y = (area.height - box.height) / 2
        text.draw(in: CGRect(x: inset, y: y, width: width, height: box.height + 4), withAttributes: attrs)
    }

    /// System_record_style: 가로 6칸(10분 단위) x 세로 24칸(0~23시). 촬영 시작~현재 프레임 시각까지만 채움
    private static func drawGrid(in area: CGRect, style: RecordStyle, range: (start: Date, end: Date),
                                 time: Date, bg: UIColor) {
        let labelRatio: CGFloat = 1.3
        let p = min(area.height * 0.96 / 24, area.width * 0.92 / (6 + labelRatio))   // 칸 간격
        let s = p * 0.82                                                             // 정사각형 한 변
        let totalW = p * (6 + labelRatio)
        let x0 = area.minX + (area.width - totalW) / 2 + p * labelRatio
        let y0 = area.minY + (area.height - 24 * p) / 2

        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        bg.getRed(&r, green: &g, blue: &b, alpha: &a)
        let light = (0.299 * r + 0.587 * g + 0.114 * b) > 0.5
        let emptyColor = light ? UIColor(white: 0.9, alpha: 1) : UIColor(white: 0.28, alpha: 1)
        let labelColor = light ? UIColor(white: 0.45, alpha: 1) : UIColor(white: 0.7, alpha: 1)
        let fillColor = UIColor(hex: style.gridFillHex)

        func cellRect(_ idx: Int) -> CGRect {
            CGRect(x: x0 + CGFloat(idx % 6) * p, y: y0 + CGFloat(idx / 6) * p, width: s, height: s)
        }

        // 시 라벨
        let para = NSMutableParagraphStyle(); para.alignment = .right
        let labelAttrs: [NSAttributedString.Key: Any] = [
            .font: UIFont.monospacedDigitSystemFont(ofSize: p * 0.45, weight: .regular),
            .foregroundColor: labelColor,
            .paragraphStyle: para
        ]
        for hour in 0..<24 {
            let rect = CGRect(x: x0 - p * labelRatio, y: y0 + CGFloat(hour) * p + (s - p * 0.45 * 1.2) / 2,
                              width: p * (labelRatio - 0.2), height: p)
            ("\(hour)시" as NSString).draw(in: rect, withAttributes: labelAttrs)
        }

        // 빈 칸
        emptyColor.setFill()
        for idx in 0..<144 {
            UIBezierPath(roundedRect: cellRect(idx), cornerRadius: s * 0.2).fill()
        }

        // 채워진 칸
        let day0 = Calendar.current.startOfDay(for: range.start)
        let startMin = range.start.timeIntervalSince(day0) / 60
        let t = min(max(time, range.start), range.end)
        let tMin = t.timeIntervalSince(day0) / 60
        let kStart = Int(floor(startMin / 10))
        let kEnd = min(Int(floor(tMin / 10)), kStart + 143)
        guard kEnd >= kStart, let cg = UIGraphicsGetCurrentContext() else { return }
        fillColor.setFill()
        for k in kStart...kEnd {
            let cellStart = Double(k) * 10
            let from = max(startMin, cellStart)
            let to = min(tMin, cellStart + 10)
            let cell = cellRect(k % 144)
            let path = UIBezierPath(roundedRect: cell, cornerRadius: s * 0.2)
            if style.gridSmooth {
                let f0 = (from - cellStart) / 10, f1 = (to - cellStart) / 10
                guard f1 > f0 else { continue }
                cg.saveGState()
                path.addClip()
                UIRectFill(CGRect(x: cell.minX + CGFloat(f0) * s, y: cell.minY, width: CGFloat(f1 - f0) * s, height: s))
                cg.restoreGState()
            } else {
                path.fill()
            }
        }
    }

    /// 설정 화면 미리보기용 (왼쪽 480px 패널만)
    static func preview(style: RecordStyle) -> UIImage? {
        let day0 = Calendar.current.startOfDay(for: Date())
        let range = (start: day0.addingTimeInterval(80 * 60), end: day0.addingTimeInterval(280 * 60))
        guard let cg = render(canvas: CGSize(width: 1920, height: 1080),
                              photoSize: CGSize(width: 4032, height: 3024),
                              style: style, range: range, time: range.end),
              let crop = cg.cropping(to: CGRect(x: 0, y: 0, width: 480, height: 1080)) else { return nil }
        return UIImage(cgImage: crop)
    }
}

// MARK: - 기록하지 못한 프레임을 대체하는 AwayImage 프레임
enum PlaceholderRenderer {
    static func make(size: CGSize, date: Date, style: StampStyle) -> Data? {
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let img = UIGraphicsImageRenderer(size: size, format: fmt).image { ctx in
            UIColor.black.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            if let away = ImageLocator.load(key: "AwayImage_Location", fallbackName: "AwayImage") {
                let s = min(size.width / away.size.width, size.height / away.size.height)
                let w = away.size.width * s, h = away.size.height * s
                away.draw(in: CGRect(x: (size.width - w) / 2, y: (size.height - h) / 2, width: w, height: h))
            } else {
                let para = NSMutableParagraphStyle(); para.alignment = .center
                let fs = min(size.width, size.height) * 0.06
                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: fs, weight: .semibold),
                    .foregroundColor: UIColor.white,
                    .paragraphStyle: para
                ]
                ("다른 앱 사용 중 📚" as NSString).draw(
                    in: CGRect(x: 0, y: (size.height - fs * 1.3) / 2, width: size.width, height: fs * 1.5),
                    withAttributes: attrs)
            }
            StampRenderer.draw(text: StampRenderer.text(for: date), canvas: size, style: style)
        }
        return img.jpegData(compressionQuality: Config.jpegQuality)
    }
}

// MARK: - 무음 카메라 (비디오 스트림에서 프레임을 뽑기 때문에 셔터음이 없음)
final class SilentCamera: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate, @unchecked Sendable {
    let session = AVCaptureSession()
    private(set) var device: AVCaptureDevice?
    private let output = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "camera.session")
    private let frameQueue = DispatchQueue(label: "camera.frames")
    private let lock = NSLock()
    private var latest: CVPixelBuffer?
    private var configured = false
    private var rotation: AVCaptureDevice.RotationCoordinator?
    private let ciContext = CIContext()

    private func configure() throws {
        guard !configured else { return }
        let discovery = AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInUltraWideCamera, .builtInWideAngleCamera],
            mediaType: .video, position: .front)
        guard let dev = discovery.devices.first(where: { $0.deviceType == .builtInUltraWideCamera })
                ?? discovery.devices.first else { throw AppError.noCamera }

        session.beginConfiguration()
        if session.canSetSessionPreset(.photo) { session.sessionPreset = .photo }
        let input = try AVCaptureDeviceInput(device: dev)
        guard session.canAddInput(input) else { session.commitConfiguration(); throw AppError.noCamera }
        session.addInput(input)
        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: frameQueue)
        guard session.canAddOutput(output) else { session.commitConfiguration(); throw AppError.noCamera }
        session.addOutput(output)
        session.commitConfiguration()

        // 가장 넓은 화각
        if (try? dev.lockForConfiguration()) != nil {
            dev.videoZoomFactor = dev.minAvailableVideoZoomFactor
            dev.unlockForConfiguration()
        }
        rotation = AVCaptureDevice.RotationCoordinator(device: dev, previewLayer: nil)
        device = dev
        configured = true
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        setLatest(pb)
    }

    // 동기 함수 안에서만 lock을 쓰면 async 경고가 나지 않음
    private func setLatest(_ pb: CVPixelBuffer?) {
        lock.lock(); latest = pb; lock.unlock()
    }

    private func getLatest() -> CVPixelBuffer? {
        lock.lock(); defer { lock.unlock() }
        return latest
    }

    private func run(_ work: @escaping @Sendable () -> Void) async {
        await withCheckedContinuation { (c: CheckedContinuation<Void, Never>) in
            sessionQueue.async { work(); c.resume() }
        }
    }

    private func prepare() async throws {
        try await withCheckedThrowingContinuation { (c: CheckedContinuation<Void, Error>) in
            sessionQueue.async {
                do { try self.configure(); c.resume() } catch { c.resume(throwing: error) }
            }
        }
    }

    // 시작 화면 미리보기용
    func startPreview() async throws {
        try await prepare()
        await run { if !self.session.isRunning { self.session.startRunning() } }
    }

    func stopPreview() async {
        await run { if self.session.isRunning { self.session.stopRunning() } }
    }

    /// 한 장 촬영 → 날짜/시간 각인 → JPEG Data 반환
    func capture() async throws -> Data {
        try await prepare()
        if let coord = rotation, let conn = output.connection(with: .video) {
            let angle = coord.videoRotationAngleForHorizonLevelCapture
            if conn.isVideoRotationAngleSupported(angle) { conn.videoRotationAngle = angle }
        }
        setLatest(nil)

        await run { if !self.session.isRunning { self.session.startRunning() } }
        do {
            try await Task.sleep(nanoseconds: UInt64(Config.warmup * 1_000_000_000))
        } catch {
            await run { self.session.stopRunning() }
            throw error
        }
        let pb = getLatest()
        await run { self.session.stopRunning() }   // 쓰지 않을 때는 카메라를 꺼서 발열/전력 절약

        guard let pb else { throw AppError.noFrame }
        let ci = CIImage(cvPixelBuffer: pb)
        guard let cg = ciContext.createCGImage(ci, from: ci.extent) else { throw AppError.noFrame }
        let stamped = stamp(cg, date: Date(), style: StampStyle.load())
        guard let data = stamped.jpegData(compressionQuality: Config.jpegQuality) else { throw AppError.noFrame }
        return data
    }

    private func stamp(_ cg: CGImage, date: Date, style: StampStyle) -> UIImage {
        let size = CGSize(width: cg.width, height: cg.height)
        let fmt = UIGraphicsImageRendererFormat()
        fmt.scale = 1; fmt.opaque = true
        return UIGraphicsImageRenderer(size: size, format: fmt).image { _ in
            UIImage(cgImage: cg).draw(in: CGRect(origin: .zero, size: size))
            StampRenderer.draw(text: StampRenderer.text(for: date), canvas: size, style: style)
        }
    }
}

// MARK: - 카메라 미리보기 (시작 화면)
final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var previewLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    var coordinator: AVCaptureDevice.RotationCoordinator?

    func refreshRotation() {
        guard let c = coordinator, let conn = previewLayer.connection else { return }
        let angle = c.videoRotationAngleForHorizonLevelPreview
        if conn.isVideoRotationAngleSupported(angle) { conn.videoRotationAngle = angle }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        refreshRotation()
    }
}

struct CameraPreview: UIViewRepresentable {
    let camera: SilentCamera
    let ready: Bool

    func makeUIView(context: Context) -> PreviewView {
        let v = PreviewView()
        v.previewLayer.videoGravity = .resizeAspectFill
        return v
    }

    func updateUIView(_ v: PreviewView, context: Context) {
        // 카메라 설정이 끝난 뒤(ready)에만 세션을 연결 (설정 도중 연결하면 간헐적으로 앱이 죽을 수 있음)
        if ready, v.previewLayer.session == nil { v.previewLayer.session = camera.session }
        if v.coordinator == nil, ready, let dev = camera.device {
            v.coordinator = AVCaptureDevice.RotationCoordinator(device: dev, previewLayer: v.previewLayer)
        }
        v.refreshRotation()
    }
}

// MARK: - 타임랩스 인코더 (H.264 mp4)
enum VideoEncoder {
    enum Layout { case original, record }

    static func encode(files: [URL], to out: URL, fps: Int32, layout: Layout,
                       style: RecordStyle = RecordStyle.load(),
                       progress: (@Sendable (Double) -> Void)? = nil) async throws {
        guard let first = files.first,
              let firstCG = UIImage(contentsOfFile: first.path)?.cgImage else { throw AppError.encode("사진 없음") }
        progress?(0)

        let w: Int, h: Int
        switch layout {
        case .record:
            w = Config.recordW; h = Config.recordH
        case .original:
            let scale = min(1, Config.maxVideoSide / CGFloat(max(firstCG.width, firstCG.height)))
            w = Int(CGFloat(firstCG.width) * scale) / 2 * 2
            h = Int(CGFloat(firstCG.height) * scale) / 2 * 2
        }
        let W = CGFloat(w), H = CGFloat(h)
        let canvas = CGSize(width: W, height: H)
        let photoSize = CGSize(width: firstCG.width, height: firstCG.height)

        // 프레임별 촬영 시각(System_record_style이 사용)
        let times: [Date?] = files.map { Store.frameDate($0) }
        let range = Store.sessionRange(files: files)
        let isGrid = (layout == .record && style.panelMode == "grid" && range != nil)
        let staticBackground: CGImage? = (layout == .record && !isGrid)
            ? PanelRenderer.render(canvas: canvas, photoSize: photoSize, style: style, range: nil, time: nil)
            : nil

        try? FileManager.default.removeItem(at: out)
        let writer = try AVAssetWriter(outputURL: out, fileType: .mp4)
        let input = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: w,
            AVVideoHeightKey: h
        ])
        let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: input, sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
            kCVPixelBufferWidthKey as String: w,
            kCVPixelBufferHeightKey as String: h
        ])
        writer.add(input)
        guard writer.startWriting() else { throw AppError.encode(writer.error?.localizedDescription ?? "시작 실패") }
        writer.startSession(atSourceTime: .zero)

        // 밝기 평탄화용 보정 배율 (진행도의 앞 15%)
        let gains = brightnessGains(files: files, progress: progress)

        // 워터마크 (Video_watermark.png): 오른쪽 최하단. 크기·여백·투명도는 ui_config.txt의 [Watermark_set]
        let wmImage = ImageLocator.load(key: "Watermark_Location", fallbackName: "Video_watermark")?.cgImage
        let wmWidth = CGFloat(UIConfig.shared.number("Watermark_set", "size") ?? 200)   // 1920px 폭 기준
        let wmMargin = CGFloat(UIConfig.shared.number("Watermark_set", "margin") ?? 24)
        let wmOpacity = CGFloat(UIConfig.shared.number("Watermark_set", "opacity") ?? 1)
        let baseColor: CGColor = (layout == .record) ? UIColor(hex: style.bgHex).cgColor : UIColor.black.cgColor
        let total = Double(files.count)

        for (i, file) in files.enumerated() {
            while !input.isReadyForMoreMediaData { try await Task.sleep(nanoseconds: 10_000_000) }
            guard let pool = adaptor.pixelBufferPool else { throw AppError.encode("버퍼 풀 없음") }
            try autoreleasepool {
                guard let cg = UIImage(contentsOfFile: file.path)?.cgImage else { return }
                var pbOut: CVPixelBuffer?
                CVPixelBufferPoolCreatePixelBuffer(nil, pool, &pbOut)
                guard let pb = pbOut else { throw AppError.encode("버퍼 생성 실패") }
                CVPixelBufferLockBaseAddress(pb, [])
                defer { CVPixelBufferUnlockBaseAddress(pb, []) }
                guard let ctx = CGContext(
                    data: CVPixelBufferGetBaseAddress(pb), width: w, height: h, bitsPerComponent: 8,
                    bytesPerRow: CVPixelBufferGetBytesPerRow(pb), space: CGColorSpaceCreateDeviceRGB(),
                    bitmapInfo: CGBitmapInfo.byteOrder32Little.rawValue | CGImageAlphaInfo.premultipliedFirst.rawValue
                ) else { throw AppError.encode("컨텍스트 실패") }
                ctx.interpolationQuality = .high

                // 바탕 (+ 왼쪽 패널)
                ctx.setFillColor(baseColor)
                ctx.fill(CGRect(x: 0, y: 0, width: W, height: H))
                var bg = staticBackground
                if isGrid, let range {
                    bg = PanelRenderer.render(canvas: canvas, photoSize: photoSize, style: style,
                                              range: range, time: times[i] ?? range.end)
                }
                if let bg { ctx.draw(bg, in: CGRect(x: 0, y: 0, width: W, height: H)) }

                // 사진: 잘림 없이 비율 유지. 레코드 영상은 오른쪽 끝 정렬, 원본은 가운데
                let pw = CGFloat(cg.width), ph = CGFloat(cg.height)
                let s = min(W / pw, H / ph)
                let dw = pw * s, dh = ph * s
                let x = (layout == .record) ? (W - dw) : (W - dw) / 2
                let photoRect = CGRect(x: x, y: (H - dh) / 2, width: dw, height: dh)
                ctx.draw(cg, in: photoRect)

                // 밝기 평탄화: 이웃 프레임의 평균 흐름에 맞춰 살짝 보정
                let g = gains[i]
                if g < 1 {
                    ctx.setBlendMode(.normal)
                    ctx.setFillColor(UIColor.black.withAlphaComponent(1 - g).cgColor)
                    ctx.fill(photoRect)
                } else if g > 1 {
                    ctx.setBlendMode(.plusLighter)
                    ctx.setAlpha(g - 1)
                    ctx.draw(cg, in: photoRect)
                }

                if let wm = wmImage {
                    let k = W / CGFloat(Config.recordW)
                    let ww = wmWidth * k
                    let wh = ww * CGFloat(wm.height) / CGFloat(wm.width)
                    ctx.setBlendMode(.normal)
                    ctx.setAlpha(wmOpacity)
                    ctx.draw(wm, in: CGRect(x: W - wmMargin * k - ww, y: wmMargin * k, width: ww, height: wh))
                    ctx.setAlpha(1)
                }

                adaptor.append(pb, withPresentationTime: CMTime(value: Int64(i), timescale: fps))
            }
            progress?(0.15 + 0.85 * Double(i + 1) / total)
        }
        input.markAsFinished()
        await writer.finishWriting()
        guard writer.status == .completed else { throw AppError.encode(writer.error?.localizedDescription ?? "알 수 없음") }
        progress?(1)
    }

    // MARK: 밝기 평탄화
    /// 작은 썸네일로 줄여서 평균 밝기(0~1)를 잰다
    private static func measureLuminance(_ url: URL) -> Double? {
        let opts: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 64
        ]
        guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
              let cg = CGImageSourceCreateThumbnailAtIndex(src, 0, opts as CFDictionary) else { return nil }
        let w = cg.width, h = cg.height
        guard w > 0, h > 0 else { return nil }
        var pixels = [UInt8](repeating: 0, count: w * h)
        let ok: Bool = pixels.withUnsafeMutableBytes { buf in
            guard let ctx = CGContext(data: buf.baseAddress, width: w, height: h, bitsPerComponent: 8,
                                      bytesPerRow: w, space: CGColorSpaceCreateDeviceGray(),
                                      bitmapInfo: CGImageAlphaInfo.none.rawValue) else { return false }
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))
            return true
        }
        guard ok else { return nil }
        let sum = pixels.reduce(0) { $0 + Int($1) }
        return Double(sum) / Double(w * h) / 255
    }

    /// 각 프레임이 앞뒤 프레임들의 평균 밝기 흐름에 맞도록 하는 배율. AwayImage 프레임은 건드리지 않음
    private static func brightnessGains(files: [URL], progress: (@Sendable (Double) -> Void)?) -> [CGFloat] {
        var gains = [CGFloat](repeating: 1, count: files.count)
        guard Config.smoothBrightness else { return gains }
        var lum: [Double?] = []
        for (i, f) in files.enumerated() {
            lum.append(f.lastPathComponent.contains("_away") ? nil : measureLuminance(f))
            progress?(0.15 * Double(i + 1) / Double(files.count))
        }
        for i in files.indices {
            guard let own = lum[i] else { continue }
            let lo = max(0, i - Config.smoothRadius)
            let hi = min(files.count - 1, i + Config.smoothRadius)
            let neighbors = lum[lo...hi].compactMap { $0 }
            guard !neighbors.isEmpty else { continue }
            let target = neighbors.reduce(0, +) / Double(neighbors.count)
            let g = min(max(target / max(own, 0.02), Config.minGain), Config.maxGain)
            gains[i] = abs(g - 1) < 0.03 ? 1 : CGFloat(g)   // 3% 미만 차이는 그대로
        }
        return gains
    }
}

// MARK: - 상태 관리
@MainActor
final class Recorder: ObservableObject {
    enum Phase { case idle, intro, running, encoding, review, finished }
    enum MoverPurpose { case original, zip }

    @Published var phase: Phase = .idle
    @Published var count = 0            // 프레임 수 (사진 + AwayImage 대체 프레임)
    @Published var missed = 0           // AwayImage로 대체된 프레임 수
    @Published var flashGreen = false          // 촬영 순간 좌하단 숫자를 초록색으로
    @Published var motivQuote: String?
    @Published var message = ""
    @Published var nextShot: Date?
    @Published var encodingText = "순간순간을 후회하지 않도록."
    @Published var progress = 0.0              // 인코딩 진행도 (0~1)
    @Published var popupText: String?          // 화면 중앙 팝업 (저장 완료! 등)
    @Published var popupOpacity = 1.0
    @Published var storageWarning = false      // 허용 용량의 80% 도달
    @Published var shareURL: URL?              // 공유/저장용 파일 (Y16HII_...mp4)
    @Published var showMover = false
    @Published var moverFile: URL?
    @Published var askOriginal = false
    @Published var askDelete = false
    @Published var askStop = false
    @Published var previewReady = false
    // 시작 인트로 연출용
    @Published var contentOpacity = 1.0
    @Published var messageOpacity = 0.0
    @Published var beigeOpacity = 1.0

    let camera = SilentCamera()
    private var task: Task<Void, Never>?
    private var moverPurpose: MoverPurpose = .zip
    private var interval: TimeInterval = 120
    private var isActive = true
    private var savedBrightness: CGFloat?
    private var quotes: [String] = []
    private var quoteTask: Task<Void, Never>?
    private var capBytes: Int64 = .max     // 이번 촬영에서 쓸 수 있는 최대 용량
    private var usedBytes: Int64 = 0

    private var dimEnabled: Bool { UserDefaults.standard.object(forKey: "dimWhileRunning") as? Bool ?? true }
    private var dimLevel: Double { UserDefaults.standard.object(forKey: "dimLevel") as? Double ?? 0.1 }
    private var screen: UIScreen? { (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.screen }

    init() {
        Store.ensure()
        quotes = MotivQuotes.load()
        count = Store.frameFiles().count
        if count > 0 { message = "이전 촬영본 \(count)장이 남아 있습니다" }
    }

    // MARK: 시작 화면 미리보기
    func startPreview() {
        Task {
            let ok = await AVCaptureDevice.requestAccess(for: .video)
            guard ok else { message = "설정에서 카메라 권한을 허용해주세요"; return }
            do {
                try await camera.startPreview()
                previewReady = true
            } catch {
                message = error.localizedDescription
            }
        }
    }

    // 촬영이 진행되는 동안 9~11분 사이 랜덤한 간격으로 문구 교체
    private func startQuoteRotation() {
        quoteTask?.cancel()
        quoteTask = Task {
            while !Task.isCancelled {
                try? await Task.sleep(for: .seconds(Double.random(in: Config.quoteSeconds)))
                if Task.isCancelled { break }
                pickQuote()
            }
        }
    }

    /// 동기부여 문구를 눌렀을 때: 바로 다른 문구로 바꾸고, 자동 교체 타이머는 새로 시작
    func nextQuote() {
        pickQuote()
        if phase == .running { startQuoteRotation() }
    }

    private func pickQuote() {
        guard !quotes.isEmpty else { motivQuote = nil; return }
        var q = quotes.randomElement()
        if quotes.count > 1 { while q == motivQuote { q = quotes.randomElement() } }
        motivQuote = q
    }

    // MARK: 시작/종료
    func start() {
        guard phase == .idle, task == nil else { return }
        phase = .intro
        Task {
            let ok = await AVCaptureDevice.requestAccess(for: .video)
            guard ok else { message = "설정에서 카메라 권한을 허용해주세요"; phase = .idle; return }
            UIApplication.shared.isIdleTimerDisabled = true   // 화면 자동 잠금 방지 (촬영 중 필수)
            interval = Prefs.interval
            missed = 0
            message = ""
            pickQuote()

            // 남은 용량의 70%까지만 사용
            let existing = Store.frameBytes()
            capBytes = Int64(Double(Store.availableBytes() + existing) * Config.storageUseRatio)
            usedBytes = existing
            storageWarning = false

            await runIntro()
            await camera.stopPreview()
            previewReady = false
            contentOpacity = 1; messageOpacity = 0; beigeOpacity = 1   // 다음번 시작 화면을 위해 복원
            phase = .running
            applyDim(true)
            task = Task { await loop() }
            startQuoteRotation()
        }
    }

    // 다른 요소 페이드아웃 → 문구 페이드인(2초 유지) → 문구와 베이지 배경 함께 페이드아웃
    private func runIntro() async {
        withAnimation(.easeOut(duration: 0.6)) { contentOpacity = 0 }
        try? await Task.sleep(for: .seconds(0.7))
        withAnimation(.easeIn(duration: 0.6)) { messageOpacity = 1 }
        try? await Task.sleep(for: .seconds(0.6 + 2.0))
        withAnimation(.easeOut(duration: 0.8)) { messageOpacity = 0; beigeOpacity = 0 }
        try? await Task.sleep(for: .seconds(0.9))
    }

    func stopAndEncode() {
        let t = task
        task = nil
        t?.cancel()
        Task {
            await t?.value   // 진행 중이던 촬영이 정리된 뒤에 인코딩 시작
            await encode()
        }
    }

    func abort() {
        askStop = false
        quoteTask?.cancel(); quoteTask = nil
        task?.cancel(); task = nil
        applyDim(false)
        UIApplication.shared.isIdleTimerDisabled = false
        phase = .idle
        nextShot = nil
    }

    func encodeExisting() {
        guard count > 0 else { return }
        Task { await encode() }
    }

    // MARK: 앱 활성/백그라운드 처리
    func sceneChanged(_ scene: ScenePhase) {
        isActive = (scene != .background)
        guard phase == .running else { return }
        switch scene {
        case .active:
            applyDim(true)
        case .background:
            applyDim(false)
        default:
            break
        }
    }

    // 촬영 중 화면 밝기 낮추기
    private func applyDim(_ on: Bool) {
        guard let screen else { return }
        if on {
            guard dimEnabled else { return }
            if savedBrightness == nil { savedBrightness = screen.brightness }
            screen.brightness = CGFloat(dimLevel)
        } else if let b = savedBrightness {
            screen.brightness = b
            savedBrightness = nil
        }
    }

    // MARK: 촬영 루프 (시작 즉시 첫 장, 이후 설정한 간격마다)
    private func loop() async {
        var next = Date()
        while !Task.isCancelled && count < Config.maxFrames && usedBytes < capBytes {
            nextShot = next
            let wait = next.timeIntervalSinceNow
            if wait > 0 { try? await Task.sleep(for: .seconds(wait)) }
            if Task.isCancelled { return }

            // 백그라운드였거나 시간이 많이 지났다면 놓친 회차는 AwayImage 프레임으로 대체
            if !isActive || -next.timeIntervalSinceNow > Config.lateTolerance {
                repeat {
                    await addPlaceholder(date: next)
                    next = next.addingTimeInterval(interval)
                } while -next.timeIntervalSinceNow > Config.lateTolerance && count < Config.maxFrames && !Task.isCancelled
                continue
            }
            await shoot()
            await camera.stopPreview()   // 촬영이 끝나면 카메라가 확실히 꺼지도록 재확인
            next = next.addingTimeInterval(interval)
        }
        guard !Task.isCancelled else { return }
        if usedBytes >= capBytes { message = "허용 용량에 도달해 촬영을 마쳤어요" }
        task = nil
        await encode()
    }

    private func nextFrameURL(away: Bool = false) -> (URL, Int) {
        let idx = Store.frameFiles().count + 1
        let name = String(format: away ? "frame_%04d_away.jpg" : "frame_%04d.jpg", idx)
        return (Store.framesDir.appendingPathComponent(name), idx)
    }

    private func shoot() async {
        do {
            let data = try await camera.capture()
            let (url, idx) = nextFrameURL()
            try data.write(to: url)
            count = idx
            usedBytes += Int64(data.count)
            checkStorage()
            StatsLog.append(type: "photo", interval: interval)
            flashCount()
        } catch {
            if error is CancellationError { return }
            message = error.localizedDescription
            await addPlaceholder(date: Date())   // 촬영 실패도 AwayImage로 대체
        }
    }

    private func addPlaceholder(date: Date) async {
        var size = Store.lastFrameSize() ?? CGSize(width: 1440, height: 1080)
        let longSide = max(size.width, size.height)
        if longSide > 1600 {
            let s = 1600 / longSide
            size = CGSize(width: (size.width * s).rounded(), height: (size.height * s).rounded())
        }
        let finalSize = size
        let style = StampStyle.load()
        let data = await Task.detached(priority: .utility) {
            PlaceholderRenderer.make(size: finalSize, date: date, style: style)
        }.value
        guard let data else { return }
        let (url, idx) = nextFrameURL(away: true)
        do {
            try data.write(to: url)
            // 파일 시각을 '놓친 회차의 시각'으로 기록 (System_record_style 계산에 사용)
            try? FileManager.default.setAttributes([.creationDate: date], ofItemAtPath: url.path)
            count = idx
            missed += 1
            usedBytes += Int64(data.count)
            checkStorage()
            StatsLog.append(type: "away", interval: interval)
        } catch {
            message = error.localizedDescription
        }
    }

    private func checkStorage() {
        storageWarning = Double(usedBytes) >= Double(capBytes) * Config.storageWarnRatio
    }

    private func progressReporter() -> @Sendable (Double) -> Void {
        { [weak self] p in
            Task { @MainActor in self?.progress = p }
        }
    }

    private func encode() async {
        askStop = false
        quoteTask?.cancel(); quoteTask = nil
        await camera.stopPreview()
        previewReady = false
        applyDim(false)
        phase = .encoding
        encodingText = "순간순간을 후회하지 않도록."
        progress = 0
        nextShot = nil
        do {
            try await VideoEncoder.encode(files: Store.frameFiles(), to: Store.videoURL, fps: Prefs.fps,
                                          layout: .record, progress: progressReporter())
            prepareShareFile()
            phase = .review
        } catch {
            message = error.localizedDescription
            phase = .idle
        }
        UIApplication.shared.isIdleTimerDisabled = false
    }

    // 촬영 순간: 좌하단 숫자를 0.5초 초록색으로 보여준 뒤, 0.5초에 걸쳐 원래대로 (화면 쪽 애니메이션)
    private func flashCount() {
        flashGreen = true
        Task {
            try? await Task.sleep(for: .seconds(0.5))
            flashGreen = false
        }
    }

    // MARK: 영상 저장(사진 앱) / 공유 / 다시 인코딩
    /// 꾸미기 설정을 바꾼 뒤 같은 사진으로 최종 영상을 다시 만듦
    func reencodeWithStyle() {
        Task { await encode() }
    }

    private func prepareShareFile() {
        let dest = Store.docs.appendingPathComponent(Store.namedVideoName())
        try? FileManager.default.removeItem(at: dest)
        shareURL = (try? FileManager.default.copyItem(at: Store.videoURL, to: dest)) != nil ? dest : Store.videoURL
    }

    func saveToPhotos() {
        Task {
            let status = await PHPhotoLibrary.requestAuthorization(for: .addOnly)
            guard status == .authorized || status == .limited else {
                showPopup("사진 권한이 필요해요")
                return
            }
            guard let url = shareURL else { return }
            do {
                try await PHPhotoLibrary.shared().performChanges {
                    let req = PHAssetCreationRequest.forAsset()
                    let opts = PHAssetResourceCreationOptions()
                    opts.originalFilename = url.lastPathComponent
                    req.addResource(with: .video, fileURL: url, options: opts)
                }
                showPopup("저장 완료!")
            } catch {
                showPopup("저장하지 못했어요")
            }
        }
    }

    // 중앙 팝업: 2초 유지 후 1초 동안 페이드 아웃 (버튼 없음)
    private func showPopup(_ text: String) {
        popupOpacity = 1
        popupText = text
        Task {
            try? await Task.sleep(for: .seconds(2))
            withAnimation(.easeOut(duration: 1)) { popupOpacity = 0 }
            try? await Task.sleep(for: .seconds(1))
            if popupOpacity == 0 { popupText = nil }
        }
    }

    // MARK: 검토 후 정리 (원본 영상 저장 여부 → 사진 삭제 여부)
    func reviewDone() { askOriginal = true }

    func answerOriginal(save: Bool) {
        askOriginal = false
        if save {
            Task { await encodeOriginalAndMove() }
        } else {
            scheduleAskDelete()
        }
    }

    private func encodeOriginalAndMove() async {
        phase = .encoding
        encodingText = "순간순간을 후회하지 않도록."
        progress = 0
        do {
            try await VideoEncoder.encode(files: Store.frameFiles(), to: Store.originalURL, fps: Prefs.fps,
                                          layout: .original, progress: progressReporter())
            phase = .review
            try? await Task.sleep(for: .seconds(0.4))
            moverPurpose = .original
            moverFile = Store.originalURL
            showMover = true
        } catch {
            message = error.localizedDescription
            phase = .review
            scheduleAskDelete()
        }
    }

    private func scheduleAskDelete() {
        Task {
            try? await Task.sleep(for: .seconds(0.5))
            askDelete = true
        }
    }

    func deleteFrames() {
        for f in Store.frameFiles() { try? FileManager.default.removeItem(at: f) }
        Store.removeLeftovers()
        count = 0
        message = "사진을 모두 삭제했습니다"
        phase = .finished
    }

    func prepareZip() {
        var coordError: NSError?
        var result: URL?
        let dest = Store.zipURL
        NSFileCoordinator().coordinate(readingItemAt: Store.framesDir, options: [.forUploading], error: &coordError) { tmp in
            try? FileManager.default.removeItem(at: dest)
            if (try? FileManager.default.copyItem(at: tmp, to: dest)) != nil { result = dest }
        }
        if let r = result, coordError == nil {
            moverPurpose = .zip
            moverFile = r
            showMover = true
        } else {
            message = AppError.zip.localizedDescription
            scheduleAskDelete()
        }
    }

    func moverFinished(_ result: Result<URL, Error>) {
        switch moverPurpose {
        case .original:
            if case .failure(let e) = result { message = e.localizedDescription }
            scheduleAskDelete()   // 저장하든 취소하든 다음 질문으로
        case .zip:
            switch result {
            case .success:
                for f in Store.frameFiles() { try? FileManager.default.removeItem(at: f) }  // 낱장 중복 제거 (압축본은 파일 앱에 있음)
                Store.removeLeftovers()
                count = 0
                message = "압축 파일을 저장했습니다"
                phase = .finished
            case .failure:
                message = "압축 저장이 취소되었습니다 (사진은 그대로 남아 있습니다)"
                scheduleAskDelete()
            }
        }
    }

    // MARK: 개발자 모드용
    func devAddPlaceholder() async { await addPlaceholder(date: Date()) }

    func devClearFrames() {
        for f in Store.frameFiles() { try? FileManager.default.removeItem(at: f) }
        count = 0
        missed = 0
    }

    func reset() {
        message = ""
        phase = .idle
    }
}

// MARK: - 화면
@main
struct StudyTimelapseApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

private let beige = UIConfig.shared.color("Colors", "background") ?? Color(red: 0.96, green: 0.92, blue: 0.84)
private let ink = UIConfig.shared.color("Colors", "ink") ?? Color(red: 0.33, green: 0.24, blue: 0.16)

struct ContentView: View {
    @StateObject private var rec = Recorder()
    @Environment(\.scenePhase) private var scenePhase
    @State private var expanded = false
    @State private var clockMode = 0        // 0 검정, 1 아날로그, 2 디지털, 3 플립
    @State private var showSettings = false
    @State private var showProfile = false
    @StateObject private var acct = AccountModel()
    @State private var showEgg = false
    @State private var showGoalSheet = false
    @State private var showDev = false
    @State private var showStopwatch = false
    @State private var showStyleSheet = false
    @State private var tutorialStage = 0     // 0 없음, 1 설명 중, 2 마무리 문구
    @State private var tutorialPage = 0
    @AppStorage("tutorialDone") private var tutorialDone = false
    @AppStorage("helpTipDismissed") private var helpTipDismissed = false
    @AppStorage("ddayShow") private var ddayShow = false
    @AppStorage("ddayName") private var ddayName = ""
    @AppStorage("ddayDate") private var ddayDate = 0.0
    @StateObject private var sw = Stopwatch()
    @StateObject private var sn = SuneungModel()
    @State private var suneungOn = false
    @AppStorage("goalText") private var goalText = ""
    @AppStorage("showGoal") private var showGoalText = true
    @AppStorage("showMotiv") private var showMotiv = true

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.ignoresSafeArea()
                    .alert("사용된 \(rec.count)장을 삭제할까요?", isPresented: $rec.askDelete) {
                        Button("예", role: .destructive) { rec.deleteFrames() }
                        Button("아니요") { rec.prepareZip() }
                    } message: {
                        Text("‘아니요’를 누르면 \(rec.count)장을 하나의 압축 파일로 만들어 파일 앱에 저장합니다.")
                    }

                switch rec.phase {
                case .idle, .intro: idleView(geo)
                case .running: runningView(geo)
                case .encoding:
                    EncodingView(text: rec.encodingText, progress: rec.progress)
                case .review: ReviewView(rec: rec)
                case .finished:
                    VStack(spacing: 16) {
                        Text(rec.message).foregroundStyle(.white)
                        VideoActions(rec: rec)
                        Button("처음으로") { rec.reset() }
                    }
                }

                // 수능시계 종료 팝업 (소리 없음)
                if sn.showEndPopup {
                    SuneungEndPopup(sn: sn)
                }

                // 저장 완료 등 중앙 팝업 (버튼 없음, 2초 유지 후 1초 페이드 아웃)
                if let t = rec.popupText {
                    Text(t)
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 34).padding(.vertical, 20)
                        .background(Color(white: 0.18), in: RoundedRectangle(cornerRadius: 18))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.25)))
                        .opacity(rec.popupOpacity)
                        .allowsHitTesting(false)
                }
            }
            .alert("원본 영상도 저장할까요?", isPresented: $rec.askOriginal) {
                Button("예") { rec.answerOriginal(save: true) }
                Button("아니요") { rec.answerOriginal(save: false) }
            } message: {
                Text("원본은 사진만 이어 붙인 영상입니다 (‘Today’s your Record’ 레이아웃 없음).")
            }
            .fileMover(isPresented: $rec.showMover, file: rec.moverFile) { result in
                rec.moverFinished(result)
            }
        }
        .ignoresSafeArea()
        .alert("⚠️ 기록을 중단하시겠습니까?", isPresented: $rec.askStop) {
            Button("예", role: .destructive) { rec.stopAndEncode() }
            Button("아니요", role: .cancel) {}
        } message: {
            Text("‘예’를 누르면 지금까지 찍은 사진으로 영상을 만듭니다.")
        }
        .onChange(of: scenePhase) { _, new in rec.sceneChanged(new) }
        .onChange(of: rec.phase) { old, new in
            if new == .running {
                // 촬영 시작: 아날로그 시계가 기본으로 켜진 상태
                clockMode = 1
                suneungOn = false
                showStopwatch = false
                expanded = false
            } else if old == .running {
                // 촬영 종료: 촬영 화면의 스톱워치·수능시계·시계 값을 모두 초기화
                sw.reset()
                sn.reset()
                showStopwatch = false
                suneungOn = false
                clockMode = 0
                expanded = false
            }
        }
        .statusBarHidden(true)
    }

    private func isWindowed(_ geo: GeometryProxy) -> Bool {
        let bounds = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.screen.bounds ?? UIScreen.main.bounds
        return geo.size.width < bounds.width - 2 || geo.size.height < bounds.height - 2
    }

    // MARK: 시작 화면 (베이지 배경 + 40% 카메라 미리보기). 위치·색·크기·문구는 ui_config.txt로 변경 가능
    private func idleView(_ geo: GeometryProxy) -> some View {
        let w = geo.size.width, h = geo.size.height
        let cfg = UIConfig.shared
        let title = cfg.elem("Title_set")
        let dday = cfg.elem("DDay_set")
        let madeby = cfg.elem("Madeby_set")
        let intro = cfg.elem("Intro_set")
        let previewCfg = cfg.elem("Preview_set")
        let homeBtn = cfg.elem("HomeButtons_set")
        let titleSize = title.size ?? min(46, min(w, h) * 0.06)
        let titlePt = title.coord ?? CGPoint(x: 0.5, y: 0.1)
        let ddayPt = dday.coord ?? CGPoint(x: 0.5, y: (h * titlePt.y + titleSize * 0.5 + 24) / h)
        let previewScale = previewCfg.size ?? Config.previewScale
        let previewPt = previewCfg.coord ?? CGPoint(x: 0.5, y: 0.5)
        let btnPt = homeBtn.coord ?? CGPoint(x: 0.5, y: min(h - 140, h * 0.7 + 80) / h)
        let madePt = madeby.coord ?? CGPoint(x: 0.5, y: (h - 44) / h)
        let introPt = intro.coord ?? CGPoint(x: 0.5, y: 0.5)
        let blurRadius: CGFloat = tutorialStage == 2 ? 14 : (showEgg ? 6 : 0)
        let tipText = cfg.value("Tutorial_set", "tip_text") ?? "여기를 누르면 이용방법을 다시 볼 수 있어요!"
        let endText = cfg.elem("Tutorial_set").text ?? "자, 이제 그럼 달려볼까요..?"
        let showTip = tutorialDone && !helpTipDismissed && tutorialStage == 0

        return ZStack {
            beige.opacity(rec.beigeOpacity).ignoresSafeArea()

            ZStack {
                Text(title.text ?? "Your 16 Hours Isn't It?")
                    .font(.system(size: titleSize, weight: .bold, design: .serif))
                    .italic(title.italic ?? false)
                    .foregroundStyle(title.color ?? ink)
                    .padding(12)
                    .contentShape(Rectangle())
                    .inspect("Title_set")
                    .position(x: w * titlePt.x, y: h * titlePt.y)

                // 디데이 (목표 탭에서 설정): 배경과 어울리는 고정 색, 이탤릭
                if ddayShow, let label = DDay.label(name: ddayName, dateInterval: ddayDate) {
                    Text(label)
                        .font(.system(size: dday.size ?? min(26, min(w, h) * 0.034), weight: .medium, design: .serif))
                        .italic(dday.italic ?? true)
                        .foregroundStyle(dday.color ?? Color(red: 0.62, green: 0.38, blue: 0.26))
                        .inspect("DDay_set")
                        .position(x: w * ddayPt.x, y: h * ddayPt.y)
                }

                CameraPreview(camera: rec.camera, ready: rec.previewReady)
                    .frame(width: w * previewScale, height: h * previewScale)
                    .background(Color.black.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .inspect("Preview_set")
                    .position(x: w * previewPt.x, y: h * previewPt.y)

                VStack(spacing: 10) {
                    Button("촬영 시작") { rec.start() }
                        .buttonStyle(.borderedProminent)
                        .tint(ink)
                    HStack(spacing: 24) {
                        Button { showGoalSheet = true } label: { Label("목표", systemImage: "target") }
                        Button { showStyleSheet = true } label: { Label("꾸미기", systemImage: "paintbrush") }
                        Button { showSettings = true } label: { Label("설정", systemImage: "gearshape") }
                    }
                    .foregroundStyle(ink)
                    if rec.count > 0 {
                        Button("남은 \(rec.count)장으로 바로 인코딩") { rec.encodeExisting() }
                            .font(.footnote).foregroundStyle(ink)
                    }
                    if !rec.message.isEmpty {
                        Text(rec.message).font(.footnote).foregroundStyle(.red.opacity(0.8))
                    }
                }
                .inspect("HomeButtons_set")
                .position(x: w * btnPt.x, y: h * btnPt.y)

                // 이스터에그: 평범한 글씨처럼 보이지만 누르면(주변 10pt 포함) 창이 열림
                Text(madeby.text ?? "우리 어플은 이용자의 촬영된 사진(또는 출력 영상 등 기기 내에서 촬영된 모든 파일)을 수집하지 않아요!\nMade by YNDHSIA with Claude")
                    .font(.system(size: madeby.size ?? 11))
                    .italic(madeby.italic ?? true)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(madeby.color ?? ink.opacity(0.55))
                    .frame(maxWidth: w * 0.9)
                    .padding(10)
                    .contentShape(Rectangle())
                    .onTapGesture { showEgg = true }
                    .inspect("Madeby_set")
                    .position(x: w * madePt.x, y: h * madePt.y)

                // 우하단: 프로필 버튼 (아이콘 + 이름). 높이는 도움말 아이콘과 같고 폭은 이름 길이에 따라 달라짐
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button { showProfile = true } label: {
                            HStack(spacing: 6) {
                                ProfileBadge(acct: acct, size: 24)
                                Text(acct.displayName)
                                    .font(.system(size: 14))
                                    .foregroundStyle(ink)
                                    .lineLimit(1)
                            }
                            .padding(.leading, 2).padding(.trailing, 12).padding(.vertical, 2)
                            .background(Color.white.opacity(0.6), in: Capsule())
                            .inspect("Profile")
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 22)
                }

                // 좌상단: 개발자 모드 버튼 (whitelist.txt에 등록된 아이디로 로그인했을 때만 보임)
                if acct.isDeveloper {
                    VStack {
                        HStack {
                            Button { showDev = true } label: {
                                Image(systemName: "hammer")
                                    .font(.system(size: 20))
                                    .foregroundStyle(ink.opacity(0.75))
                                    .padding(8)
                                    .background(Color.white.opacity(0.6), in: Circle())
                                    .inspect("DevButton")
                            }
                            .buttonStyle(.plain)
                            Spacer()
                        }
                        Spacer()
                    }
                    .padding(.leading, 20)
                    .padding(.top, 16)
                }

                // 좌하단: 도움말(튜토리얼 다시 보기) 아이콘 + 안내 팝업
                VStack {
                    Spacer()
                    HStack(spacing: 10) {
                        Button { startTutorial() } label: {
                            Image(systemName: "questionmark.circle")
                                .font(.system(size: 28))
                                .foregroundStyle(ink.opacity(0.75))
                                .inspect("Help")
                        }
                        if showTip {
                            HStack(spacing: 8) {
                                Text(tipText)
                                    .font(.system(size: 12))
                                    .foregroundStyle(ink)
                                Button { helpTipDismissed = true } label: {
                                    Image(systemName: "xmark")
                                        .font(.system(size: 11, weight: .bold))
                                        .foregroundStyle(ink.opacity(0.7))
                                        .padding(4)
                                }
                            }
                            .padding(.horizontal, 12).padding(.vertical, 8)
                            .background(Color.white.opacity(0.88), in: RoundedRectangle(cornerRadius: 12))
                            .shadow(color: .black.opacity(0.12), radius: 4)
                        }
                        Spacer()
                    }
                    .padding(.leading, 20)
                    .padding(.bottom, 22)
                }
            }
            .opacity(rec.contentOpacity)
            .blur(radius: blurRadius)
            .animation(.easeInOut(duration: 0.4), value: tutorialStage)

            Text(intro.text ?? "자, 시작해볼까요? 오늘도 화이팅!")
                .font(.system(size: intro.size ?? 34, weight: .semibold, design: .serif))
                .italic(intro.italic ?? false)
                .foregroundStyle(intro.color ?? ink)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
                .position(x: w * introPt.x, y: h * introPt.y)
                .opacity(rec.messageOpacity)

            // 첫 실행 튜토리얼 (홈 위에 덮음)
            if tutorialStage == 1 {
                TutorialView(page: $tutorialPage, onFinish: finishTutorial)
                    .transition(.opacity)
            }
            // 튜토리얼 마무리 문구 (홈은 블러 처리된 상태)
            if tutorialStage == 2 {
                Text(endText)
                    .font(.system(size: 30, weight: .semibold, design: .serif))
                    .foregroundStyle(ink)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                    .transition(.opacity)
            }

            if showEgg {
                Color.black.opacity(0.5).ignoresSafeArea()
                    .onTapGesture { showEgg = false }
                Group {
                    if let ui = ImageLocator.load(key: "ThankYou_Location", fallbackName: "Thank_you_for_use") {
                        Image(uiImage: ui).resizable().scaledToFit()
                    } else {
                        Text("Thank you for using 💛").font(.title2).foregroundStyle(ink).padding(30)
                    }
                }
                .frame(maxWidth: w * 0.7, maxHeight: h * 0.7)
                .padding(12)
                .background(Color.white, in: RoundedRectangle(cornerRadius: 18))
                .shadow(radius: 24)
                .onTapGesture { showEgg = false }
            }
        }
        .onAppear {
            rec.startPreview()
            if !tutorialDone && tutorialStage == 0 { startTutorial() }
        }
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showProfile) { ProfileView(acct: acct) }
        .sheet(isPresented: $showGoalSheet) { GoalView() }
        .sheet(isPresented: $showDev) { DevView(rec: rec) }
        .sheet(isPresented: $showStyleSheet) { RecordStyleView(rec: rec, canReencode: false) }
    }

    private func startTutorial() {
        tutorialPage = 0
        withAnimation(.easeInOut(duration: 0.3)) { tutorialStage = 1 }
    }

    // 튜토리얼 끝(또는 건너뛰기): 홈을 블러 처리하고 문구를 잠시 보여준 뒤 원래 홈으로
    private func finishTutorial() {
        tutorialDone = true
        withAnimation(.easeInOut(duration: 0.4)) { tutorialStage = 2 }
        Task {
            try? await Task.sleep(for: .seconds(1.8))
            withAnimation(.easeOut(duration: 0.5)) { tutorialStage = 0 }
        }
    }

    // MARK: 촬영 중: 거의 검은 화면 + 구석의 작은 표시들. 위치·색·크기는 ui_config.txt로 변경 가능
    private func runningView(_ geo: GeometryProxy) -> some View {
        let w = geo.size.width, h = geo.size.height
        let side = min(w, h)
        let cfg = UIConfig.shared
        let goalCfg = cfg.elem("Goal_set")
        let motivCfg = cfg.elem("Motiv_set")
        let clockCfg = cfg.elem("Clock_set")
        let swCfg = cfg.elem("Stopwatch_set")
        let btnCfg = cfg.elem("Buttons_set")
        let warnCfg = cfg.elem("StorageWarning_set")
        let counterCfg = cfg.elem("Counter_set")
        let clockSide = side * (showStopwatch ? 0.4 : 0.6)
        let clockPt = clockCfg.coord ?? CGPoint(x: 0.5, y: showStopwatch ? 0.36 : 0.5)
        let swPt = swCfg.coord ?? CGPoint(x: 0.5, y: 0.72)
        let goalPt = goalCfg.coord ?? CGPoint(x: 0.5, y: 0.09)
        let motivPt = motivCfg.coord ?? CGPoint(x: 0.5, y: (h - 112) / h)
        let btnPt = btnCfg.coord ?? CGPoint(x: 0.5, y: (h - 36) / h)
        let warnPt = warnCfg.coord ?? CGPoint(x: 0.5, y: (h - 72) / h)
        let goalOK = showGoalText && !goalText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty

        return ZStack {
            // 목표 (중앙 상단)
            if goalOK {
                MyungjoText(text: goalText, size: goalCfg.size ?? min(30, side * 0.04),
                            color: goalCfg.color, italic: goalCfg.italic ?? false)
                    .frame(maxWidth: w * 0.8)
                    .inspect("Goal_set")
                    .position(x: w * goalPt.x, y: h * goalPt.y)
                    .allowsHitTesting(false)
            }

            // 시계 (하단 '시계' 버튼: 검정 → 아날로그 → 디지털 → 플립 → 검정)
            if suneungOn {
                let snSide = clockSide * 0.6                         // 기존 시계의 60%
                let ringR = snSide * 0.56                            // 바깥 동심원 반지름
                let listW = max(190, min(300, w / 2 - ringR - 24))   // 시계와 겹치지 않는 목록 너비
                SuneungClockGroup(sn: sn, clockSide: snSide)
                    .inspect("Clock_set")
                    .position(x: w * clockPt.x, y: h * clockPt.y)
                SuneungButtons(sn: sn)
                    .inspect("SuneungButtons")
                    .position(x: w * clockPt.x, y: h * clockPt.y + ringR + 28)
                SuneungList(sn: sn, width: listW)
                    .inspect("SuneungList")
                    .position(x: 10 + listW / 2, y: h * clockPt.y)   // 왼쪽 끝에서 10pt
            } else if clockMode == 1 {
                AnalogClock()
                    .frame(width: clockSide, height: clockSide)
                    .inspect("Clock_set")
                    .position(x: w * clockPt.x, y: h * clockPt.y)
                    .allowsHitTesting(false)
            } else if clockMode == 2 {
                DigitalClock()
                    .inspect("Clock_set")
                    .position(x: w * clockPt.x, y: h * clockPt.y)
                    .allowsHitTesting(false)
            } else if clockMode == 3 {
                // 플립 시계는 이전보다 3% 작게
                FlipClock(cardWidth: min(w * 0.17, side * 0.22) * 0.97 * (showStopwatch ? 0.7 : 1))
                    .inspect("Clock_set")
                    .position(x: w * clockPt.x, y: h * clockPt.y)
                    .allowsHitTesting(false)
            }

            // 스톱워치
            if showStopwatch {
                StopwatchPanel(sw: sw)
                    .inspect("Stopwatch_set")
                    .position(x: w * swPt.x, y: h * swPt.y)
            }

            // 동기부여 문구 (중앙 하단, 버튼보다 조금 위). 누르면 랜덤으로 다른 문구
            if showMotiv, let q = rec.motivQuote {
                MyungjoText(text: q, size: motivCfg.size ?? min(22, side * 0.03),
                            color: motivCfg.color, italic: motivCfg.italic ?? false)
                    .frame(maxWidth: w * 0.8)
                    .padding(8)
                    .contentShape(Rectangle())
                    .onTapGesture { rec.nextQuote() }
                    .inspect("Motiv_set")
                    .position(x: w * motivPt.x, y: h * motivPt.y)
            }

            // 허용 용량의 80% 도달 경고 (버튼 바로 위)
            if rec.storageWarning {
                Text(warnCfg.text ?? "곧 허용 용량에 도달해요!")
                    .font(.system(size: warnCfg.size ?? 11, weight: .medium))
                    .foregroundStyle(warnCfg.color ?? Color.orange)
                    .inspect("StorageWarning_set")
                    .position(x: w * warnPt.x, y: h * warnPt.y)
                    .allowsHitTesting(false)
            }

            // 하단 중앙: 작고 어두운 실제 버튼
            HStack(spacing: 10) {
                MiniButton("시계") {
                    if suneungOn {
                        suneungOn = false     // 수능시계가 꺼지고
                        clockMode = 1         // 시계(아날로그)가 켜짐
                    } else {
                        clockMode = (clockMode + 1) % 4
                    }
                }
                MiniButton("수능시계") {
                    clockMode = 0             // 켜져 있던 시계는 꺼짐
                    suneungOn.toggle()        // 수능시계를 끄면 시계도 꺼진 상태로 유지
                }
                MiniButton("스톱워치") { showStopwatch.toggle() }
                MiniButton("정지") { rec.askStop = true }
            }
            .inspect("Buttons_set")
            .position(x: w * btnPt.x, y: h * btnPt.y)

            // 좌하단: 촬영 수 / 우하단: 창 모드 안내
            VStack {
                Spacer()
                HStack(alignment: .bottom) {
                    VStack(alignment: .leading, spacing: 6) {
                        if expanded {
                            if let n = rec.nextShot {
                                Text("다음 \(n.formatted(date: .omitted, time: .shortened)) · 대체 \(rec.missed)")
                                    .font(.system(size: 10)).foregroundStyle(.gray)
                            }
                            Button("종료 후 인코딩") { rec.stopAndEncode() }.font(.system(size: 11))
                            Button("중단", role: .destructive) { rec.abort() }.font(.system(size: 11))
                        }
                        // 촬영 순간 0.5초 초록색 → 0.5초에 걸쳐 원래 색으로
                        Text("● \(rec.count)")
                            .font(.system(size: counterCfg.size ?? 10))
                            .foregroundStyle(rec.flashGreen ? Color.green : (counterCfg.color ?? Color.white.opacity(0.35)))
                            .animation(rec.flashGreen ? nil : .easeOut(duration: 0.5), value: rec.flashGreen)
                            .onTapGesture { expanded.toggle() }
                            .inspect("Counter_set")
                    }
                    Spacer()
                    if isWindowed(geo) { ExpandHint() }
                }
            }
            .padding(10)
        }
    }

}

// MARK: - 첫 실행 튜토리얼 (홈 위에 덮는 안내 카드)
struct TutorialPage {
    let icon: String
    let title: String
    let body: String
}

struct TutorialView: View {
    @Binding var page: Int
    let onFinish: () -> Void

    private let pages: [TutorialPage] = [
        TutorialPage(icon: "sparkles", title: "Your 16 Hours Isn't It?",
                     body: "공부하는 하루를 사진으로 남겨서 타임랩스 영상으로 만들어 주는 앱이에요. 사용법을 간단히 알려드릴게요."),
        TutorialPage(icon: "camera.viewfinder", title: "시작 화면",
                     body: "가운데 카메라 화면으로 앵글과 얼굴 위치를 먼저 확인하고, ‘촬영 시작’을 누르세요. 시작하면 카메라 화면은 사라지고 촬영이 시작돼요."),
        TutorialPage(icon: "speaker.slash", title: "무음 촬영",
                     body: "정한 간격(기본 120초)마다 셔터음 없이 한 장씩 찍고, 사진 우측 상단에 날짜와 시간을 새겨요. 앱이 전체 화면으로 켜져 있어야 촬영돼요. 충전기를 꽂아 두면 좋아요."),
        TutorialPage(icon: "clock", title: "촬영 화면",
                     body: "화면은 거의 검게 유지돼요. 아래 작은 버튼으로 시계(아날로그·디지털·플립)와 스톱워치를 켜고, 정지를 눌러 기록을 마칠 수 있어요. 문구를 누르면 다른 문구로 바뀌고, 좌하단 숫자는 찍은 장수예요."),
        TutorialPage(icon: "target", title: "목표 · 디데이 · 통계",
                     body: "목표 탭에서 목표 문구와 디데이를 정하면 촬영 화면과 홈에 보여요. 오른쪽 아래 프로필의 통계에서는 지금까지 찍힌 순간과 시간을 볼 수 있어요."),
        TutorialPage(icon: "film", title: "영상 만들기",
                     body: "촬영이 끝나면 사진을 영상으로 만들어요. ‘커스터마이징’에서 왼쪽 문구나 타임테이블을 바꾸고, 영상은 사진 앱에 저장하거나 공유해요. 그다음 원본 영상 저장과 사진 삭제 여부를 물어봐요."),
        TutorialPage(icon: "gearshape", title: "설정과 용량",
                     body: "설정에서 프레임(fps), 촬영 간격, 밝기와 저장 용량을 확인하고, 꾸미기에서 타임스탬프 디자인을 바꿀 수 있어요. 앱은 남은 용량의 70%까지만 쓰고, 80%에 가까워지면 알려줘요.")
    ]

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.55).ignoresSafeArea()
                VStack(spacing: 14) {
                    Image(systemName: pages[page].icon)
                        .font(.system(size: 44))
                        .foregroundStyle(ink)
                    Text(pages[page].title)
                        .font(.system(size: 24, weight: .bold, design: .serif))
                        .foregroundStyle(ink)
                        .multilineTextAlignment(.center)
                    Text(pages[page].body)
                        .font(.system(size: 16))
                        .foregroundStyle(ink.opacity(0.85))
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 6) {
                        ForEach(0..<pages.count, id: \.self) { i in
                            Circle()
                                .fill(i == page ? ink : ink.opacity(0.25))
                                .frame(width: 7, height: 7)
                        }
                    }
                    .padding(.top, 4)
                    HStack {
                        if page < pages.count - 1 {
                            Button("건너뛰기") { onFinish() }
                                .foregroundStyle(ink.opacity(0.6))
                        }
                        Spacer()
                        if page > 0 {
                            Button("이전") { withAnimation { page -= 1 } }
                                .foregroundStyle(ink)
                        }
                        if page < pages.count - 1 {
                            Button("다음") { withAnimation { page += 1 } }
                                .buttonStyle(.borderedProminent)
                                .tint(ink)
                        } else {
                            Button("시작하기") { onFinish() }
                                .buttonStyle(.borderedProminent)
                                .tint(ink)
                        }
                    }
                    .padding(.top, 6)
                }
                .padding(28)
                .frame(maxWidth: min(geo.size.width * 0.86, 560))
                .background(beige, in: RoundedRectangle(cornerRadius: 22))
                .shadow(radius: 20)
            }
        }
    }
}

// MARK: - 수능시계 (무알림·무음 타이머)
struct SuneungItem: Codable, Identifiable, Equatable {
    var id = UUID()
    var name: String
    var startMin: Int       // 하루 중 시작 시각(분)
    var endMin: Int         // 하루 중 종료 시각(분)

    var minutes: Int { max(0, endMin - startMin) }

    /// 과목 | 08:40 ~ 10:00 | 80분
    var line: String {
        let s = String(format: "%02d:%02d", startMin / 60, startMin % 60)
        let e = String(format: "%02d:%02d", endMin / 60, endMin % 60)
        return "\(name) | \(s) ~ \(e) | \(minutes)분"
    }
}

enum SuneungStore {
    static let key = "suneungItems"
    static let maxItems = 10

    static func load() -> [SuneungItem] {
        guard let d = UserDefaults.standard.data(forKey: key),
              let a = try? JSONDecoder().decode([SuneungItem].self, from: d) else { return [] }
        return Array(a.prefix(maxItems))
    }

    static func save(_ items: [SuneungItem]) {
        if let d = try? JSONEncoder().encode(Array(items.prefix(maxItems))) {
            UserDefaults.standard.set(d, forKey: key)
        }
    }
}

/// 시험 진행 상태. 시계 화면을 껐다 켜도 진행이 유지되고, 종료 시각에 소리 없이 팝업만 띄움
@MainActor
final class SuneungModel: ObservableObject {
    @Published var items: [SuneungItem] = SuneungStore.load()
    @Published var selected: UUID?
    @Published var running = false
    @Published var finished = false
    @Published var showEndPopup = false
    private(set) var startDate: Date?
    private var base: Double = 0      // 시험 시작 시각(하루 중 초)
    private var total: Double = 0     // 시험 시간(초)
    private var endTask: Task<Void, Never>?

    init() { selected = items.first?.id }

    var selectedItem: SuneungItem? { items.first { $0.id == selected } }

    /// 설정에서 바꾼 과목 목록을 다시 불러옴 (진행 중이면 건드리지 않음)
    func reload() {
        guard !running else { return }
        items = SuneungStore.load()
        if selectedItem == nil { selected = items.first?.id }
    }

    func start() {
        guard !running, let it = selectedItem, it.minutes > 0 else { return }
        base = Double(it.startMin) * 60      // 시침·분침이 시작 시각에, 초침은 항상 0초에서 시작
        total = Double(it.minutes) * 60
        startDate = Date()
        finished = false
        running = true
        endTask?.cancel()
        let wait = total
        endTask = Task {
            try? await Task.sleep(for: .seconds(wait))
            if !Task.isCancelled { finish() }
        }
    }

    private func finish() {
        endTask = nil
        running = false
        finished = true
        showEndPopup = true
    }

    func reset() {
        endTask?.cancel()
        endTask = nil
        running = false
        finished = false
        startDate = nil
        showEndPopup = false
    }

    /// 시계에 표시할 '하루 중 초'
    func simSeconds(at date: Date) -> Double {
        if running, let s = startDate { return base + min(max(0, date.timeIntervalSince(s)), total) }
        if finished { return base + total }
        if let it = selectedItem { return Double(it.startMin) * 60 }
        return 0
    }
}

// 시계판: 5분 단위 굵은 선 + 1분 단위 가는 눈금 + 숫자
struct SuneungDial: View {
    let s: CGFloat

    var body: some View {
        let r = s / 2
        ZStack {
            Circle().stroke(Color.white.opacity(0.85), lineWidth: s * 0.012)
            ForEach(0..<60, id: \.self) { i in
                let major = i % 5 == 0
                let len = major ? s * 0.07 : s * 0.025
                Rectangle()
                    .fill(Color.white.opacity(major ? 0.95 : 0.4))
                    .frame(width: major ? s * 0.012 : s * 0.005, height: len)
                    .offset(y: -(r - s * 0.02 - len / 2))
                    .rotationEffect(.degrees(Double(i) * 6))
            }
            ForEach(1...12, id: \.self) { n in
                Text("\(n)")
                    .font(.system(size: s * 0.09, weight: .light))
                    .foregroundStyle(Color.white.opacity(0.85))
                    .position(x: r + CGFloat(sin(Double(n) * .pi / 6)) * r * 0.70,
                              y: r - CGFloat(cos(Double(n) * .pi / 6)) * r * 0.70)
            }
        }
        .frame(width: s, height: s)
    }
}

// 시침 · 분침 · 초침 (tick = true면 1초에 한 칸씩 딱딱, false면 부드럽게)
struct SuneungHands: View {
    let sim: Double
    let tick: Bool
    let s: CGFloat

    var body: some View {
        let sec = tick ? (sim + 0.001).rounded(.down) : sim
        let secAngle = sec.truncatingRemainder(dividingBy: 60) * 6
        let minAngle = (sec / 60).truncatingRemainder(dividingBy: 60) * 6
        let hourAngle = (sec / 3600).truncatingRemainder(dividingBy: 12) * 30
        let r = s / 2
        ZStack {
            hand(length: r * 0.50, width: s * 0.025, angle: hourAngle, color: Color.white.opacity(0.95), tail: 0)
            hand(length: r * 0.78, width: s * 0.016, angle: minAngle, color: Color.white.opacity(0.95), tail: 0)
            hand(length: r * 0.86, width: s * 0.007, angle: secAngle,
                 color: Color(red: 0.95, green: 0.35, blue: 0.25), tail: r * 0.18)
            Circle().fill(Color.white).frame(width: s * 0.04, height: s * 0.04)
        }
        .frame(width: s, height: s)
    }

    private func hand(length: CGFloat, width: CGFloat, angle: Double, color: Color, tail: CGFloat) -> some View {
        Capsule()
            .fill(color)
            .frame(width: width, height: length + tail)
            .offset(y: (tail - length) / 2)
            .rotationEffect(.degrees(angle))
    }
}

struct SuneungClock: View {
    @ObservedObject var sn: SuneungModel
    let tick: Bool
    let side: CGFloat

    var body: some View {
        ZStack {
            // 바깥 동심원: 시계보다 조금 더 크게, 어두운 색
            Circle()
                .stroke(Color(white: 0.3), lineWidth: side * 0.03)
                .frame(width: side * 1.12, height: side * 1.12)
            SuneungDial(s: side)
            if sn.running, let start = sn.startDate {
                if tick {
                    TimelineView(.periodic(from: start, by: 1)) { ctx in
                        SuneungHands(sim: sn.simSeconds(at: ctx.date), tick: true, s: side)
                    }
                } else {
                    TimelineView(.animation) { ctx in
                        SuneungHands(sim: sn.simSeconds(at: ctx.date), tick: false, s: side)
                    }
                }
            } else {
                SuneungHands(sim: sn.simSeconds(at: Date()), tick: tick, s: side)
            }
        }
        .frame(width: side, height: side)
    }
}

// 촬영 화면의 수능시계: 시계는 화면 중앙, 과목 목록은 왼쪽 끝에서 10pt 떨어진 위치
struct SuneungClockGroup: View {
    @ObservedObject var sn: SuneungModel
    let clockSide: CGFloat
    @AppStorage("suneungSecondStyle") private var secondStyle = "smooth"

    var body: some View {
        SuneungClock(sn: sn, tick: secondStyle == "tick", side: clockSide)
            .onAppear { sn.reload() }
    }
}

struct SuneungButtons: View {
    @ObservedObject var sn: SuneungModel

    var body: some View {
        HStack(spacing: 10) {
            if sn.running {
                MiniButton("리셋") { sn.reset() }
            } else {
                MiniButton("시작") { sn.start() }
                if sn.finished { MiniButton("리셋") { sn.reset() } }
            }
        }
    }
}

struct SuneungList: View {
    @ObservedObject var sn: SuneungModel
    let width: CGFloat

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 6) {
                if sn.items.isEmpty {
                    Text("설정 > 수능시계에서\n과목을 추가해주세요")
                        .font(.system(size: 12))
                        .foregroundStyle(Color.white.opacity(0.5))
                }
                ForEach(sn.items) { it in
                    let isSel = it.id == sn.selected
                    Button {
                        if !sn.running { sn.selected = it.id }
                    } label: {
                        Text(it.line)
                            .font(.system(size: 14, design: .monospaced))
                            .lineLimit(1)
                            .minimumScaleFactor(0.6)
                            .foregroundStyle(Color.white.opacity(isSel ? 0.95 : 0.7))
                            .padding(.horizontal, 12).padding(.vertical, 8)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(white: isSel ? 0.30 : 0.17), in: RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.white.opacity(isSel ? 0.5 : 0), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .frame(width: width)
        .frame(maxHeight: 380)
    }
}

// 종료 팝업: 소리 없음
struct SuneungEndPopup: View {
    @ObservedObject var sn: SuneungModel

    var body: some View {
        ZStack {
            Color.black.opacity(0.55).ignoresSafeArea()
            VStack(spacing: 14) {
                Text("시험이 종료되었습니다.")
                    .font(.system(size: 26, weight: .semibold))
                    .foregroundStyle(Color.white)
                Text("⚠️ 펜을 놓아주세요.")
                    .font(.system(size: 22))
                    .foregroundStyle(Color.white.opacity(0.9))
                Button("확인") { sn.showEndPopup = false }
                    .buttonStyle(.borderedProminent)
                    .tint(Color(white: 0.38))
                    .padding(.top, 6)
            }
            .padding(34)
            .background(Color(white: 0.16), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.25)))
        }
    }
}

// MARK: - 설정 > 수능시계 탭
struct SuneungSettingsView: View {
    @AppStorage("suneungSecondStyle") private var secondStyle = "smooth"
    @State private var items = SuneungStore.load()
    @State private var editing: SuneungItem?

    var body: some View {
        Form {
            Section {
                Picker("초침", selection: $secondStyle) {
                    Text("부드럽게").tag("smooth")
                    Text("1초씩 딱딱").tag("tick")
                }
                .pickerStyle(.segmented)
            } header: {
                Text("초침 방식")
            }

            Section {
                ForEach(items) { it in
                    Button { editing = it } label: {
                        Text(it.line)
                            .font(.system(size: 15, design: .monospaced))
                            .foregroundStyle(Color.primary)
                    }
                }
                .onDelete { offsets in
                    items.remove(atOffsets: offsets)
                    SuneungStore.save(items)
                }
                Button("과목 추가") {
                    editing = SuneungItem(name: "", startMin: 8 * 60 + 40, endMin: 10 * 60)
                }
                .disabled(items.count >= SuneungStore.maxItems)
            } header: {
                Text("과목 (\(items.count)/\(SuneungStore.maxItems))")
            } footer: {
                Text("과목을 누르면 수정하고, 왼쪽으로 밀면 삭제돼요. 촬영 화면의 '수능시계' 버튼으로 사용해요.")
            }
        }
        .sheet(item: $editing) { item in
            SuneungEditor(item: item) { saved in
                if let i = items.firstIndex(where: { $0.id == saved.id }) {
                    items[i] = saved
                } else if items.count < SuneungStore.maxItems {
                    items.append(saved)
                }
                SuneungStore.save(items)
            }
        }
    }
}

struct SuneungEditor: View {
    @Environment(\.dismiss) private var dismiss
    @State private var item: SuneungItem
    let onSave: (SuneungItem) -> Void

    init(item: SuneungItem, onSave: @escaping (SuneungItem) -> Void) {
        _item = State(initialValue: item)
        self.onSave = onSave
    }

    private func dateBinding(_ minutes: Binding<Int>) -> Binding<Date> {
        Binding(
            get: {
                Calendar.current.date(bySettingHour: minutes.wrappedValue / 60, minute: minutes.wrappedValue % 60,
                                      second: 0, of: Date()) ?? Date()
            },
            set: {
                let c = Calendar.current.dateComponents([.hour, .minute], from: $0)
                minutes.wrappedValue = (c.hour ?? 0) * 60 + (c.minute ?? 0)
            }
        )
    }

    private var valid: Bool { item.endMin > item.startMin }

    var body: some View {
        NavigationStack {
            Form {
                TextField("과목명 (예: 국어)", text: $item.name)
                DatePicker("시작 시간", selection: dateBinding($item.startMin), displayedComponents: .hourAndMinute)
                DatePicker("종료 시간", selection: dateBinding($item.endMin), displayedComponents: .hourAndMinute)
                Text("시험 시간 \(item.minutes)분").foregroundStyle(.secondary)
                if !valid {
                    Text("종료 시간이 시작 시간보다 늦어야 해요").foregroundStyle(.red)
                }
            }
            .navigationTitle("과목")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("취소") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("저장") {
                        var out = item
                        let n = out.name.trimmingCharacters(in: .whitespaces)
                        out.name = n.isEmpty ? "과목" : n
                        onSave(out)
                        dismiss()
                    }
                    .disabled(!valid)
                }
            }
        }
    }
}

// MARK: - 작고 어두운 버튼 (scale로 크기 배율 조정)
struct MiniButton: View {
    let title: String
    let scale: CGFloat
    let action: () -> Void
    init(_ title: String, scale: CGFloat = 1, action: @escaping () -> Void) {
        self.title = title
        self.scale = scale
        self.action = action
    }
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11 * scale))
                .foregroundStyle(.white.opacity(0.4))
                .padding(.horizontal, 12 * scale).padding(.vertical, 6 * scale)
                .background(Color.white.opacity(0.08), in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

// MARK: - 사용자 서체 파일 (ttf/otf)
// 1) 설정 > 촬영 화면 > '서체 파일 선택'으로 고른 파일  2) 프로젝트(번들) 안의 ttf/otf 아무 파일 (goal_font* 우선)
enum FontLoader {
    private static let key = "customFontPS"

    static func fontFileURLs() -> [URL] {
        var result: [URL] = []
        let fm = FileManager.default
        let roots = [Bundle.main.bundleURL, Store.docs.appendingPathComponent("Fonts", isDirectory: true)]
        for root in roots {
            guard let en = fm.enumerator(at: root, includingPropertiesForKeys: nil) else { continue }
            for case let url as URL in en {
                let ext = url.pathExtension.lowercased()
                if ext == "ttf" || ext == "otf" { result.append(url) }
            }
        }
        return result
    }

    /// 등록된 사용자 서체의 PostScript 이름 (없으면 nil)
    static func customName() -> String? {
        if let saved = UserDefaults.standard.string(forKey: key), UIFont(name: saved, size: 12) != nil { return saved }
        let docsPath = Store.docs.path
        func score(_ u: URL) -> Int {
            let n = u.lastPathComponent.lowercased()
            var sc = 0
            if u.path.hasPrefix(docsPath) { sc += 100 }
            if n.hasPrefix("goal_font") { sc += 50 }
            if n.contains("myeong") || n.contains("myung") || n.contains("명조") { sc += 20 }
            return sc
        }
        for url in fontFileURLs().sorted(by: { score($0) > score($1) }) {
            CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
            if let provider = CGDataProvider(url: url as CFURL),
               let cg = CGFont(provider),
               let name = cg.postScriptName as String?,
               UIFont(name: name, size: 12) != nil {
                UserDefaults.standard.set(name, forKey: key)
                return name
            }
        }
        return nil
    }

    /// 파일 앱에서 고른 서체를 앱 안(Documents/Fonts)으로 복사
    static func importFont(from src: URL) throws {
        let fm = FileManager.default
        let dir = Store.docs.appendingPathComponent("Fonts", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        for old in (try? fm.contentsOfDirectory(at: dir, includingPropertiesForKeys: nil)) ?? [] {
            try? fm.removeItem(at: old)
        }
        let scoped = src.startAccessingSecurityScopedResource()
        defer { if scoped { src.stopAccessingSecurityScopedResource() } }
        let dest = dir.appendingPathComponent("goal_font." + src.pathExtension.lowercased())
        try fm.copyItem(at: src, to: dest)
        UserDefaults.standard.removeObject(forKey: key)
    }
}

// MARK: - 목표 / 동기부여 문구 글꼴 (사용자 서체 → Apple Myungjo → 기본 서체 순서, 기울임 없음, 흰색과 베이지를 섞은 색)
enum Myungjo {
    static func make(size: CGFloat) -> UIFont {
        FontLoader.customName().flatMap { UIFont(name: $0, size: size) }
            ?? UIFont(name: "AppleMyungjo", size: size)
            ?? UIFont(name: "Apple Myungjo", size: size)
            ?? UIFont.systemFont(ofSize: size)
    }
}

struct MyungjoText: View {
    let text: String
    let size: CGFloat
    var color: Color? = nil
    var italic = false

    var body: some View {
        Text(text)
            .font(Font(Myungjo.make(size: size) as CTFont))
            .italic(italic)
            .foregroundStyle(color ?? Color(red: 0.98, green: 0.96, blue: 0.92).opacity(0.8))
            .multilineTextAlignment(.center)
    }
}

// MARK: - 디데이
enum DDay {
    static func label(name: String, dateInterval: Double) -> String? {
        guard dateInterval > 0 else { return nil }
        let cal = Calendar.current
        let target = cal.startOfDay(for: Date(timeIntervalSince1970: dateInterval))
        let today = cal.startOfDay(for: Date())
        let diff = cal.dateComponents([.day], from: today, to: target).day ?? 0
        let core = diff == 0 ? "D-Day" : (diff > 0 ? "D-\(diff)" : "D+\(-diff)")
        let n = name.trimmingCharacters(in: .whitespaces)
        return n.isEmpty ? core : "\(n)  \(core)"
    }
}

// MARK: - 스톱워치 (표기 HH:MM:SS:FF, FF는 1/100초)
@MainActor
final class Stopwatch: ObservableObject {
    struct Lap: Identifiable {
        let id = UUID()
        let n: Int
        let split: TimeInterval
        let total: TimeInterval
    }

    @Published var running = false
    @Published var laps: [Lap] = []
    private var accumulated: TimeInterval = 0
    private var startedAt: Date?
    private var lastLapTotal: TimeInterval = 0

    var elapsed: TimeInterval {
        accumulated + (startedAt.map { Date().timeIntervalSince($0) } ?? 0)
    }

    func toggle() {
        if running {
            accumulated = elapsed
            startedAt = nil
            running = false
        } else {
            startedAt = Date()
            running = true
        }
    }

    func lap() {
        let t = elapsed
        guard t > 0 else { return }
        laps.append(Lap(n: laps.count + 1, split: t - lastLapTotal, total: t))
        lastLapTotal = t
    }

    func reset() {
        running = false
        startedAt = nil
        accumulated = 0
        lastLapTotal = 0
        laps = []
    }

    nonisolated static func format(_ t: TimeInterval) -> String {
        let cs = max(0, Int(t * 100))
        return String(format: "%02d:%02d:%02d:%02d", cs / 360000, (cs / 6000) % 60, (cs / 100) % 60, cs % 100)
    }
}

struct StopwatchPanel: View {
    @ObservedObject var sw: Stopwatch

    var body: some View {
        VStack(spacing: 10) {
            TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !sw.running)) { _ in
                Text(Stopwatch.format(sw.elapsed))
                    .font(.system(size: 48, weight: .light, design: .monospaced))   // 기존 40 → 20% 확대
                    .foregroundStyle(.white.opacity(0.8))
            }
            // 버튼은 기존보다 60% 크게
            HStack(spacing: 12) {
                MiniButton(sw.running ? "멈춤" : "시작", scale: 1.6) { sw.toggle() }
                MiniButton("랩", scale: 1.6) { sw.lap() }
                MiniButton("리셋", scale: 1.6) { sw.reset() }
            }
            // 랩은 한 번에 3개가 보이고, 스크롤로 나머지(최신순)를 볼 수 있음
            if !sw.laps.isEmpty {
                ScrollView(.vertical, showsIndicators: true) {
                    VStack(spacing: 4) {
                        ForEach(sw.laps.reversed()) { lap in
                            Text("랩 \(lap.n)   \(Stopwatch.format(lap.split))   (\(Stopwatch.format(lap.total)))")
                                .font(.system(size: 14.4, design: .monospaced))     // 기존 12 → 20% 확대
                                .foregroundStyle(.white.opacity(0.55))
                        }
                    }
                    .frame(maxWidth: .infinity)
                }
                .frame(maxWidth: 560)
                .frame(height: 3 * 20 + 2 * 4)    // 3줄 높이
            }
        }
    }
}

// MARK: - 목표 탭 (목표 문구 + 디데이)
struct GoalView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("goalText") private var saved = ""
    @AppStorage("showGoal") private var show = true
    @AppStorage("ddayShow") private var ddayShow = false
    @AppStorage("ddayName") private var ddayName = ""
    @AppStorage("ddayDate") private var ddayDate = 0.0
    @State private var draft = ""
    @State private var savedNotice = false

    private var ddayBinding: Binding<Date> {
        Binding(
            get: { ddayDate > 0 ? Date(timeIntervalSince1970: ddayDate) : Date() },
            set: { ddayDate = $0.timeIntervalSince1970 }
        )
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("목표") {
                    TextEditor(text: $draft)
                        .frame(minHeight: 110)
                    HStack {
                        Button("저장") {
                            saved = draft.trimmingCharacters(in: .whitespacesAndNewlines)
                            savedNotice = true
                        }
                        if savedNotice { Text("저장했어요 ✓").font(.footnote).foregroundStyle(.secondary) }
                    }
                }
                Section {
                    Toggle("촬영 중 목표 표시", isOn: $show)
                } footer: {
                    Text("끄더라도 저장된 목표 문구는 그대로 유지돼요.")
                }
                Section("미리보기") {
                    ZStack {
                        RoundedRectangle(cornerRadius: 10).fill(Color.black)
                        MyungjoText(text: draft.isEmpty ? "목표를 입력하면 이렇게 보여요" : draft, size: 22)
                            .padding(20)
                    }
                    .frame(minHeight: 100)
                    .opacity(show ? 1 : 0.35)
                }
                Section {
                    Toggle("홈 화면에 디데이 표시", isOn: $ddayShow)
                    TextField("디데이 이름 (예: 시험)", text: $ddayName)
                    DatePicker("날짜", selection: ddayBinding, displayedComponents: .date)
                    if let label = DDay.label(name: ddayName, dateInterval: ddayDate) {
                        Text(label)
                            .font(.system(size: 20, weight: .medium, design: .serif))
                            .italic()
                            .foregroundStyle(Color(red: 0.62, green: 0.38, blue: 0.26))
                    }
                } header: {
                    Text("디데이")
                } footer: {
                    Text("끄더라도 설정한 이름과 날짜는 유지돼요.")
                }
            }
            .navigationTitle("목표")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("닫기") { dismiss() } } }
            .onAppear {
                draft = saved
                if ddayDate == 0 { ddayDate = Calendar.current.startOfDay(for: Date()).timeIntervalSince1970 }
            }
            .onChange(of: draft) { _, _ in savedNotice = false }
        }
    }
}

// MARK: - 개발자 모드 (시작 화면 제목을 2초 안에 7번 탭)
struct DevView: View {
    @ObservedObject var rec: Recorder
    @Environment(\.dismiss) private var dismiss
    @State private var camText = "-"
    @AppStorage("serverURL") private var serverURL = ""
    @AppStorage("layoutInspect") private var layoutInspect = false

    var body: some View {
        NavigationStack {
            Form {
                Section("카메라") {
                    Text("카메라 세션: \(camText)")
                    Button("카메라 강제 정지") {
                        Task { await rec.camera.stopPreview(); refresh() }
                    }
                }
                Section("서체") {
                    Text("적용된 사용자 서체: \(FontLoader.customName() ?? "없음")")
                    Text("Apple Myungjo: \(UIFont(name: "AppleMyungjo", size: 12) != nil ? "있음" : "없음")")
                    Text("명조 계열 서체: \(myungjoFamilies.isEmpty ? "없음" : myungjoFamilies.joined(separator: ", "))")
                        .font(.caption)
                }
                Section("번들 파일") {
                    Text("서버 주소: \(ServerAPI.baseURL?.absoluteString ?? "설정 안 됨")")
                    Text("ui_config.txt: \(UIConfig.shared.isLoaded ? "불러옴 (섹션 \(UIConfig.shared.sectionCount)개)" : "없음 (기본값 사용)")")
                    Text("워터마크: \(ImageLocator.load(key: "Watermark_Location", fallbackName: "Video_watermark") != nil ? "있음" : "없음")")
                    Text("AwayImage: \(ImageLocator.load(key: "AwayImage_Location", fallbackName: "AwayImage") != nil ? "있음" : "없음")")
                    Text("motiv_text: \(Bundle.main.url(forResource: "motiv_text", withExtension: "txt") != nil ? "있음" : "없음") · 문구 \(MotivQuotes.load().count)개")
                    Text("서체 파일: \(fontFiles.isEmpty ? "없음" : fontFiles.joined(separator: ", "))")
                        .font(.caption)
                    Text("번들 안 파일: \(bundleFiles)").font(.caption)
                }
                Section {
                    TextField("서버 주소 (https://…)", text: $serverURL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    Toggle("레이아웃 표시 (위치·크기·중심 좌표)", isOn: $layoutInspect)
                } header: {
                    Text("서버 / 레이아웃")
                } footer: {
                    Text("레이아웃 표시를 켜면 홈과 촬영 화면의 각 요소에 테두리와 이름, 크기, 화면 대비 중심 좌표(ui_config.txt의 coordinate 값)가 겹쳐 보여요. ui_config.txt에 서버 주소가 있으면 그 값이 우선돼요.")
                }
                Section("프레임 / 로그") {
                    Text("프레임 \(rec.count)장 (AwayImage 대체 \(rec.missed)장)")
                    Button("AwayImage 프레임 1장 추가") { Task { await rec.devAddPlaceholder() } }
                    Button("프레임 전부 삭제", role: .destructive) { rec.devClearFrames() }
                    Button("통계 로그 삭제", role: .destructive) {
                        try? FileManager.default.removeItem(at: StatsLog.file)
                    }
                }
                Section("상태") {
                    Text("phase: \(String(describing: rec.phase))")
                    Text("간격 \(Int(Prefs.interval))초 · \(Prefs.fps)fps")
                }
            }
            .navigationTitle("개발자 모드")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("닫기") { dismiss() } } }
            .onAppear { refresh() }
        }
    }

    private var fontFiles: [String] { FontLoader.fontFileURLs().map { $0.lastPathComponent } }

    private var bundleFiles: String {
        let names = (try? FileManager.default.contentsOfDirectory(atPath: Bundle.main.bundlePath)) ?? []
        return names.sorted().prefix(25).joined(separator: ", ")
    }

    private var myungjoFamilies: [String] {
        UIFont.familyNames.filter {
            let l = $0.lowercased()
            return l.contains("myung") || l.contains("myeong") || l.contains("nanum") || $0.contains("명조")
        }
    }

    private func refresh() {
        camText = rec.camera.session.isRunning ? "켜짐" : "꺼짐"
    }
}

struct AnalogClock: View {
    var body: some View {
        TimelineView(.everyMinute) { ctx in
            let cal = Calendar.current
            let h = Double(cal.component(.hour, from: ctx.date) % 12)
            let m = Double(cal.component(.minute, from: ctx.date))
            GeometryReader { g in
                let s = min(g.size.width, g.size.height)
                let r = s / 2
                ZStack {
                    Circle().stroke(Color.white.opacity(0.8), lineWidth: s * 0.01)
                    ForEach(1...12, id: \.self) { n in
                        Text("\(n)")
                            .font(.system(size: s * 0.09, weight: .medium, design: .serif))
                            .foregroundStyle(.white.opacity(0.85))
                            .position(x: r + CGFloat(sin(Double(n) * .pi / 6)) * r * 0.82,
                                      y: r - CGFloat(cos(Double(n) * .pi / 6)) * r * 0.82)
                    }
                    hand(length: r * 0.5, width: s * 0.025, angle: (h + m / 60) * 30)   // 시침
                    hand(length: r * 0.75, width: s * 0.015, angle: m * 6)               // 분침 (초침 없음)
                    Circle().fill(Color.white).frame(width: s * 0.04, height: s * 0.04)
                }
                .frame(width: s, height: s)
            }
        }
    }

    private func hand(length: CGFloat, width: CGFloat, angle: Double) -> some View {
        Capsule()
            .fill(Color.white.opacity(0.9))
            .frame(width: width, height: length)
            .offset(y: -length / 2)
            .rotationEffect(.degrees(angle))
    }
}

struct DigitalClock: View {
    var body: some View {
        TimelineView(.everyMinute) { ctx in
            VStack(spacing: 12) {
                Text(Self.format(ctx.date, "yy년 MM월 dd일 (E)"))
                    .font(.system(size: 34, weight: .medium))
                Text(Self.format(ctx.date, "HH : mm"))
                    .font(.system(size: 80, weight: .semibold, design: .rounded))
                    .monospacedDigit()
            }
            .foregroundStyle(.white.opacity(0.9))
        }
    }

    private static func format(_ date: Date, _ pattern: String) -> String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "ko_KR")
        f.dateFormat = pattern
        return f.string(from: date)
    }
}

// MARK: - 플립 시계 (어두운 회색 카드 + 흰 숫자, 시간이 바뀔 때 넘어가는 효과)
struct FlipHalf: View {
    let digit: Int
    let top: Bool
    let size: CGSize

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size.width * 0.12).fill(Color(white: 0.2))
            Text("\(digit)")
                .font(.system(size: size.height * 0.72, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
        }
        .frame(width: size.width, height: size.height)
        .frame(width: size.width, height: size.height / 2, alignment: top ? .top : .bottom)
        .clipped()
    }
}

struct FlipCard: View {
    let digit: Int
    let size: CGSize
    @State private var shown: Int
    @State private var incoming: Int
    @State private var topAngle = 0.0
    @State private var bottomAngle = 90.0

    init(digit: Int, size: CGSize) {
        self.digit = digit
        self.size = size
        _shown = State(initialValue: digit)
        _incoming = State(initialValue: digit)
    }

    var body: some View {
        ZStack {
            // 뒤: 새 숫자의 윗면 + 옛 숫자의 아랫면
            VStack(spacing: 0) {
                FlipHalf(digit: incoming, top: true, size: size)
                FlipHalf(digit: shown, top: false, size: size)
            }
            // 앞: 옛 숫자의 윗면이 아래로 넘어감
            VStack(spacing: 0) {
                FlipHalf(digit: shown, top: true, size: size)
                    .rotation3DEffect(.degrees(topAngle), axis: (x: 1, y: 0, z: 0), anchor: .bottom, perspective: 0.5)
                    .opacity(topAngle > -89 ? 1 : 0)
                Color.clear.frame(width: size.width, height: size.height / 2)
            }
            // 앞: 새 숫자의 아랫면이 위에서 내려옴
            VStack(spacing: 0) {
                Color.clear.frame(width: size.width, height: size.height / 2)
                FlipHalf(digit: incoming, top: false, size: size)
                    .rotation3DEffect(.degrees(bottomAngle), axis: (x: 1, y: 0, z: 0), anchor: .top, perspective: 0.5)
                    .opacity(bottomAngle < 89 ? 1 : 0)
            }
            Rectangle().fill(Color.black.opacity(0.7)).frame(height: 2)
        }
        .frame(width: size.width, height: size.height)
        .onChange(of: digit) { _, new in flip(to: new) }
    }

    private func flip(to new: Int) {
        incoming = new
        withAnimation(.easeIn(duration: 0.25)) { topAngle = -90 }
        Task {
            try? await Task.sleep(for: .seconds(0.25))
            withAnimation(.easeOut(duration: 0.25)) { bottomAngle = 0 }
            try? await Task.sleep(for: .seconds(0.25))
            var t = Transaction()
            t.disablesAnimations = true
            withTransaction(t) {
                shown = new
                topAngle = 0
                bottomAngle = 90
            }
        }
    }
}

struct FlipClock: View {
    let cardWidth: CGFloat

    var body: some View {
        let size = CGSize(width: cardWidth, height: cardWidth * 1.4)
        TimelineView(.everyMinute) { ctx in
            let cal = Calendar.current
            let h = cal.component(.hour, from: ctx.date)
            let m = cal.component(.minute, from: ctx.date)
            HStack(spacing: cardWidth * 0.18) {
                HStack(spacing: cardWidth * 0.06) {
                    FlipCard(digit: h / 10, size: size)
                    FlipCard(digit: h % 10, size: size)
                }
                VStack(spacing: size.height * 0.2) {
                    Circle().fill(Color(white: 0.35)).frame(width: cardWidth * 0.1, height: cardWidth * 0.1)
                    Circle().fill(Color(white: 0.35)).frame(width: cardWidth * 0.1, height: cardWidth * 0.1)
                }
                HStack(spacing: cardWidth * 0.06) {
                    FlipCard(digit: m / 10, size: size)
                    FlipCard(digit: m % 10, size: size)
                }
            }
        }
    }
}

// MARK: - 창 모드 안내: 문구 크기에 맞는 사각형 + 점멸
struct ExpandHint: View {
    @State private var on = false

    var body: some View {
        let e = UIConfig.shared.elem("ExpandHint_set")
        let c = e.color ?? Color.red
        Text(e.text ?? "Can you expand it for our records")
            .font(.system(size: e.size ?? 10.5))
            .foregroundStyle(c)
            .padding(.horizontal, 9)
            .padding(.vertical, 6)
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(c, lineWidth: 1))
            .opacity(on ? 1 : 0.25)
            .animation(.easeInOut(duration: 0.7).repeatForever(autoreverses: true), value: on)
            .onAppear { on = true }
    }
}

// MARK: - 인코딩 중 화면 (문구 + 가로 진행도 바)
struct EncodingView: View {
    let text: String
    let progress: Double

    var body: some View {
        let e = UIConfig.shared.elem("Encoding_set")
        return VStack(spacing: 22) {
            Text(e.text ?? text)
                .font(.system(size: e.size ?? 26, weight: .regular, design: .serif))
                .italic(e.italic ?? false)
                .foregroundStyle(e.color ?? Color.white.opacity(0.9))
                .multilineTextAlignment(.center)
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.15))
                    Capsule().fill(Color.white.opacity(0.85))
                        .frame(width: g.size.width * min(max(progress, 0), 1))
                }
            }
            .frame(maxWidth: 420)
            .frame(height: 8)
            Text("\(Int(min(max(progress, 0), 1) * 100))%")
                .font(.system(size: 13, design: .monospaced))
                .foregroundStyle(.white.opacity(0.5))
        }
        .padding(40)
    }
}

// MARK: - 영상 저장(사진 앱) / 공유 버튼
struct VideoActions: View {
    @ObservedObject var rec: Recorder

    var body: some View {
        HStack(spacing: 18) {
            Button { rec.saveToPhotos() } label: { Label("영상 저장", systemImage: "square.and.arrow.down") }
            if let u = rec.shareURL {
                ShareLink(item: u) { Label("공유", systemImage: "square.and.arrow.up") }
            }
        }
    }
}

struct ReviewView: View {
    @ObservedObject var rec: Recorder
    @State private var player = AVPlayer(url: Store.videoURL)
    @State private var showStyle = false

    var body: some View {
        VStack(spacing: 14) {
            VideoPlayer(player: player)
                .aspectRatio(16.0 / 9.0, contentMode: .fit)
                .onAppear { player.play() }
            Text("최종 영상을 확인하고, 먼저 저장하세요")
                .font(.footnote).foregroundStyle(.gray)
            HStack(spacing: 22) {
                Button { showStyle = true } label: { Label("커스터마이징", systemImage: "paintbrush") }
                VideoActions(rec: rec)
                Button("검토 완료") { rec.reviewDone() }.buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .sheet(isPresented: $showStyle) { RecordStyleView(rec: rec, canReencode: true) }
    }
}

// MARK: - 영상 꾸미기 (최종 영상 왼쪽 패널 + 타임스탬프)
private let fontChoices = ["System", "Helvetica Neue", "Avenir Next", "Georgia", "Times New Roman",
                           "Courier New", "Menlo", "Futura", "Optima", "Palatino",
                           "Arial Rounded MT Bold", "Marker Felt", "Noteworthy", "Chalkduster"]

struct RecordStyleView: View {
    @ObservedObject var rec: Recorder
    let canReencode: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var style = RecordStyle.load()
    @State private var stamp = StampStyle.load()

    var body: some View {
        NavigationStack {
            Form {
                Section("왼쪽 패널 미리보기") {
                    if let img = PanelRenderer.preview(style: style) {
                        Image(uiImage: img)
                            .resizable().scaledToFit()
                            .frame(maxHeight: 280)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                            .frame(maxWidth: .infinity)
                    }
                }
                Section("형식") {
                    Picker("형식", selection: $style.panelMode) {
                        Text("문구").tag("text")
                        Text("타임테이블").tag("grid")
                    }
                    .pickerStyle(.segmented)
                    ColorPicker("배경 색", selection: colorBinding($style.bgHex), supportsOpacity: false)
                }
                if style.panelMode == "text" { textSection } else { gridSection }
                if !canReencode { stampSection }      // 타임스탬프는 촬영 전에 홈의 '꾸미기'에서만 설정
            }
            .navigationTitle("영상 꾸미기")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("닫기") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    if canReencode {
                        Button("적용 · 다시 인코딩") {
                            style.save()
                            dismiss()
                            rec.reencodeWithStyle()
                        }
                    } else {
                        Button("완료") { dismiss() }
                    }
                }
            }
            .onChange(of: style) { _, s in s.save() }
            .onChange(of: stamp) { _, s in s.save() }
        }
    }

    private var textSection: some View {
        Section("문구") {
            TextField("문구", text: $style.text)
            Button("기본 문구로 되돌리기") { style.text = RecordStyle.defaultText }
            Picker("글꼴", selection: $style.fontName) {
                ForEach(fontChoices, id: \.self) { name in
                    Text(name).font(name == "System" ? .body : .custom(name, size: 17)).tag(name)
                }
            }
            ColorPicker("글자 색", selection: colorBinding($style.textHex), supportsOpacity: false)
            Toggle("기울임", isOn: $style.italic)
            VStack(alignment: .leading) {
                Text("글씨 크기 ×\(style.textScale ?? 1, specifier: "%.2f")")
                Slider(value: Binding(get: { style.textScale ?? 1 }, set: { style.textScale = $0 }),
                       in: 0.4...2.0, step: 0.05)
            }
            Picker("정렬", selection: $style.align) {
                Text("왼쪽").tag("left")
                Text("가운데").tag("center")
                Text("오른쪽").tag("right")
            }
            .pickerStyle(.segmented)
        }
    }

    private var gridSection: some View {
        Section {
            ColorPicker("채움 색", selection: colorBinding($style.gridFillHex), supportsOpacity: false)
            Picker("채우는 방식", selection: $style.gridSmooth) {
                Text("10분 칸 하나씩").tag(false)
                Text("칸 안에서 서서히").tag(true)
            }
            .pickerStyle(.segmented)
        } header: {
            Text("타임테이블")
        } footer: {
            Text("한 칸은 10분, 한 줄은 1시간이에요. 촬영 시작 시각부터 종료 시각까지만 영상이 재생되는 동안 채워져요.")
        }
    }

    private var stampSection: some View {
        Section {
            Image(uiImage: StampRenderer.preview(stamp))
                .resizable().scaledToFit()
                .clipShape(RoundedRectangle(cornerRadius: 8))
            ColorPicker("글자 색", selection: colorBinding($stamp.textHex), supportsOpacity: false)
            Picker("글꼴", selection: $stamp.fontName) {
                ForEach(fontChoices, id: \.self) { name in
                    Text(name).font(name == "System" ? .body : .custom(name, size: 17)).tag(name)
                }
            }
            Toggle("이탤릭", isOn: $stamp.italic)
            VStack(alignment: .leading) {
                Text("크기 \(stamp.sizePercent, specifier: "%.1f")%")
                Slider(value: $stamp.sizePercent, in: 1.5...6)
            }
            Toggle("글자 테두리", isOn: $stamp.strokeOn)
            if stamp.strokeOn {
                ColorPicker("테두리 색", selection: colorBinding($stamp.strokeHex), supportsOpacity: false)
                VStack(alignment: .leading) {
                    Text("테두리 두께 \(stamp.strokeWidth, specifier: "%.1f")")
                    Slider(value: $stamp.strokeWidth, in: 0.5...8)
                }
            }
        } header: {
            Text("타임스탬프")
        } footer: {
            Text("타임스탬프는 촬영할 때 사진에 바로 새겨져요. 바꾼 디자인은 다음 촬영부터 적용돼요.")
        }
    }

    private func colorBinding(_ hex: Binding<String>) -> Binding<Color> {
        Binding(
            get: { Color(UIColor(hex: hex.wrappedValue)) },
            set: { hex.wrappedValue = UIColor($0).hexString }
        )
    }
}

// MARK: - 계정 / 서버 저장 (사용자 세팅값 + 촬영 기록 로그만 저장. 사진·영상은 저장하지 않음)
enum Keychain {
    private static let service = "Y16HII.account"

    private static func base(_ key: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: key]
    }

    static func set(_ value: String, key: String) {
        SecItemDelete(base(key) as CFDictionary)
        var add = base(key)
        add[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(add as CFDictionary, nil)
    }

    static func get(_ key: String) -> String? {
        var q = base(key)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess,
              let d = out as? Data else { return nil }
        return String(data: d, encoding: .utf8)
    }

    static func remove(_ key: String) {
        SecItemDelete(base(key) as CFDictionary)
    }
}

struct APIFailure: LocalizedError {
    let status: Int
    let message: String
    var errorDescription: String? { message }
}

enum ServerAPI {
    /// ui_config.txt 의 [Server_set] url (https 주소만 허용)
    static var baseURL: URL? {
        let configured = UIConfig.shared.value("Server_set", "url") ?? ""
        let s = (configured.isEmpty ? (UserDefaults.standard.string(forKey: "serverURL") ?? "") : configured)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard s.lowercased().hasPrefix("https://") else { return nil }
        return URL(string: s.hasSuffix("/") ? String(s.dropLast()) : s)
    }

    static func call(_ method: String, _ path: String, token: String?, body: Data?) async throws -> Data {
        guard let base = baseURL, let url = URL(string: base.absoluteString + path) else {
            throw APIFailure(status: 0, message: "서버 주소가 설정되지 않았어요 (ui_config.txt의 [Server_set] url)")
        }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.timeoutInterval = 30
        if let token { req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        if let body {
            req.httpBody = body
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        let (data, resp) = try await URLSession.shared.data(for: req)
        let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
        guard (200..<300).contains(status) else {
            let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw APIFailure(status: status, message: obj?["error"] as? String ?? "요청에 실패했어요 (\(status))")
        }
        return data
    }

    static func object(_ data: Data) -> [String: Any] {
        (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
    }
}

// MARK: 서버에 저장하는 사용자 세팅값 (user_set_data)
struct UserSetData: Codable {
    struct DDayInfo: Codable { var show: Bool; var name: String; var date: Double }
    struct Goal: Codable { var text: String; var show: Bool }
    struct Suneung: Codable { var secondStyle: String; var items: [SuneungItem] }
    struct AppSettings: Codable {
        var fps: Double
        var interval: Double
        var dimWhileRunning: Bool
        var dimLevel: Double
        var showMotiv: Bool
    }

    var version = 1
    var dday: DDayInfo
    var goal: Goal
    var suneung: Suneung
    var recordStyle: RecordStyle      // 영상 꾸미기(저장 시점 값)
    var stampStyle: StampStyle        // 타임스탬프 디자인
    var settings: AppSettings         // fps, 촬영 간격, 밝기, 문구 표시 등

    static func collect() -> UserSetData {
        let d = UserDefaults.standard
        return UserSetData(
            dday: DDayInfo(show: d.bool(forKey: "ddayShow"),
                       name: d.string(forKey: "ddayName") ?? "",
                       date: d.double(forKey: "ddayDate")),
            goal: Goal(text: d.string(forKey: "goalText") ?? "",
                       show: d.object(forKey: "showGoal") as? Bool ?? true),
            suneung: Suneung(secondStyle: d.string(forKey: "suneungSecondStyle") ?? "smooth",
                             items: SuneungStore.load()),
            recordStyle: RecordStyle.load(),
            stampStyle: StampStyle.load(),
            settings: AppSettings(fps: d.object(forKey: "videoFps") as? Double ?? 24,
                                  interval: d.object(forKey: "captureInterval") as? Double ?? 120,
                                  dimWhileRunning: d.object(forKey: "dimWhileRunning") as? Bool ?? true,
                                  dimLevel: d.object(forKey: "dimLevel") as? Double ?? 0.1,
                                  showMotiv: d.object(forKey: "showMotiv") as? Bool ?? true))
    }

    func apply() {
        let d = UserDefaults.standard
        d.set(dday.show, forKey: "ddayShow")
        d.set(dday.name, forKey: "ddayName")
        d.set(dday.date, forKey: "ddayDate")
        d.set(goal.text, forKey: "goalText")
        d.set(goal.show, forKey: "showGoal")
        d.set(suneung.secondStyle, forKey: "suneungSecondStyle")
        SuneungStore.save(suneung.items)
        recordStyle.save()
        stampStyle.save()
        d.set(settings.fps, forKey: "videoFps")
        d.set(settings.interval, forKey: "captureInterval")
        d.set(settings.dimWhileRunning, forKey: "dimWhileRunning")
        d.set(settings.dimLevel, forKey: "dimLevel")
        d.set(settings.showMotiv, forKey: "showMotiv")
    }
}

@MainActor
final class AccountModel: ObservableObject {
    @Published var userId: String? = UserDefaults.standard.string(forKey: "acctId")
    @Published var email = ""
    @Published var emailVerified = false
    @Published var busy = false
    @Published var message = ""
    @Published var isError = false
    @Published var name = UserDefaults.standard.string(forKey: "profileName") ?? ""
    @Published var icon = UserDefaults.standard.string(forKey: "profileIcon") ?? "😀"
    @Published var imageVersion = 0          // 사진 아이콘이 바뀌면 화면을 다시 그리기 위한 값

    var loggedIn: Bool { userId != nil && Keychain.get("token") != nil }
    var hasServer: Bool { ServerAPI.baseURL != nil }

    /// 프로필 버튼에 보이는 이름: 이름이 있으면 이름, 없으면 아이디
    var displayName: String {
        let n = name.trimmingCharacters(in: .whitespaces)
        if !n.isEmpty { return n }
        if loggedIn, let id = userId { return id }
        return "게스트"
    }

    /// 개발자 모드 버튼: whitelist.txt 에 등록된 아이디로 로그인했을 때만
    var isDeveloper: Bool { loggedIn && Whitelist.contains(userId) }
    private var token: String? { Keychain.get("token") }

    private func say(_ m: String, error: Bool = false) {
        message = m
        isError = error
    }

    private func run(_ work: () async throws -> Void) async {
        busy = true
        message = ""
        defer { busy = false }
        do {
            try await work()
        } catch let e as APIFailure {
            if e.status == 401 && loggedIn {
                clearSession()
                say("로그인이 만료됐어요. 다시 로그인해주세요.", error: true)
            } else {
                say(e.message, error: true)
            }
        } catch {
            say("네트워크 오류: \(error.localizedDescription)", error: true)
        }
    }

    private func clearSession() {
        Keychain.remove("token")
        UserDefaults.standard.removeObject(forKey: "acctId")
        UserDefaults.standard.removeObject(forKey: "logUploadedThrough")
        userId = nil
        email = ""
        emailVerified = false
        name = ""
        UserDefaults.standard.removeObject(forKey: "profileName")
    }

    private func finishLogin(_ data: Data, id: String) throws {
        let obj = ServerAPI.object(data)
        guard let t = obj["token"] as? String else { throw APIFailure(status: 0, message: "서버 응답이 올바르지 않아요") }
        Keychain.set(t, key: "token")
        UserDefaults.standard.set(id, forKey: "acctId")
        userId = id
        email = obj["email"] as? String ?? ""
        emailVerified = obj["emailVerified"] as? Bool ?? false
        applyServerProfile(obj)
    }

    private func body(_ dict: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: dict)
    }

    // MARK: 가입 / 로그인
    func register(id: String, password: String, email: String, name: String = "") async {
        await run {
            let cleanId = id.trimmingCharacters(in: .whitespaces)
            guard password.count >= 4 else {
                throw APIFailure(status: 0, message: "비밀번호는 4자리 이상이어야 해요")
            }
            var b: [String: Any] = ["id": cleanId, "password": password]
            let mail = email.trimmingCharacters(in: .whitespaces)
            if !mail.isEmpty { b["email"] = mail }
            let nm = name.trimmingCharacters(in: .whitespaces)
            if !nm.isEmpty { b["name"] = nm }
            b["icon"] = self.icon
            let data = try await ServerAPI.call("POST", "/register", token: nil, body: try self.body(b))
            try self.finishLogin(data, id: cleanId)
            self.say(mail.isEmpty
                     ? "가입했어요. 이메일을 등록·인증하지 않으면 비밀번호를 잊었을 때 찾을 수 없어요."
                     : "가입했어요. 아래에서 이메일 인증 코드를 받아 인증을 마쳐주세요.")
        }
    }

    func login(id: String, password: String) async {
        await run {
            let cleanId = id.trimmingCharacters(in: .whitespaces)
            let data = try await ServerAPI.call("POST", "/login", token: nil,
                                                body: try self.body(["id": cleanId, "password": password]))
            try self.finishLogin(data, id: cleanId)
            self.say("로그인했어요.")
        }
    }

    func logout() {
        clearSession()
        say("로그아웃했어요.")
    }

    func refreshMe() async {
        guard let t = token else { return }
        if let data = try? await ServerAPI.call("GET", "/me", token: t, body: nil) {
            let obj = ServerAPI.object(data)
            email = obj["email"] as? String ?? ""
            emailVerified = obj["emailVerified"] as? Bool ?? false
            applyServerProfile(obj)
        }
    }

    private func applyServerProfile(_ obj: [String: Any]) {
        if let n = obj["name"] as? String, !n.isEmpty {
            name = n
            UserDefaults.standard.set(n, forKey: "profileName")
        }
        if let i = obj["icon"] as? String, !i.isEmpty {
            icon = i
            UserDefaults.standard.set(i, forKey: "profileIcon")
        }
    }

    /// 이름/이모지 아이콘 저장 (로그인 중이면 서버에도)
    func setProfile(name newName: String? = nil, icon newIcon: String? = nil) async {
        if let n = newName {
            name = n
            UserDefaults.standard.set(n, forKey: "profileName")
        }
        if let i = newIcon {
            icon = i
            UserDefaults.standard.set(i, forKey: "profileIcon")
        }
        guard loggedIn else { return }
        _ = try? await ServerAPI.call("PUT", "/profile", token: token, body: try? body(["name": name, "icon": icon]))
    }

    // MARK: 이메일 인증 / 비밀번호 재설정
    func requestEmailCode(_ mail: String) async {
        await run {
            _ = try await ServerAPI.call("POST", "/email/request", token: self.token,
                                         body: try self.body(["email": mail.trimmingCharacters(in: .whitespaces)]))
            self.say("인증 코드를 보냈어요. 10분 안에 입력해주세요.")
        }
    }

    func confirmEmail(_ code: String) async {
        await run {
            _ = try await ServerAPI.call("POST", "/email/confirm", token: self.token,
                                         body: try self.body(["code": code]))
            await self.refreshMe()
            self.say("이메일 인증이 끝났어요.")
        }
    }

    func requestReset(id: String) async {
        await run {
            _ = try await ServerAPI.call("POST", "/password/reset/request", token: nil,
                                         body: try self.body(["id": id.trimmingCharacters(in: .whitespaces)]))
            self.say("이메일 인증을 마친 계정이라면 재설정 코드를 보냈어요.")
        }
    }

    func confirmReset(id: String, code: String, newPassword: String) async {
        await run {
            guard newPassword.count >= 4 else {
                throw APIFailure(status: 0, message: "비밀번호는 4자리 이상이어야 해요")
            }
            _ = try await ServerAPI.call("POST", "/password/reset/confirm", token: nil,
                                         body: try self.body(["id": id.trimmingCharacters(in: .whitespaces),
                                                              "code": code, "newPassword": newPassword]))
            self.say("비밀번호를 바꿨어요. 새 비밀번호로 로그인해주세요.")
        }
    }

    func deleteAccount() async {
        await run {
            _ = try await ServerAPI.call("DELETE", "/account", token: self.token, body: nil)
            self.clearSession()
            self.say("계정과 서버에 저장된 데이터를 삭제했어요. 이 기기의 데이터는 그대로예요.")
        }
    }

    // MARK: 저장 / 불러오기
    /// 로그(JSONL)를 날짜(UTC)별로 묶음
    private static func groupedLog() -> [(day: String, text: String)] {
        guard let text = try? String(contentsOf: StatsLog.file, encoding: .utf8) else { return [] }
        var days: [String: [Substring]] = [:]
        for line in text.split(separator: "\n") {
            guard line.hasPrefix("{\"time\":\""), line.count > 20 else { continue }
            days[String(line.dropFirst(9).prefix(10)), default: []].append(line)
        }
        return days.keys.sorted().map { ($0, days[$0]!.joined(separator: "\n") + "\n") }
    }

    private func sendLogs(_ batch: [String: String]) async throws {
        _ = try await ServerAPI.call("PUT", "/logs", token: token, body: try body(["days": batch]))
    }

    func upload() async {
        await run {
            // 1) 설정값
            let setData = try JSONEncoder().encode(UserSetData.collect())
            let obj = try JSONSerialization.jsonObject(with: setData)
            _ = try await ServerAPI.call("PUT", "/settings", token: self.token, body: try self.body(["data": obj]))

            // 2) 촬영 기록 로그 (마지막으로 올린 날부터 다시 올림)
            let all = Self.groupedLog()
            let since = UserDefaults.standard.string(forKey: "logUploadedThrough") ?? ""
            var batch: [String: String] = [:]
            var bytes = 0
            var days = 0
            for (day, text) in all where day >= since {
                batch[day] = text
                bytes += text.utf8.count
                days += 1
                if bytes >= 400_000 {
                    try await self.sendLogs(batch)
                    batch = [:]
                    bytes = 0
                }
            }
            if !batch.isEmpty { try await self.sendLogs(batch) }
            if let last = all.last?.day { UserDefaults.standard.set(last, forKey: "logUploadedThrough") }
            self.say("서버에 저장했어요. (설정값 + 기록 \(days)일치)")
        }
    }

    func download() async {
        await run {
            // 1) 설정값
            let sdata = try await ServerAPI.call("GET", "/settings", token: self.token, body: nil)
            var applied = false
            if let dataObj = ServerAPI.object(sdata)["data"], !(dataObj is NSNull) {
                let raw = try JSONSerialization.data(withJSONObject: dataObj)
                let set = try JSONDecoder().decode(UserSetData.self, from: raw)
                set.apply()
                applied = true
            }

            // 2) 촬영 기록 로그 (페이지 단위로 받아 합침)
            var texts: [String: String] = [:]
            var next: String?
            repeat {
                var path = "/logs"
                if let n = next, let enc = n.addingPercentEncoding(withAllowedCharacters: .alphanumerics) {
                    path += "?next=" + enc
                }
                let r = ServerAPI.object(try await ServerAPI.call("GET", path, token: self.token, body: nil))
                for it in (r["items"] as? [[String: Any]] ?? []) {
                    if let day = it["date"] as? String, let t = it["text"] as? String { texts[day, default: ""] += t }
                }
                next = r["next"] as? String
            } while next != nil

            if !texts.isEmpty {
                let merged = texts.keys.sorted().map { texts[$0] ?? "" }.joined()
                try FileManager.default.createDirectory(at: StatsLog.dir, withIntermediateDirectories: true)
                try merged.write(to: StatsLog.file, atomically: true, encoding: .utf8)
                UserDefaults.standard.set(texts.keys.max(), forKey: "logUploadedThrough")
            }
            self.say(applied || !texts.isEmpty
                     ? "서버에서 불러왔어요. (설정값\(applied ? " ✓" : " 없음") · 기록 \(texts.count)일치)"
                     : "서버에 저장된 내용이 아직 없어요.")
        }
    }
}

// MARK: - 설정 > 계정 탭
struct AccountView: View {
    @ObservedObject var acct: AccountModel
    @State private var mode = 0                // 0 로그인, 1 가입
    @State private var id = ""
    @State private var password = ""
    @State private var email = ""
    @State private var name = ""
    @State private var askUpload = false
    @State private var showReset = false
    @State private var resetId = ""
    @State private var resetCode = ""
    @State private var resetPw = ""
    @State private var resetSent = false
    @State private var mailInput = ""
    @State private var codeInput = ""
    @State private var askDownload = false
    @State private var askDelete = false

    private let notice = "로그인하면 설정값을 서버에 저장해 두었다가 나중에 불러올 수 있어요. 서버에는 사용자 세팅값(디데이, 목표, 수능시계, 영상 꾸미기·타임스탬프, 설정값)과 촬영 기록(촬영 시각 로그)만 저장되고, 사진과 영상은 저장되지 않아요. 장래에 값을 저장/불러오기 위한 용도로만 쓰여요. 로그인하지 않아도 앱의 모든 기능을 쓸 수 있어요."

    var body: some View {
        Form {
            Section {
                Text(notice).font(.footnote).foregroundStyle(.secondary)
            } header: {
                Text("서버 저장 (선택)")
            }
            if !acct.hasServer {
                Section {
                    Text("서버 주소가 설정되지 않았어요. 개발자 모드에서 입력하거나 ui_config.txt의 [Server_set] url에 넣어주세요.")
                        .font(.footnote).foregroundStyle(.orange)
                }
            }
            if acct.loggedIn { loggedInSections } else { loggedOutSections }
            if !acct.message.isEmpty {
                Section {
                    Text(acct.message).font(.footnote)
                        .foregroundStyle(acct.isError ? Color.red : Color.green)
                }
            }
        }
        .disabled(acct.busy)
        .overlay { if acct.busy { ProgressView() } }
        .onAppear { if acct.loggedIn { Task { await acct.refreshMe() } } }
        .alert("서버에 저장할까요?", isPresented: $askUpload) {
            Button("저장") { Task { await acct.upload() } }
            Button("취소", role: .cancel) {}
        } message: {
            Text("서버에 저장된 설정과 기록이 이 기기의 값으로 바뀌어요.")
        }
        .alert("서버에서 불러올까요?", isPresented: $askDownload) {
            Button("불러오기", role: .destructive) { Task { await acct.download() } }
            Button("취소", role: .cancel) {}
        } message: {
            Text("이 기기의 설정과 통계 기록이 서버에 저장된 내용으로 바뀌어요.")
        }
        .alert("계정을 삭제할까요?", isPresented: $askDelete) {
            Button("삭제", role: .destructive) { Task { await acct.deleteAccount() } }
            Button("취소", role: .cancel) {}
        } message: {
            Text("서버에 저장된 계정, 설정값, 촬영 기록이 모두 삭제되고 되돌릴 수 없어요. 이 기기의 데이터는 그대로 남아요.")
        }
    }

    private var loggedOutSections: some View {
        Group {
            Section {
                Picker("", selection: $mode) {
                    Text("로그인").tag(0)
                    Text("가입").tag(1)
                }
                .pickerStyle(.segmented)
                TextField("아이디", text: $id)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                SecureField("비밀번호 (4자리 이상)", text: $password)
                if mode == 1 {
                    TextField("이름 (선택)", text: $name)
                    TextField("이메일 (선택)", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Button(mode == 0 ? "로그인" : "가입하기") {
                    Task {
                        if mode == 0 {
                            await acct.login(id: id, password: password)
                        } else {
                            await acct.register(id: id, password: password, email: email, name: name)
                        }
                        if acct.loggedIn { password = "" }
                    }
                }
                .disabled(id.trimmingCharacters(in: .whitespaces).isEmpty || password.isEmpty)
            } footer: {
                if mode == 1 {
                    Text("아이디는 다른 사람과 겹칠 수 없어요. 이메일은 선택 사항이에요. 이메일을 등록·인증하지 않으면 비밀번호를 잊어도 찾을 수 없어요. 이 경우 새 계정을 만들어야 하고, 저장된 설정은 복구되지 않아요. 이메일은 비밀번호 재설정 용도로만 사용돼요.")
                } else {
                    Text("이메일을 인증하지 않은 계정은 비밀번호를 잊으면 찾을 수 없어요.")
                }
            }
            if mode == 0 {
                Section {
                    DisclosureGroup("비밀번호 찾기", isExpanded: $showReset) {
                        TextField("아이디", text: $resetId)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                        if !resetSent {
                            Button("재설정 코드 보내기") {
                                Task {
                                    await acct.requestReset(id: resetId)
                                    if !acct.isError { resetSent = true }
                                }
                            }
                            .disabled(resetId.isEmpty)
                            Text("이메일 인증을 마친 계정만 코드를 받을 수 있어요.")
                                .font(.footnote).foregroundStyle(.secondary)
                        } else {
                            TextField("코드 6자리", text: $resetCode).keyboardType(.numberPad)
                            SecureField("새 비밀번호 (4자리 이상)", text: $resetPw)
                            Button("비밀번호 바꾸기") {
                                Task {
                                    await acct.confirmReset(id: resetId, code: resetCode, newPassword: resetPw)
                                    if !acct.isError {
                                        resetSent = false; resetCode = ""; resetPw = ""; showReset = false
                                    }
                                }
                            }
                            .disabled(resetCode.isEmpty || resetPw.isEmpty)
                        }
                    }
                }
            }
        }
    }

    private var loggedInSections: some View {
        Group {
            Section {
                Text("아이디: \(acct.userId ?? "")")
                if acct.emailVerified {
                    Text("이메일: \(acct.email) (인증됨)")
                } else {
                    Text(acct.email.isEmpty ? "이메일: 등록 안 됨" : "이메일: \(acct.email) (인증 전)")
                    TextField("이메일", text: $mailInput)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button("인증 코드 보내기") { Task { await acct.requestEmailCode(mailInput) } }
                        .disabled(mailInput.isEmpty)
                    TextField("인증 코드 6자리", text: $codeInput).keyboardType(.numberPad)
                    Button("인증 확인") { Task { await acct.confirmEmail(codeInput) } }
                        .disabled(codeInput.isEmpty)
                }
            } header: {
                Text("계정")
            } footer: {
                if !acct.emailVerified {
                    Text("이메일을 인증하지 않으면 비밀번호를 잊어도 찾을 수 없어요.")
                }
            }
            Section {
                Button("설정과 촬영 기록을 서버에 저장") { askUpload = true }
                Button("서버에서 불러오기") { askDownload = true }
            } header: {
                Text("서버 저장")
            } footer: {
                Text("저장 항목: 디데이, 목표, 수능시계 항목, 영상 꾸미기와 타임스탬프 값, 설정값(fps·촬영 간격 등), 촬영 기록(통계).")
            }
            Section {
                Button("로그아웃") { acct.logout() }
                Button("계정 삭제", role: .destructive) { askDelete = true }
            }
        }
    }
}

// MARK: - 개발자 모드 허용 목록 (whitelist.txt: 한 줄에 아이디 하나, '#'은 주석)
enum Whitelist {
    static let ids: Set<String> = {
        guard let url = Bundle.main.url(forResource: "whitelist", withExtension: "txt")
                ?? BundleFiles.find("whitelist", exts: ["txt"]),
              let text = try? String(contentsOf: url, encoding: .utf8) else { return [] }
        let trim = CharacterSet.whitespacesAndNewlines.union(CharacterSet(charactersIn: "\u{FEFF}"))
        return Set(text.split(whereSeparator: \.isNewline)
            .map { $0.trimmingCharacters(in: trim).lowercased() }
            .filter { !$0.isEmpty && !$0.hasPrefix("#") })
    }()

    static func contains(_ id: String?) -> Bool {
        guard let id else { return false }
        return ids.contains(id.trimmingCharacters(in: .whitespaces).lowercased())
    }
}

// MARK: - 프로필 아이콘 (이모지 또는 사진. 사진은 이 기기에만 저장)
enum ProfileStore {
    static var imageURL: URL { Store.docs.appendingPathComponent("profile_icon.jpg") }

    static func image() -> UIImage? { UIImage(contentsOfFile: imageURL.path) }

    static func save(_ data: Data) {
        guard let img = UIImage(data: data), img.size.width > 0, img.size.height > 0 else { return }
        let side: CGFloat = 256
        let k = max(side / img.size.width, side / img.size.height)
        let size = CGSize(width: img.size.width * k, height: img.size.height * k)
        let fmt = UIGraphicsImageRendererFormat(); fmt.scale = 1; fmt.opaque = true
        let out = UIGraphicsImageRenderer(size: CGSize(width: side, height: side), format: fmt).image { _ in
            img.draw(in: CGRect(x: (side - size.width) / 2, y: (side - size.height) / 2,
                                width: size.width, height: size.height))
        }
        try? out.jpegData(compressionQuality: 0.85)?.write(to: imageURL)
    }

    static func remove() { try? FileManager.default.removeItem(at: imageURL) }
}

struct ProfileBadge: View {
    @ObservedObject var acct: AccountModel
    let size: CGFloat

    var body: some View {
        Group {
            if acct.imageVersion >= 0, let img = ProfileStore.image() {
                Image(uiImage: img)
                    .resizable().scaledToFill()
                    .frame(width: size, height: size)
                    .clipShape(Circle())
            } else {
                Text(acct.icon.isEmpty ? "😀" : acct.icon)
                    .font(.system(size: size * 0.8))
                    .frame(width: size, height: size)
            }
        }
    }
}

private let emojiChoices = ["😀", "😎", "😏", "🤓", "🥳", "😴", "🤔", "🦊", "🐶", "🐱", "🐼", "🐯", "🦁", "🐸",
                            "🐧", "🦉", "🍈", "🍎", "🍀", "🌙", "⭐️", "🔥", "📚", "✏️", "🎧", "☕️", "🚀", "🏆"]

struct ProfileEditForm: View {
    @ObservedObject var acct: AccountModel
    @State private var nameDraft = ""
    @State private var pick: PhotosPickerItem?
    @State private var saved = false

    var body: some View {
        Form {
            Section {
                TextField("이름 (선택)", text: $nameDraft)
                Button("이름 저장") {
                    Task {
                        await acct.setProfile(name: nameDraft.trimmingCharacters(in: .whitespaces))
                        saved = true
                    }
                }
                if saved { Text("저장했어요 ✓").font(.footnote).foregroundStyle(.secondary) }
            } header: {
                Text("이름")
            } footer: {
                Text("이름을 비우면 프로필 버튼에 아이디가 표시돼요.")
            }

            Section {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 6), count: 7), spacing: 6) {
                    ForEach(emojiChoices, id: \.self) { e in
                        Button {
                            ProfileStore.remove()
                            acct.imageVersion += 1
                            Task { await acct.setProfile(icon: e) }
                        } label: {
                            Text(e).font(.system(size: 28))
                                .frame(maxWidth: .infinity, minHeight: 44)
                                .background(acct.icon == e && ProfileStore.image() == nil
                                            ? Color.accentColor.opacity(0.2) : Color.clear,
                                            in: RoundedRectangle(cornerRadius: 10))
                        }
                        .buttonStyle(.plain)
                    }
                }
                PhotosPicker(selection: $pick, matching: .images) {
                    Label("사진에서 고르기", systemImage: "photo")
                }
                if ProfileStore.image() != nil {
                    Button("사진 지우기 (이모지로 돌아가기)", role: .destructive) {
                        ProfileStore.remove()
                        acct.imageVersion += 1
                    }
                }
            } header: {
                Text("아이콘")
            } footer: {
                Text("이모지는 서버에 저장되지만, 고른 사진은 이 기기에만 저장되고 서버로 올라가지 않아요.")
            }
        }
        .onAppear { nameDraft = acct.name }
        .onChange(of: pick) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self) {
                    ProfileStore.save(data)
                    acct.imageVersion += 1
                }
                pick = nil
            }
        }
    }
}

// MARK: - 프로필 (프로필 / 계정 / 통계)
struct ProfileView: View {
    @ObservedObject var acct: AccountModel
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 14) {
                    ProfileBadge(acct: acct, size: 56)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(acct.displayName).font(.title3.bold())
                        Text(acct.loggedIn ? "@\(acct.userId ?? "")" : "로그인하지 않았어요")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                .padding([.horizontal, .top])

                Picker("", selection: $tab) {
                    Text("프로필").tag(0)
                    Text("계정").tag(1)
                    Text("통계").tag(2)
                }
                .pickerStyle(.segmented)
                .padding()

                switch tab {
                case 0: ProfileEditForm(acct: acct)
                case 1: AccountView(acct: acct)
                default: StatsContent()
                }
            }
            .navigationTitle("프로필")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("닫기") { dismiss() } } }
        }
    }
}

// MARK: - 레이아웃 표시기 (개발자 모드): 버튼·박스·글자의 크기와 화면 대비 중심 좌표를 겹쳐서 보여줌
struct LayoutInspect: ViewModifier {
    let name: String
    @AppStorage("layoutInspect") private var on = false

    private var tint: Color {
        let hue = Double(name.unicodeScalars.reduce(0) { ($0 &* 31 &+ Int($1.value)) % 360 }) / 360
        return Color(hue: hue, saturation: 0.85, brightness: 0.95)
    }

    func body(content: Content) -> some View {
        content.overlay {
            if on {
                GeometryReader { g in
                    let f = g.frame(in: .global)
                    let b = (UIApplication.shared.connectedScenes.first as? UIWindowScene)?.screen.bounds
                        ?? CGRect(x: 0, y: 0, width: 1, height: 1)
                    Rectangle()
                        .stroke(tint, lineWidth: 1)
                        .overlay(alignment: .topLeading) {
                            Text("\(name)\n\(Int(f.width))×\(Int(f.height))  (\(String(format: "%.2f", f.midX / max(b.width, 1))), \(String(format: "%.2f", f.midY / max(b.height, 1))))")
                                .font(.system(size: 9, design: .monospaced))
                                .foregroundStyle(.white)
                                .padding(2)
                                .background(tint.opacity(0.85))
                                .fixedSize()
                        }
                }
                .allowsHitTesting(false)
            }
        }
    }
}

extension View {
    func inspect(_ name: String) -> some View { modifier(LayoutInspect(name: name)) }
}

// MARK: - 통계
struct StatsContent: View {
    @State private var summary = StatsLog.summary()

    private var hoursText: String {
        let h = (summary.hours * 10).rounded() / 10
        return h == h.rounded() ? "\(Int(h))시간" : String(format: "%.1f시간", h)
    }

    var body: some View {
        VStack(spacing: 40) {
            Spacer(minLength: 20)
            stat("지금까지 찍힌 나의 순간!", "\(summary.photos)장")
            stat("지금까지 찍힌 나의 연속성!", hoursText)
            VStack(spacing: 10) {
                Text("통계는 기기 안 ‘Stats’ 폴더의 capture_log.jsonl 로그에 저장돼요.")
                    .font(.footnote).foregroundStyle(.secondary)
                if FileManager.default.fileExists(atPath: StatsLog.file.path) {
                    ShareLink(item: StatsLog.file) { Label("로그 파일 내보내기", systemImage: "square.and.arrow.up") }
                        .font(.footnote)
                }
            }
            Spacer(minLength: 20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .onAppear { summary = StatsLog.summary() }
    }

    private func stat(_ title: String, _ value: String) -> some View {
        VStack(spacing: 8) {
            Text(title).font(.headline).foregroundStyle(.secondary)
            Text(value).font(.system(size: 48, weight: .bold, design: .rounded))
        }
    }
}

// MARK: - 프레임 체감 인디케이터 (흰 배경, 검정 공이 fps 속도로 좌→우 반복 이동)
struct FpsIndicator: View {
    let fps: Double

    var body: some View {
        TimelineView(.animation) { ctx in
            GeometryReader { g in
                let d: CGFloat = 28
                let frames = max(2, Int(fps * 2))   // 한 번 가로지르는 데 2초
                let tick = Int((ctx.date.timeIntervalSinceReferenceDate * fps).rounded(.down))
                let idx = tick % frames
                let p = CGFloat(idx) / CGFloat(frames - 1)
                Circle()
                    .fill(Color.black)
                    .frame(width: d, height: d)
                    .position(x: d / 2 + p * (g.size.width - d), y: g.size.height / 2)
            }
        }
        .frame(height: 70)
        .frame(maxWidth: .infinity)
        .background(Color.white)
    }
}

// MARK: - 설정
struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var tab = 0
    @AppStorage("dimWhileRunning") private var dim = true
    @AppStorage("dimLevel") private var dimLevel = 0.1
    @AppStorage("videoFps") private var fps = 24.0
    @AppStorage("captureInterval") private var interval = 120.0
    @AppStorage("showMotiv") private var showMotiv = true
    @State private var pickFont = false
    @State private var fontMsg = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("", selection: $tab) {
                    Text("영상 인코딩 설정").tag(0)
                    Text("전력/용량").tag(1)
                    Text("촬영 화면").tag(2)
                    Text("수능시계").tag(3)
                }
                .pickerStyle(.segmented)
                .padding()

                switch tab {
                case 0: encodingTab
                case 1: powerForm
                case 2: displayForm
                default: SuneungSettingsView()
                }
            }
            .navigationTitle("설정")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("완료") { dismiss() }
                }
            }
        }
    }

    // 영상 인코딩 설정
    private var encodingTab: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                FpsIndicator(fps: fps)

                VStack(alignment: .leading, spacing: 6) {
                    Text("프레임 \(Int(fps)) fps").font(.headline)
                    Slider(value: $fps, in: 5...60, step: 1)
                }
                .padding(.horizontal)

                VStack(alignment: .leading, spacing: 6) {
                    Text("촬영 간격 \(Int(interval))초").font(.headline)
                    Slider(value: $interval, in: 5...600, step: 1)
                }
                .padding(.horizontal)

                Text("개발자 추천\n장시간 촬영 설정 : 24fps, 120초 (12시간에 10.5초 영상 출력) (디폴트)\n단시간 촬영 설정 : 36fps, 6초 (1시간에 10초 영상 출력)")
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)
            }
        }
    }

    private var powerForm: some View {
        Form {
            Section("전력") {
                Toggle("촬영 중 밝기 낮추기", isOn: $dim)
                if dim {
                    VStack(alignment: .leading) {
                        Text("촬영 중 밝기 \(Int(dimLevel * 100))%")
                        Slider(value: $dimLevel, in: 0.0...0.5)
                    }
                }
            }
            Section {
                Text("남은 용량 \(ByteCountFormatter.string(fromByteCount: Store.availableBytes(), countStyle: .file))")
                Text("허용 한도(남은 용량의 70%) \(ByteCountFormatter.string(fromByteCount: Int64(Double(Store.availableBytes() + Store.frameBytes()) * Config.storageUseRatio), countStyle: .file))")
                Text("저장된 사진 \(ByteCountFormatter.string(fromByteCount: Store.frameBytes(), countStyle: .file))")
            } header: {
                Text("저장 용량")
            } footer: {
                Text("촬영은 남은 용량의 70%까지만 쓰고, 그 80%에 가까워지면 촬영 화면에서 알려줘요. 이 화면을 열 때마다 다시 계산돼요.")
            }
        }
    }

    private var displayForm: some View {
        Form {
            Section {
                Toggle("동기부여 문구 표시", isOn: $showMotiv)
            } header: {
                Text("촬영 화면")
            } footer: {
                Text("프로젝트에 넣은 motiv_text.txt의 문구(한 줄에 하나)가 촬영 화면 하단에 표시돼요. 문구를 누르면 다른 문구로 바뀌어요.")
            }
            Section {
                Button("서체 파일 선택 (ttf / otf)") { pickFont = true }
                Text("적용된 서체: \(FontLoader.customName() ?? "없음 (기본 서체 사용 중)")")
                    .font(.footnote)
                if !fontMsg.isEmpty { Text(fontMsg).font(.footnote).foregroundStyle(.secondary) }
                ZStack {
                    RoundedRectangle(cornerRadius: 10).fill(Color.black)
                    MyungjoText(text: "서체 미리보기 · 오늘도 화이팅!", size: 22).padding(16)
                }
                .frame(minHeight: 70)
            } header: {
                Text("목표 / 문구 서체")
            } footer: {
                Text("프로젝트에 넣은 ttf/otf가 인식되지 않으면 여기서 파일 앱의 서체 파일을 직접 골라주세요.")
            }
        }
        .fileImporter(isPresented: $pickFont,
                      allowedContentTypes: [UTType.font, UTType(filenameExtension: "ttf"), UTType(filenameExtension: "otf")].compactMap { $0 }) { result in
            switch result {
            case .success(let url):
                do {
                    try FontLoader.importFont(from: url)
                    fontMsg = FontLoader.customName().map { "적용됐어요: \($0)" } ?? "파일은 복사했지만 서체로 인식하지 못했어요"
                } catch {
                    fontMsg = "실패: \(error.localizedDescription)"
                }
            case .failure(let e):
                fontMsg = e.localizedDescription
            }
        }
    }
}
