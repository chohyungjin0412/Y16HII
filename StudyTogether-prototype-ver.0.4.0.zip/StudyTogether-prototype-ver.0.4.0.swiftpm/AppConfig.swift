import Foundation

// 서버를 만든 뒤 아래 두 값만 채우면 가짜(Mock) 모드가 꺼지고 실서버로 연결됨
enum AppConfig {
    static let appVersion = "prototype-0.4.0"                            // 앱 버전. 여기만 고치면 설정 탭 맨 아래 'Ver. 0.1.0'이 바뀜
    static let region = "ap-southeast-2"                       // 시드니 (개발용). 서울로 옮기면 ap-northeast-2
    static let cognitoClientId = "6o4lfburddnn6731gavgt8i736"         // Cognito 앱 클라이언트 ID (비밀 키 없는 것)
    static let apiBaseURL = "https://xoptufo6mi.execute-api.ap-southeast-2.amazonaws.com" // API Gateway 주소
    
    static var useMockAuth: Bool { cognitoClientId.hasPrefix("YOUR_") }
    static var useMockAPI: Bool { apiBaseURL.contains("YOUR_") }
}

