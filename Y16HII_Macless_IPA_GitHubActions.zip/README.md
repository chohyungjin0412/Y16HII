# Y16HII — Mac 없는 IPA 빌드

이 저장소는 Swift Playgrounds App Playground를 GitHub Actions의 macOS/Xcode 27 runner에서
unsigned IPA로 빌드하기 위한 테스트용 구성입니다.

## 사용법

1. 이 폴더의 내용을 **GitHub Public Repository**에 업로드합니다.
2. GitHub의 **Actions → Build Y16HII IPA → Run workflow**를 실행합니다.
3. 완료되면 workflow의 **Artifacts**에서 `Y16HII-unsigned-ipa`를 다운로드합니다.
4. 그 IPA를 SideStore 등에 넣어 Apple Account로 서명/설치합니다.

주의:
- `xcode-27` runner는 2026년 현재 public preview입니다.
- 무료 GitHub Actions macOS 사용은 **Public Repository** 기준입니다.
- 이 workflow는 **unsigned IPA**를 만듭니다. 개발자 계정으로 서명하는 단계는 포함하지 않습니다.
- `Package.swift`에 테스트용 Bundle ID `com.y16hii.studytime`을 명시했습니다.
