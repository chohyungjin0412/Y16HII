import SwiftUI

// ───────── 통계 탭 ─────────
// 데이터: 로그인했으면 서버에 올라간 하루 합계 + 이 기기에서 아직 안 올라간 기록 + 지금 재는 중인 시간.
//        로그인 안 했거나 서버를 못 불러오면 이 기기의 기록만 보여줌.

private let dayParser: DateFormatter = {
    let f = DateFormatter()
    f.locale = Locale(identifier: "en_US_POSIX")
    f.calendar = DayBoundary.calendar
    f.dateFormat = "yyyy-MM-dd"
    return f
}()

private let weekdayFormatter: DateFormatter = {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ko_KR")
    f.calendar = DayBoundary.calendar
    f.dateFormat = "E"
    return f
}()

private let monthDayFormatter: DateFormatter = {
    let f = DateFormatter()
    f.locale = Locale(identifier: "ko_KR")
    f.calendar = DayBoundary.calendar
    f.dateFormat = "M월 d일"
    return f
}()

/// 3시간 05분 / 42분
func hm(_ s: Int) -> String {
    let m = max(0, s) / 60
    if m >= 60 { return "\(m / 60)시간 \(String(format: "%02d", m % 60))분" }
    return "\(m)분"
}

struct StatsView: View {
    @EnvironmentObject var store: TimerStore
    @EnvironmentObject var session: SessionStore

    @State private var length = 7            // 7 / 30 / 90일
    @State private var offset = 0            // 0 = 가장 최근 기간, 1 = 그 전 기간 ...
    @State private var serverDays: [DailyStat]?
    @State private var loadError: String?
    @State private var now = Date()
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    private struct Agg {
        var total = 0
        var bySubject: [Int: Int] = [:]
    }

    // MARK: 기간 계산
    private var todayString: String { DayBoundary.studyDay(of: now) }

    private var rangeDays: [String] {
        let cal = DayBoundary.calendar
        let today = dayParser.date(from: todayString) ?? now
        let end = cal.date(byAdding: .day, value: -offset * length, to: today) ?? today
        return (0..<length).reversed().map { i in
            dayParser.string(from: cal.date(byAdding: .day, value: -i, to: end) ?? end)
        }
    }

    private func label(_ day: String) -> String {
        guard let d = dayParser.date(from: day) else { return day }
        return monthDayFormatter.string(from: d)
    }

    private func weekday(_ day: String) -> String {
        guard let d = dayParser.date(from: day) else { return "" }
        return weekdayFormatter.string(from: d)
    }

    // MARK: 집계
    private func aggregate() -> [String: Agg] {
        var out: [String: Agg] = [:]
        func add(_ day: String, _ subject: Int, _ sec: Int) {
            guard sec > 0 else { return }
            out[day, default: Agg()].total += sec
            out[day, default: Agg()].bySubject[subject, default: 0] += sec
        }
        var local = store.records
        if let days = serverDays {
            for d in days {
                for (k, v) in d.bySubject { if let id = Int(k) { add(d.day, id, v) } }
            }
            local = local.filter { !$0.synced }          // 이미 서버에 올라간 기록은 서버 값에 들어 있음
        }
        for r in local { add(DayBoundary.studyDay(of: r.start), r.subjectId, r.seconds) }
        if let id = store.runningSubjectId, let s = store.runningStart {   // 지금 재는 중인 시간
            for p in DayBoundary.split(StudyRecord(subjectId: id, start: s, end: now)) {
                add(DayBoundary.studyDay(of: p.start), id, p.seconds)
            }
        }
        return out
    }

    // MARK: 화면
    var body: some View {
        let days = rangeDays
        let agg = aggregate()
        let values = days.map { agg[$0]?.total ?? 0 }
        let total = values.reduce(0, +)
        let bestIndex = values.indices.max(by: { values[$0] < values[$1] })

        return ScreenScaffold("통계") {
            Picker("기간", selection: Binding(get: { length }, set: { length = $0; offset = 0 })) {
                Text("7일").tag(7)
                Text("30일").tag(30)
                Text("90일").tag(90)
            }
            .pickerStyle(.segmented)

            HStack {
                Button { offset += 1 } label: { Image(systemName: "chevron.left").frame(width: 36, height: 36) }
                Spacer()
                Text("\(label(days.first ?? "")) ~ \(label(days.last ?? ""))")
                    .font(.system(size: 15, weight: .medium)).foregroundColor(Theme.textPrimary)
                Spacer()
                Button { offset -= 1 } label: { Image(systemName: "chevron.right").frame(width: 36, height: 36) }
                    .disabled(offset == 0)
            }
            .foregroundColor(Theme.accent)

            if let loadError {
                Text("서버 기록을 불러오지 못해 이 기기의 기록만 보여줘요. (\(loadError))")
                    .font(.system(size: 12)).foregroundColor(Theme.danger)
            } else if !session.isSignedIn {
                Text("로그인하면 다른 기기에서 공부한 기록도 함께 보여줘요.")
                    .font(.system(size: 12)).foregroundColor(Theme.textSecondary)
            }

            // 요약
            HStack(spacing: 0) {
                summaryItem("총 공부시간", hm(total))
                summaryItem("하루 평균", hm(total / max(1, length)))
                summaryItem("가장 많이 한 날", bestIndex.map { values[$0] > 0 ? label(days[$0]) : "-" } ?? "-")
            }
            .card(vertical: 16)

            // 막대 그래프
            VStack(alignment: .leading, spacing: 8) {
                Text("하루 공부시간").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
                barChart(days, values)
            }
            .card(vertical: 16)

            // 과목별
            subjectSection(subjectTotals(days, agg), total)

            // 날짜별
            dailyList(days, values)
        }
        .refreshable { await load() }
        .task(id: "\(length)-\(offset)-\(session.isSignedIn)") { await load() }
        .onReceive(ticker) { t in if store.runningSubjectId != nil { now = t } }
    }

    private func summaryItem(_ title: String, _ value: String) -> some View {
        VStack(spacing: 4) {
            Text(value).font(.system(size: 17, weight: .bold)).foregroundColor(Theme.textPrimary)
                .minimumScaleFactor(0.7).lineLimit(1)
            Text(title).font(.system(size: 11)).foregroundColor(Theme.textSecondary)
        }
        .frame(maxWidth: .infinity)
    }

    private func barChart(_ days: [String], _ values: [Int]) -> some View {
        let maxV = max(values.max() ?? 0, 1)
        let showLabels = length == 7
        return HStack(alignment: .bottom, spacing: showLabels ? 8 : 2) {
            ForEach(Array(days.enumerated()), id: \.offset) { i, d in
                VStack(spacing: 4) {
                    RoundedRectangle(cornerRadius: 3)
                        .fill(d == todayString ? Theme.accent : Theme.accent.opacity(0.45))
                        .frame(height: max(2, CGFloat(values[i]) / CGFloat(maxV) * 120))
                    if showLabels {
                        Text(weekday(d)).font(.system(size: 11)).foregroundColor(Theme.textSecondary)
                    }
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: showLabels ? 150 : 128, alignment: .bottom)
    }

    /// 기간 전체의 과목별 합계 (많은 순)
    private func subjectTotals(_ days: [String], _ agg: [String: Agg]) -> [(key: Int, value: Int)] {
        var bySubject: [Int: Int] = [:]
        for d in days {
            for (id, sec) in agg[d]?.bySubject ?? [:] { bySubject[id, default: 0] += sec }
        }
        return bySubject.sorted { $0.value > $1.value }
    }

    @ViewBuilder private func subjectSection(_ rows: [(key: Int, value: Int)], _ total: Int) -> some View {
        if !rows.isEmpty {
            Text("과목별").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
            VStack(spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.element.key) { i, row in
                    let subject = store.subjects.first { $0.id == row.key }
                    VStack(spacing: 6) {
                        HStack(spacing: 8) {
                            Circle().fill(subject.map { Color(hex: $0.colorHex) } ?? Theme.border).frame(width: 12, height: 12)
                            Text(subject?.name ?? "보관된 과목").font(.system(size: 16, weight: .medium))
                                .foregroundColor(Theme.textPrimary)
                            Spacer()
                            Text(hm(row.value)).font(.system(size: 15)).monospacedDigit().foregroundColor(Theme.textSecondary)
                            Text("\(Int((Double(row.value) / Double(max(total, 1)) * 100).rounded()))%")
                                .font(.system(size: 13)).foregroundColor(Theme.textSecondary).frame(width: 40, alignment: .trailing)
                        }
                        ProgressView(value: Double(row.value) / Double(max(total, 1)))
                            .tint(subject.map { Color(hex: $0.colorHex) } ?? Theme.border)
                    }
                    .padding(.vertical, 10)
                    if i < rows.count - 1 { Divider1() }
                }
            }
            .card()
        }
    }

    @ViewBuilder private func dailyList(_ days: [String], _ values: [Int]) -> some View {
        let rows = Array(days.enumerated()).filter { values[$0.offset] > 0 }.reversed()
        Text("날짜별").font(.system(size: 14, weight: .medium)).foregroundColor(Theme.textSecondary)
        if rows.isEmpty {
            Text("이 기간에 기록이 없어요").font(.system(size: 14)).foregroundColor(Theme.textSecondary)
                .frame(maxWidth: .infinity).padding(.vertical, 24).card()
        } else {
            VStack(spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.offset) { i, row in
                    HStack {
                        Text("\(label(row.element)) (\(weekday(row.element)))")
                            .font(.system(size: 16)).foregroundColor(Theme.textPrimary)
                        if row.element == todayString {
                            Text("오늘").font(.system(size: 11, weight: .bold)).foregroundColor(.white)
                                .padding(.horizontal, 6).padding(.vertical, 2).background(Theme.accent, in: Capsule())
                        }
                        Spacer()
                        Text(hm(values[row.offset])).font(.system(size: 16)).monospacedDigit().foregroundColor(Theme.textSecondary)
                    }
                    .frame(height: 48)
                    if i < rows.count - 1 { Divider1() }
                }
            }
            .card()
        }
    }

    // MARK: 서버에서 불러오기
    private func load() async {
        guard session.isSignedIn, !AppConfig.useMockAPI, let first = rangeDays.first, let last = rangeDays.last else {
            await MainActor.run { serverDays = nil; loadError = nil }
            return
        }
        do {
            let d = try await store.api.fetchDaily(from: first, to: last)
            await MainActor.run { serverDays = d; loadError = nil }
        } catch {
            await MainActor.run { serverDays = nil; loadError = errorText(error) }
        }
    }
}
