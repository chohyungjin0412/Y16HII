import SwiftUI
import UIKit

@main
struct StudyTogetherApp: App {
    @StateObject private var app = AppContainer()
    
    var body: some Scene {
        WindowGroup {
            // 스플래시가 끝난 뒤에 메인 화면(RootView)이 만들어짐
            SplashGate {
                RootView()
            }
            .environmentObject(app.store)
            .environmentObject(app.session)
            .environmentObject(app.profile)
            .preferredColorScheme(.light)   // Figma 시안은 라이트 모드만 있음
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: TimerStore
    
    var body: some View {
        TabView {
            TimerView().tabItem { Label("타이머", systemImage: "timer") }
            StatsView().tabItem { Label("통계", systemImage: "chart.bar") }
            AuthGate("커뮤니티") { CommunityView() }.tabItem { Label("커뮤니티", systemImage: "person.3") }
            AuthGate("친구") { FriendsView() }.tabItem { Label("친구", systemImage: "person.2") }
            ProfileView().tabItem { Label("프로필", systemImage: "person.crop.circle") }
            SettingsView().tabItem { Label("설정", systemImage: "gearshape") }
        }
        .tint(Theme.accent)
        .toolbarBackground(Theme.surface, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        // 앱으로 돌아오면: 밀린 종료 신호/기록을 보내고, 서버에 기록된 내 상태를 다시 받아 옴
        // (onChange(of: scenePhase)는 iOS 버전마다 문법이 달라서 알림 방식을 씀)
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didBecomeActiveNotification)) { _ in
            store.flushPendingStops()
            store.syncPending()
            store.refreshSession()
        }
    }
}
